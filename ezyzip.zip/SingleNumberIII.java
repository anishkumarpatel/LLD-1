
public class SingleNumberIII {

	public static void main(String[] args) {
	  int arr[] = {1, 2, 3, 1, 2, 4};
	    int re[] = solve(arr);
	    System.out.println(re[0]+" "+re[1]);
	}
	 static int[] solve(int[] A) {
	        int xor=0;
	         
	         for(int a : A)
	            xor ^= a;
	             int pos=0;
	        for(int i=0; i<32; i++)
	           if(checkBit(xor,i))
	             {
	               pos = i;
	               break;
	             }
	        int a1 = 0,b1=0;

	        for(int a : A)
	        {
	            if(checkBit(a,pos))
	              a1 ^=a;
	            else
	             b1 ^= a;
	        }
	        if(a1<b1)
	       return new int[]{a1,b1};
	      else
	       return new int[]{b1,a1}; 
	    }
	static    boolean checkBit(int n, int i) {
			if (((n >> i) & 1) == 1)
				return true;
			else
				return false;
		}
}
