
public class KthSymbol {

	public static void main(String[] args) {
		System.out.println(solve(2, 2));
	}
	static int solve(int A, int B) {    
	        if(B==1) return 0;
	    
	        int p = solve(A-1, (B+1)/2) ;

	        if((B+1)%2 == 0)
	         return p ;
	         else
	          return 1 - p ;
	    }
	
static	int solve1(int A, int B) {
        return solveQ(A, B) ? 1 : 0;
    }
    static boolean solveQ(int n, int k) {

        if (n == 1 && k == 1)
            return false;

        int mid = (int) Math.pow(2, n - 1) / 2;

        if (k <= mid)
            return solveQ(n - 1, k);
        else
            return !solveQ(n - 1, k - mid);
    }
}
