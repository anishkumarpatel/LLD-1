import java.util.Arrays;

public class UniqueElement {

	public static void main(String[] args) {
		int A[] = {1, 1, 1, 2, 3, 4};

		int n = A.length ;
	/*
	  1 --> 3
	  2 --> 0
	  3 --> 0
	  4 --> 0
	 2 5 6 6 7 8 9 10 10 13 14 14 14 14 15 16 17 18 18 18 20 21 22 22 23 23 23 24 25 26 30 31 31 
	 32 32 34 35 36 37 39 41 45 46 47 48 48 51 51 51 53 54 54 54 55 56 56 56 60 61 62 66 66 66 67 68
	 69 69 71 72 73 73 75 76 76 79 80 81 81 81 83 83 85 85 85 85 86 88 92 95 97 98 99 100 100 
		*/	
		System.out.println(solve(A));
	}
	
	static int solve(int[] A) {
	        int n = A.length;

	        Arrays.sort(A);
	int count=0, pre = A[0];
	 
	        for(int i=1; i<n; i++){
	          if(  A[i] <= pre )
	             {
	                  count += pre +1 -A[i];
	                   A[i] = pre+1;
	             }
	             pre = A[i]; 
	             }

	             return count ;
	    }

}
