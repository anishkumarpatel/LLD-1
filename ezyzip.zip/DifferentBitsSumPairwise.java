public class DifferentBitsSumPairwise {

	public static void main(String[] args) {
		int a[] = { 1, 3, 5 };
		System.out.println(different(a) + " " + cntBits(a));

		int a1[] = { 2, 3 };
		System.out.println(different(a1) + " " + cntBits(a1));
	}

	static int different(int a[]) {
		int sum = 0;
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				int v = a[i] ^ a[j], c = 0;
				for (int k = 0; k < 32; k++)
					if (checkBit(v, k))
						c++;
				sum += c;
			}
		}
		return sum;
	}

	static boolean checkBit(int n, int i) {
		if (((n >> i) & 1) == 1)
			return true;
		else
			return false;
	}

	static int cntBits(int[] A) {
		long sum = 0, n = A.length;
		for (int i = 0; i < 32; i++) {
			long cs = 0, cus = 0;
			for (int j = 0; j < n; j++) {
				if (checkBit1(A[j], i)) {
					cs++;
				} else {
					cus++;
				}
			}
			sum = sum + (cs * cus * 2);
			sum = sum % (1000000007);
		}
		return (int) (sum % 1000000007);
	}

	static boolean checkBit1(int num, int pos) {
		if ((num & (1 << pos)) != 0) {
			return true;
		} else {
			return false;
		}
	}

	static int cntBit(int[] A) {
		long c1 = 0, c2 = 0;

		long ans = 0;

		for (int i = 0; i < 32; i++) {
			c1 = 0;
			for (int a : A) {
				if (checkBit(a, i))
					c1++;
			}
			ans += (A.length - c1) * c1;
			ans = ans % 1000000007;
		}
		return (int) ((2 * ans) % 1000000007);
	}
}
