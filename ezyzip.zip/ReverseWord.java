
public class ReverseWord {

	public static void main(String[] args) {
		// Your code goes here
				String A = "the sky is blue" ;
				 int n = A.length() - 1;
				  A =  reverseWord(A);
		      System.out.print(A);
	}
//	https://www.interviewbit.com/snippet/611caf7aacbad457882c/
	
	static String reverseWord(String A)
	{
	    int n = A.length()-1, p1=0, p2=0;

	    A = reverse(A,0,n);
	   
	  StringBuilder sb = new StringBuilder();  
	   if(A.charAt(0)  == ' ' )
	        p1++;
	    while(p1<=n)
	    {
	        while(p2<=n && A.charAt(p2)!= ' ')
	         p2++;
	        if(p1<p2){
	        sb.append(reverse(A,p1,p2-1));
	      //  if(A.charAt(p2) == ' ' && p2 != n) top mistake
	      if(n != sb.length())
	        sb.append(" ");
	    }
	      p1 = p2+1; p2 = p1;
	    }
	    //sb.deleteCharAt(sb.length()-1);
	    return sb.toString();
	}

	  static  String reverse(String A, int p1, int p2)
	    {
	        StringBuilder sb = new StringBuilder();

	        for(int i=p2; i>=p1; i--)
	         sb.append(A.charAt(i));
	      return sb.toString();
	    }

	   static  String reverseWord1(String A)
	 {
	      int n = A.length(), p1=0,p2=0;
	        A = reverse(A,0,n-1);
	        StringBuilder ans = new StringBuilder();
	        while(p1<n&&p2<n&&A.charAt(p1)==' ')
	        {
	            p1++;
	            p2++;
	        }
	        while(p1<n){
	            while(p2<n &&A.charAt(p2)!=' ' ){
	                p2++;
	            }
	            if(p1<p2)
	                {
	                    ans.append(reverse(A,p1,p2-1));
	                    ans.append(" ");
	                    p1=p2+1;
	                    p2=p1;
	                }
	        }
	        StringBuilder ans2 = new StringBuilder();
	        for(int i=0;i<ans.length()-1;i++)
	            ans2.append(ans.charAt(i));
	        return ans2.toString();
	 }

	}
	// "blue is sky the"
/*
 
 class  Test
{
	public static void main(String[] args) throws Exception
	{
		
	}

	public int[] solve(int[] A, int B) {
         ArrayList < Integer > l1 = new ArrayList < > ();
         int n = A.length;
         int len = 2 * B + 1;
         for (int i = 0; i < n - len + 1; i++) {
             int curr = -1;
             int flag = 1;
             for (int j = i; j < i + len; j++) {
                 if (A[j] == curr) {
                     flag = 0;
                     break;
                 }
                 curr = A[j];
             }
             if (flag == 1) {
                 l1.add(i + B);
             }
         }
         int[] ret = new int[l1.size()];
         for (int i = 0; i < l1.size(); i++) {
             ret[i] = l1.get(i);
         }
         return ret;
     }
}
Output 1:

 [1, 2, 3]
 ==

 public class Solution {
    public void solve(int[][] A) {
        int r = A.length, column = A[0].length;

        for(int i = 0; i<column; i++) // transpose
         for(int j=i+1; j<r; j++)
          {
               A[i][j] = A[i][j] + A[j][i];
                  A[j][i] = A[i][j] - A[j][i];
                  A[i][j] = A[i][j] - A[j][i];
          }
        for(int i=0; i<column; i++) 
         for(int j=0; j<r; j++)  // reverse the row
         { if(i< j)
          {
               A[i][j] = A[i][j] + A[i][r-1-j];
               A[i][r-1-j] = A[i][j] - A[i][r-1-j];
               A[i][j] = A[i][j] - A[i][r-1-j];
          }else break;}
   
    }
}

==

public class Solution {

    public void solve(int[][] A) {

        int n= A.length;


        for(int i = 0; i<n; i++) // transpose

         for(int j=i+1; j<n-1; j++)

          {

               A[i][j] = A[i][j] + A[j][i];

                  A[j][i] = A[i][j] - A[j][i];

                  A[i][j] = A[i][j] - A[j][i];

          }

        for(int i=0; i<n; i++)

         for(int j=0; j<n; j++)

         { if(i< j)

          {


               A[i][j] = A[i][j] + A[i][n-1-j];

               A[i][n-1-j] = A[i][j] - A[i][n-1-j];

               A[i][j] = A[i][j] - A[i][n-1-j];

          }else break;}

   

    }

}


while(j=0; j<n-e; j++)
{
	
	sum=0
		for(int i=e; i<b; i++)
		 sum+= A[i];
	ans = max(ans,sum)

		temp+=1;
}
============

// Java implementation to return
// an array of its anti-diagonals
// when an N*N square matrix is given

class Matrix {

	// function to print the diagonals
	void diagonal(int A[][])
	{

		int N = 3;

		// For each column start row is 0
		for (int col = 0; col < N; col++) {

			int startcol = col, startrow = 0;

			while (startcol >= 0 && startrow < N) {

				System.out.print(A[startrow][startcol]
								+ " ");

				startcol--;

				startrow++;
			}
			System.out.println();
		}

		// For each row start column is N-1
		for (int row = 1; row < N; row++) {
			int startrow = row, startcol = N - 1;

			while (startrow < N && startcol >= 0) {
				System.out.print(A[startrow][startcol]
								+ " ");

				startcol--;

				startrow++;
			}
			System.out.println();
		}
	}

	// Driver code
	public static void main(String args[])
	{

		// matrix initialisation
		int A[][]
			= { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };

		Matrix m = new Matrix();

		m.diagonal(A);
	}
}

==

public class Solution {
    public int[][] diagonal(int[][] A) {
      int n = A.length;
int a[][]= new int[2*n-1][n];

      for(int i=0; i<n; i++)
       a = getDiagonal1(A,0,i);
     for(int i=1; i<n; i++)
      a = getDiagonal(A,i,n-1);
return a;
       
    }

    int[][] getDiagonal1(int A[][],int i, int j)
    {
        int column = A.length;

int a[][]= new int[2*column-1][column];

         int y=i,z=j;
        while( z<column)
        {
            a[y][z]= A[y][z];
            z++; 
        }
      return  a;
    }

     int[][] getDiagonal(int A[][],int i, int j)
    {
        int column = A.length;

int a[][]= new int[2*column-1][column];

         int y=i,z=j;
        while( y<column && z>=0)
        {
            a[y][z]= A[y][z];
            y++; z--;
        }
      return  a;
    }
}

********
***  ***
**    **
*      *
*      *
**    **
***  ***
********


public class Solution {
    public int solve(String A) {
    return getMaxLength(A); 
    }

    int getMaxLength(String s)
    {
        int n = s.length();
int ans=0, max;
        for(int i=0; i<n; i++)
        {
            max=0;
            int left=0,right=0;
            if(i-1 != -1)
            for(int j=i-1; j>=0 && s.charAt(j)!='0'; j-- ) 
             if(left == 0) left=0;
             else left++;
              if(i+1 != n)   
            for(int j=i+1; j< n && s.charAt(j)!= '0'; j++ ) 
              if(right == 0 )
               right =0;
               else right++;

            ans = Math.max(ans,left+right+1);
        }
        return ans;
    }
}


Working code is pasted below : here prefix and suffix logic is used whilehandling the case of 1 swap actually ( go for CHR discussion for better understanding of this problem )


int maximum_one(string &s) {
    // To count all 1's in the string
    int cnt_one = 0;
     int n=s.size();
    for (int i = 0; i < n; i++) {
        if (s[i] == '1')
            cnt_one++;
    }

    // To store cumulative 1's
    int left[n], right[n];

    if (s[0] == '1')
        left[0] = 1;
    else
        left[0] = 0;

    if (s[n - 1] == '1')
        right[n - 1] = 1;
    else
        right[n - 1] = 0;
    for (int i = 1; i < n; i++) {
        if (s[i] == '1')
            left[i] = left[i - 1] + 1;
        else
            left[i] = 0;
    }

    for (int i = n - 2; i >= 0; i--) {
        if (s[i] == '1')
            right[i] = right[i + 1] + 1;

        else
            right[i] = 0;
    }

    int cnt = 0, max_cnt = 0;
    for(int i=0; i<n; ++i )
    max_cnt=max(max_cnt,max(right[i],left[i]));
    for (int i = 1; i < n - 1; i++) {
        if (s[i] == '0') {
            int sum = left[i - 1] + right[i + 1];

            if (sum < cnt_one)
                cnt = sum + 1;

            else
                cnt = sum;

            max_cnt = max(max_cnt, cnt);
            cnt = 0;
        }
    }

    return max_cnt;
}

int Solution::solve(string A) {
    return maximum_one(A);
}
===

 public ArrayList<Integer> solve(ArrayList<Integer> A) {
        int n = A.size();
      int ans =0, s = 0, e = 0;

       for(int i=0; i<n; i++)
       {
           int max=0;
           for(int j=i; j<n; j++)
           {
               if(A.get(j)>= 0 )
               {
                   max = j - i + 1;
                    e = j;
               }else break;
           }
           if(ans<max)
            {
                s = i;
                ans = max;
            } else if(ans == max) continue;
       }
   ArrayList<Integer> a = new ArrayList<Integer>();
     for(int i=s; i<=e; i++)
      a.add(A.get(i));
    return a;
    }



	 public ArrayList<Integer> solve(ArrayList<Integer> A) {
        int n = A.size();

        int ans=0, count, start=0, end = 0, e=0;

        for(int i=0; i<n; i++)
        {
            count=0; 

            for(int j=i; j<n; j++)
             if(A.get(j) >= 0)
             {
                 count = j - i +1; e = j;
             }else break;
        if(ans<count)
        {
            start = i;
            end = e;
            ans = count;
        }
        else if(count == ans) continue;
        }
     ArrayList<Integer> a = new ArrayList<Integer>();

     for(int i=start; i<=end; i++)
      a.add(A.get(i));

    return a;
    }

8986143, -5026827, 5591744, 4058312, 2210051, 5680315, -5251946, -607433, 1633303, 2186575 

The expected return value:
5591744 4058312 2210051 5680315 

5591744 4058312 2210051 5680315 

====

public class Solution {
  public int[] solve(int[] A) {
    int size = 0, left = 0, right = 0;
    for (int l = -1, r = 0; r < A.length; r++) {
      if (A[r] >= 0) {
        if (size < r - l) {
          size = r - l;
          left = l;
          right = r;
        }
      } else {
        l = r;
      }
    }
    int ans[] = new int[size];
    for (int i = left + 1; i <= right; i++) ans[i - left - 1] = A[i];
    return ans;
  }
}

 int n = A.length;
int i= -1,j=0,start=0,end=0,size=0;
		 while( j<n)
		 {
           if(A[j]>=0)
			   {if(size < j -i)
			    {
					size = j-i;
					start = i; end = j;
				}
				}
				else i = j;
			
			j++;
		 }
======correct below

public class Solution {
  public int[] solve(int[] A) {
     int n = A.length;
int i=0,j=0,start=0,end=0,size=0;
		 while( j<n)
		 {
           if(A[j]>=0)
			   {if(size < j -i)
			    {
					size = j-i;
					start = i; end = j;
				}
				}
				else i = j;
			
			j++;
		 }
		int a[] = new int[size+1];
int k=0;
		for(int l=start; l<=end; l++)
          if(l!= -1)
		  {a[k] = A[l]; k++;}
		return a;
	}
}

============

 int n = A.length;
int i=0,j=0,start=0,end=0;
		 while( j<n)
		 {
           if(A[j]>=0)
			   {if(j-i  > end-start)
			    {start = i; end = j;
				}
				}
				else i = j;
			
			j++;
		 }
		 ===


	public class Solution {
	public long reverse(long a) {
         long A = a;
        long rev = 0,m = 31;
    while(m>0){
        //print(A%2)
        
            rev = rev | (1<<m);
        
        A=A/2;
        m = m<<1;
    }
    return rev;
	}
}


public class Solution {
  public long reverse(long a) {
          long A = a;
         long rev = 0,m = 31;
     while(A>0){
         //print(A%2)
         if(A%2==1){
             rev = rev | (1l <<m);
         }
         A=A/2;
         m--;
     }
     return rev;
   }
 }
https://www.interviewbit.com/snippet/8763d6712c714ddb70d4/

Q1. Sort by Color

https://www.interviewbit.com/snippet/611caf7aacbad457882c/

Q1ReverseTheString.java



https://www.interviewbit.com/snippet/611caf7aacbad457882c/



for(int i=0; i<n; i++)
{
	for(int j=0; i)
}
 
 */
