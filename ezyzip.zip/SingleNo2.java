import java.util.*;
public class SingleNo2 {

	public static void main(String[] args) {
	   int a[] = {1, 2, 4, 3, 3, 2, 2, 3, 1, 1};
	    System.out.println(singleNumber(a));
	}    static int singleNumber(final int[] A) {
	        int ans=0 ;
	         for(int i=0; i<32; i++)
	         {
	              int c =0;
	             for(int j=0; j<A.length; j++)
	               if( checkBit(A[j],i) )
	                 c++;
	                if(c%3 != 0)
	                ans |= (1 << i) ;
	         }
	         return ans;
	    }
	    static boolean checkBit(int n , int i)
	    {
	        if(((n>>i)&1) == 1 ) return true;
	       else
	        return false;
	    }
	    static int singleNumber11(final List < Integer > A) {
	        int ones = 0, twos = 0, threes = 0;
	        for (int num : A) {
	            // twos is a bitmask to represent the ith bit had appeared twice
	            twos |= ones & num;
	            // ones is a bitmask to represent the ith bit had appeared once
	            ones ^= num;
	            // threes is a bitmask to represent the ith bit had appeared three times
	            threes = ones & twos;
	            ones &= ~threes;
	            twos &= ~threes;
	        }
	        return ones;
	    }
	    public int singleNumber111(final List < Integer > A) {
	        int[] bits = new int[32];
	        // check frequency of each bit
	        for (int num: A) {
	            for (int i = 0; i < 32; i++) {
	                bits[i] += (1 & (num >> i));
	                bits[i] %= 3;
	            }
	        }
	        int number = 0;
	        for (int i = 31; i >= 0; i--) {
	            number = number * 2 + bits[i];
	        }
	        return number;
	    }
	}

/*
 Input 1:

 A = [1, 2, 4, 3, 3, 2, 2, 3, 1, 1]
Input 2:

 A = [0, 0, 0, 1]


Example Output
Output 1:

 4
Output 2:

 1
 */

