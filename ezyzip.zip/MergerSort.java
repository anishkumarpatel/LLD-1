public class MergerSort {

	public static void main(String[] args) {
		int A[] = {9,4,7,6,3,1,5} ;
		 int n = A.length ;
	 mergeSort(A, 0, n-1);		  
		  for(int i=0; i<n; i++)
		 System.out.print(A[i]+" "); 
	}	
	static void mergeSort(int []A, int l, int r)
	{
		if(l<r) {
			int mid = (l+r)/2 ;
			
			mergeSort(A, l, mid);
			
			mergeSort(A, mid+1, r);
			
			merger(A,l,mid,r);
		}
	}
	static void merger(int A[], int l , int mid, int r)
	{
		int B[] = new int[A.length] ;
		
		int i = l;
		 int j = mid+1;
		  int k = l;
	  while(i<=mid && j<=r)
	  {
		  if(A[i]<A[j])
			  B[k] = A[i++];
		  else
			  B[k] = A[j++]; 
		  k++;
	  }
	  if(i>mid)
		while(j<=r)  B[k++] = A[j++];
	  else
		  while(i<=mid) B[k++] = A[i++];
	  
	  for(int m = l; m<=r; m++)
		  A[m] = B[m];
	}
}
/*
 public class Solution {
    public int solve(int[] A) {
        int n = A.length-1 ;
       return (int)mergeSort(A,0,n) ;
    }
  long mergeSort(int[] A, int left, int right)
    {
          long count = 0;
        if(left<right)
        {
             int mid = (left+right)/2 ;
           count += mergeSort(A,left, mid) ;
            count += mergeSort(A, mid + 1, right) ;
              count += merge(A,left, mid, right) ; 
        }
        return count ;
    }
    long merge(int[] A, int left, int mid, int right)
    {
        int[] temp = new int[right-left+1] ;

        int i = left;
        int j = mid+1;
        int k = 0 ; //why
long count = 0;
        while(i<= mid && j<= right)
         if(A[i]<=A[j])
            temp[k++] = A[i++];
          else
               temp[k++] = A[j++];
        
        if(i>mid)
          while(j<=right) temp[k++] = A[j++];
        else
          while(i<=mid) temp[k++] = A[i++];
    
     i = left; j= mid+1;
        while(i<= mid && j<= right)
        {  if( A[i] <=  2l*A[j] )
             i++ ;
          else
           { 
                j++ ;
             count += (mid-i+1);  // this step i  am getting confusion
           }
        }

          for(int l=left; l <= right; l++)
             A[l] = temp[l-left];

             return count; // no issue about curly braces
    }
}
 */


