import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Serial {

	public static void main(String[] args) throws Exception {
		 Dog d = new Dog();
		FileOutputStream fos = new FileOutputStream("abc.ser");
		ObjectOutputStream oops = new ObjectOutputStream(fos);
		 oops.writeObject(d);
		 
		 FileInputStream fis = new FileInputStream("abc.ser");
		 ObjectInput oos = new ObjectInputStream(fis);
		  Dog d1 = (Dog)oos.readObject();
		  
		  System.out.println(d1.i+" "+d1.j);		
	}
}
class Dog implements Serializable
{
  int i= 101, j = 202;
}
