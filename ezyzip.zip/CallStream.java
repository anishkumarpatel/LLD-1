package com.dsa;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CallStream {

	public static void main(String[] args) {
		ArrayList<Integer> arrayList = new ArrayList<>();
		arrayList.add(1);
		arrayList.add(2);
		arrayList.add(3);
		arrayList.add(4);
		arrayList.add(5);
		arrayList.add(6);
		arrayList.add(7);
		arrayList.add(8);
		System.out.println(arrayList);

		List<Integer> list = arrayList.stream().filter(i -> i % 2 == 0).collect(Collectors.toList());
		System.out.println(list);

		list = arrayList.stream().map(i -> i + 5).collect(Collectors.toList());
		System.out.println(list);
	}

}
