package com.dsa;

import java.util.Scanner;

public class Bank {

	public static void main(String[] args) {
	  Scanner scanner = new Scanner(System.in);
	  
	  while(true)
	  {
		  System.out.println("Arithmetic Operations");
		  System.out.println("1. Add");
		  System.out.println("2. Subtract");
		  System.out.println("3. Multiply");
		  System.out.println("4. Division");
		  System.out.println("Quit");
		  
		  System.out.print("Enter your choice: ");
		   int ch = scanner.nextInt();
		   
		   if(ch == 1) {
			   System.out.println("Entre 3 numbers");
			    int a = scanner.nextInt();
			     int b = scanner.nextInt();
			      int c = a+b;
			     System.out.println("Result: "+c);
		   }
		   if(ch == 2) {
			   System.out.println("Entre 3 numbers");
			    int a = scanner.nextInt();
			     int b = scanner.nextInt();
			      int c = a-b;
			     System.out.println("Result: "+c);
		   }
		   if(ch == 3) {
			   System.out.println("Entre 3 numbers");
			    int a = scanner.nextInt();
			     int b = scanner.nextInt();
			      int c = a*b;
			     System.out.println("Result: "+c);
		   }
		   if(ch == 4) {
			   System.out.println("Entre 3 numbers");
			    int a = scanner.nextInt();
			     int b = scanner.nextInt();
			      int c = a/b;
			     System.out.println("Result: "+c);
		   }
		   if(ch == 5) break;
		   /*
		    if(ch == 5) {
			   System.out.println("Signing off");
			    System.exit(1);
		   }
		    */
	  }

	}
}
