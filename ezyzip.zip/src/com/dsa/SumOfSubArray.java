
public class SumOfSubArray {

	public static void main(String[] args) {
		int[] A = {1,2,2} ;
		System.out.println(brute1(A));
		System.out.println(brute2(A));
		System.out.println(solve(A));
	}
//	Efficient Approach: To solve the problem follow the below idea:
//
//		If we take a close look then we observe a pattern. 
//		Let’s take an example:
//
//		arr[] = [1, 2, 3], n = 3
//		All subarrays :  [1], [1, 2], [1, 2, 3], [2], [2, 3], [3]
//
//		here first element ‘arr[0]’ appears 3 times    
//		second element ‘arr[1]’ appears 4 times  
//		third element ‘arr[2]’ appears 3 times
//
//		Every element arr[i] appears in two types of subsets:
//
//		i)  In subarrays beginning with arr[i]. There are 
//		    (n-i) such subsets. For example [2] appears
//		    in [2] and [2, 3].
//
//		ii) In (n-i)*i subarrays where this element is not
//		    first element. For example [2] appears in [1, 2] and [1, 2, 3].
//
//		Total of above (i) and (ii) = (n-i) + (n-i)*i  = (n-i)(i+1)
//
//		For arr[] = {1, 2, 3}, sum of subarrays is:
//
//		  arr[0] * ( 0 + 1 ) * ( 3 – 0 ) + 
//		  arr[1] * ( 1 + 1 ) * ( 3 – 1 ) +
//		  arr[2] * ( 2 + 1 ) * ( 3 – 2 ) 
//
//		= 1*3 + 2*4 + 3*3 
//		= 20
//
//		Follow the below steps to solve the problem:
//
//		Declare an integer answer equal to zero
//		Run a for loop for i [0, N]
//		Add arr[i] * (i+1) * (N-i) into the answer at each iteration
//		Return answer
//		Below is the implementation of the above approach:
//

	static int solve(int[] A) {
		int n = A.length ;
		int sum = 0;
		for(int i=0; i<n ; i++)
			sum += (n-i)*(i+1)*A[i] ;
	 return sum ;
	}
	static int brute2(int[] A) {
		int n = A.length ;
		int sum = 0;
		for(int i=0; i<n; i++) {
			int temp = 0;
			for(int j=i; j<n; j++) {
				temp += A[j];
				sum += temp;
			}
		}
		return sum;
	}
	static int brute1(int[] A) {
		int n = A.length ;
		int sum = 0;
		for(int i=0; i<n; i++) {
			for(int j=i; j<n; j++) {
				for(int k=i; k<=j; k++)
					sum += A[k];
			}
		}
		return sum ;
	}

}
