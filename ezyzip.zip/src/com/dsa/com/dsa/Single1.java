package com.dsa;

public class Single1 {

	public static void main(String[] args) {
		int a[] = { 1, 3, 1, 4, 5, 4, 5 };
		System.out.println(single1(a));
	}

	static int single1(int a[]) {
		int result = 0;

		for (int ele : a)
			result = result ^ ele;
		return result;
	}

}
