package com.dsa.queue;
import java.util.*;
public class FirstnonRepeatingCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	 public String solve(String A) { // optimised
	        int n = A.length();
	        StringBuilder sb = new StringBuilder();
	        if(n==1)
	          return A ;
	        Deque<Character> q = new ArrayDeque();
	        int[] a = new int[26];

	        for(int i=0; i<n; i++){
	            
	            char c = A.charAt(i) ;
	               q.offer(c) ;
	               a[c-'a']++ ;

	            while(!q.isEmpty() && a[q.peekFirst()-'a'] != 1)
	                q.pollFirst();
	             
	            if(q.isEmpty())
	             sb.append('#') ;
	            else
	             sb.append(q.peekFirst());
	        }
	        return sb.toString();
	    }
	public String brute(String A) { // brute force approach
        int n = A.length();
        StringBuilder sb = new StringBuilder();

        for(int i=0; i<n; i++){
            String s = A.substring(0,i+1);

           LinkedHashMap<Character,Integer> map = new LinkedHashMap();

            for(int j=0; j<s.length(); j++)
            {
                int fre = map.getOrDefault(s.charAt(j),0)+1 ;
                map.put(s.charAt(j),fre) ;

            }
             int flag = 1;
            for(Map.Entry<Character,Integer> entry : map.entrySet())
               if(entry.getValue() == 1){
                    flag = 0;
                    sb.append(entry.getKey()) ;
                    break;
               }
               if(flag == 1) sb.append('#') ;
        }
        return sb.toString() ;
    }
}

//Example Input
//Input 1:
//
// A = "abadbc"
//Input 2:
//
// A = "abcabc"
//
//
//Example Output
//Output 1:
//
//"aabbdd"
//Output 2:
//
//"aaabc#"
//
//
//Example Explanation
//Explanation 1:
//
//"a"      -   first non repeating character 'a'
//"ab"     -   first non repeating character 'a'
//"aba"    -   first non repeating character 'b'
//"abad"   -   first non repeating character 'b'
//"abadb"  -   first non repeating character 'd'
//"abadbc" -   first non repeating character 'd'
//Explanation 2:
//
//"a"      -   first non repeating character 'a'
//"ab"     -   first non repeating character 'a'
//"abc"    -   first non repeating character 'a'
//"abca"   -   first non repeating character 'b'
//"abcab"  -   first non repeating character 'c'
//"abcabc" -   no non repeating character so '#'
//
//
//
//See Expected Output
