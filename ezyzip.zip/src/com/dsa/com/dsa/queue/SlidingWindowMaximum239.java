package com.dsa.queue;
import java.util.*;
public class SlidingWindowMaximum239 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public int[] slidingMaximum(final int[] A, int B) {
        int n = A.length;
        if(B>n) return new int[]{1} ;
        int[] C = new int[n-B+1];
        Deque<Integer> q = new ArrayDeque() ;
        int s = 0;
        for(int e=0; e<n; e++){
            while(!q.isEmpty() && q.peekLast() < A[e] )
              q.pollLast();
            q.offer(A[e]);

            if(e-s+1 == B){
                C[s] = q.peekFirst() ;
                if(q.peekFirst() == A[s])
                  q.pollFirst() ;
                s++;
            }
        }
        return C ;
    }
	public ArrayList < Integer > slidingMaximum(final List < Integer > A, int B) {
        int n = A.size();
        int i;
        ArrayList < Integer > res = new ArrayList < > ();
        int window = Math.min(A.size(), B);
        Deque < Node > deque = new LinkedList < > ();
        int val;
        Node ans;
        for (i = 0; i < window - 1; i++) {
            val = A.get(i);
            while (!deque.isEmpty() && deque.peekFirst().val <= val) {
                deque.pollFirst();
            }
            deque.addFirst(new Node(i, val));
        }
        for (; i < n; i++) {
            val = A.get(i);
            // removes the elements not in range
            while (!deque.isEmpty() && (i - deque.peekLast().index >= window)) {
                deque.pollLast();
            }
            // removes the elements lesser than A[i]
            while (!deque.isEmpty() && deque.peekFirst().val <= val) {
                deque.pollFirst();
            }
            deque.addFirst(new Node(i, val));
            ans = deque.peekLast();
            res.add(ans.val);
        }
        return res;
    }

    class Node {
        int val;
        int index;
        public Node(int index, int val) {
            this.index = index;
            this.val = val;
        }
    }

}
//
//Input: nums = [1,3,-1,-3,5,3,6,7], k = 3
//Output: [3,3,5,5,6,7]
//Explanation: 
//Window position                Max
//---------------               -----
//[1  3  -1] -3  5  3  6  7       3
// 1 [3  -1  -3] 5  3  6  7       3
// 1  3 [-1  -3  5] 3  6  7       5
// 1  3  -1 [-3  5  3] 6  7       5
// 1  3  -1  -3 [5  3  6] 7       6
// 1  3  -1  -3  5 [3  6  7]      7