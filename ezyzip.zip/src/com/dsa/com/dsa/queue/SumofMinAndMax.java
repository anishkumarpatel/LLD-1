package com.dsa.queue;
import java.util.* ;
public class SumofMinAndMax {

	public static void main(String[] args) {
//		Example Input
//		Input 1:
//
//		 A = [2, 5, -1, 7, -3, -1, -2]
//		 B = 4
//		Input 2:
//
//		 A = [2, -1, 3]
//		 B = 2
//
//
//		Example Output
//		Output 1:
//
//		 18
//		Output 2:
//
//		 3
//
//
//		Example Explanation
//		Explanation 1:
//
//		 Subarrays of size 4 are : 
//		    [2, 5, -1, 7],   min + max = -1 + 7 = 6
//		    [5, -1, 7, -3],  min + max = -3 + 7 = 4      
//		    [-1, 7, -3, -1], min + max = -3 + 7 = 4
//		    [7, -3, -1, -2], min + max = -3 + 7 = 4   
//		    Sum of all min & max = 6 + 4 + 4 + 4 = 18 
	}
	public int solve(int[] A, int B) { // optimised
        int n = A.length ;
        long maxSum=0;
        int mod = 1000*1000*1000+7 ;
        Deque<Integer> q = new ArrayDeque();
        int s = 0;
        for(int e=0; e<n; e++){
             while(q.size()>0 && q.peekLast()< A[e])
                q.pollLast();
                q.offer(A[e]) ;
            if(e-s+1 == B){
                maxSum = (maxSum + q.peekFirst() + mod)%mod ;
                if(q.peekFirst() == A[s])
                 q.pollFirst();
                s++ ;
            }
          //  q.offer(A[e]) ;
        }
        long minSum = 0;
        s = 0;
        q = new LinkedList();
        for(int e = 0 ; e<n; e++){
           while(q.size()>0 && q.peekLast()> A[e])
                q.pollLast();
                q.offer(A[e]) ;
            if(e-s+1 == B){
                minSum = (minSum + q.peekFirst() + mod)%mod ;
                if(q.peekFirst() == A[s])
                 q.pollFirst();
                s++ ;
            }
         //   q.offer(A[e]) ;   
        }
      return (int)( ( maxSum + minSum + mod ) % mod )  ;
    }
	public int solve2(int[] A, int B) { // brute 
        int n = A.length;
        int max = Integer.MIN_VALUE ;
        int min = Integer.MAX_VALUE ;

        for(int i=0; i<B; i++){
            max = Math.max(max,A[i]);
            min = Math.min(min,A[i]);
        }
        long sum = max+min;
        int mod = 1000*1000*1000+7 ;
        for(int i=1; i+B-1<n; i++){
            max = A[i];
            min = A[i] ;
            for(int j=i; j<i+B; j++){
                max = Math.max(max,A[j]);
            min = Math.min(min,A[j]); 
            }
            sum = (sum + max+min+mod)%mod ;
        }
        return (int)sum ;
    }
	public int solve1(int[] A, int B) {  /// brute force approach
        int n = A.length ;
        int sum=0;
        int mod = 1000*1000*1000+7 ;
        for(int s=0; s<n; s++)
         for(int e=s; e<n; e++)
          if(e-s+1 == B)
           sum = (sum + subArray(A,s,e)+mod)%mod;
        return sum ;
    }
    int subArray(int[] A,int s,int e){
        int n = A.length;
        int max = A[s];
        int min = A[s];
        for(int i=s; i<=e; i++){
            max = Math.max(max,A[i]);
            min = Math.min(min,A[i]);
        }
        return max+min ;
    }
}
