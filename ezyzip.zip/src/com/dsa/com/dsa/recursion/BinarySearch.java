package com.dsa.recursion;

public class BinarySearch {

	public static void main(String[] args) {
       int[] A = {1,2,3,4,5,6,7,8,9,10};
       
       System.out.println(search(A, 5, 0, A.length-1));
	}
	static int search(int[] A,int target, int s, int e) {
	   if(s>e) return -1;
	   
	   int m = s+(e-s)/2 ;
	   
	   if(A[m]== target) return m;
	   
	   if(A[m]>target) return search(A,target, s, m-1);
	   
	   if(A[m]<target) return search(A,target, m+1, e);
	   
	return m;
	}
}
