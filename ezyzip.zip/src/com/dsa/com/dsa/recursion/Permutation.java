package com.dsa.recursion;
import java.util.*;
public class Permutation {

	public static void main(String[] args) {
		int[] A = {1,2,3};
		int n = A.length ;
	   ArrayList<ArrayList<Integer>> ans = new ArrayList() ;
	     solve(ans,A,0) ;
		System.out.print(ans) ;	   
	}
	static void solve(ArrayList<ArrayList<Integer>> ans,int[] A, int idx)
	{
		if(idx == A.length-1)
		{
			ArrayList<Integer> a = new ArrayList();
			for(int i=0; i<A.length; i++)
               a.add(A[i]);
			ans.add(a);
		}
		for(int i=idx; i<A.length; i++)
		{
			swap( A,i, idx) ;
			//System.out.println(A[idx]+" ");
			solve(ans,A,idx+1) ;
			//System.out.print(A[idx]+" ");
			swap(A, i, idx) ;
			//System.out.print(A[idx]+"  ");
		}
	}
	static void swap(int[] A,int a,int b)
	{
		int temp = A[a];
		  A[a] = A[b];
		  A[b] = temp;
	}

}

//
//Shivam Pradhan
//  11:14 PM
//// ABC
//3 letters, now in the next recursice we will have 2 letters, we will have 1 letter.
//   CBA   
//       A => BC => AB => C => ABC
//                  AC => B => ACB
//       B => AC => BA => C => BAC
//                  BC => A => BCA
//       C => BA => CB => A => CBA
//                  CA => B => CAB
//                  exhausted all our chpoices, recusrion stops.
