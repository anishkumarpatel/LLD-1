package com.dsa.stack;
import java.util.*;
public class MaximumRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public int solve2(int[][] A) {
        int r = A.length;
        int c = A[0].length ;
        int[] curRow = A[0];
        int max = largestRectangleArea(curRow);

        for(int i=1; i<r; i++){
            for(int j=0; j<c; j++){
                if(A[i][j] == 1)
                 curRow[j] += 1;
                else
                curRow[j] = 0;
            }
            max = Math.max(largestRectangleArea(curRow), max);
        }
        return max ;
    }
    public int largestRectangleArea3(int[] A) {
        int n = A.length ;
        int area = 0;

           
        for(int i=0; i<n; i++){
            int left = i;
            int right = i;

            while(left >=0 && A[left]>=A[i]) left--;

            while(right <n && A[right]>=A[i]) right++;

            area = Math.max(area,(right-left-1)*A[i]) ;
        }
        return area ;
    }
	 public int solve(int[][] A) {
	        int r = A.length;
	        int c = A[0].length ;
	        int[] curRow = A[0];
	        int max = largestRectangleArea(curRow);

	        for(int i=1; i<r; i++){
	            for(int j=0; j<c; j++){
	                if(A[i][j] == 1)
	                 curRow[j] += 1;
	                else
	                curRow[j] = 0;
	            }
	            max = Math.max(largestRectangleArea(curRow), max);
	        }
	        return max ;
	    }
	 
	     public int largestRectangleArea1(int[] A) { // optimised
	        int n = A.length ;
	        int[] psl = prevSmaller(A);
	        int[] nsr = nextSmaller(A);
	int area = 0;
	        for(int i=0; i<n; i++){
	            int width = nsr[i] - psl[i] - 1;

	            area = Math.max(area,width*A[i]);
	        }
	        return area ;
	    }
	    int[] prevSmaller(int[] A){
	        int n = A.length ;
	        int[] result = new int[n];
	        Stack<Integer> s = new Stack();

	        for(int i=0; i<n; i++){
	             while(!s.empty() && A[s.peek()] >= A[i] )
	               s.pop();

	            if(s.empty()) result[i] = -1;
	          else
	             result[i] = s.peek() ;
	            s.push(i);
	        }
	        return result ;
	    }
	     int[] nextSmaller(int[] A){
	        int n = A.length ;
	        int[] result = new int[n];
	        Stack<Integer> s = new Stack();

	        for(int i=n-1; i>=0; i--){
	             while(!s.empty() && A[s.peek()] >= A[i] )
	               s.pop();

	            if(s.empty()) result[i] = n;
	          else
	             result[i] = s.peek() ;
	            s.push(i);
	        }
	        return result ;
	    }
	public int brute1(int[][] A) {
        int r = A.length;
        int c = A[0].length ;
        int[] curRow = A[0];
        int max = largestRectangleArea(curRow);

        for(int i=1; i<r; i++){
            for(int j=0; j<c; j++){
                if(A[i][j] == 1)
                 curRow[j] += 1;
                else
                curRow[j] = 0;
            }
            max = Math.max(largestRectangleArea(curRow), max);
        }
        return max ;
    }
    public int largestRectangleArea(int[] A) {
        int n = A.length;

        int max = Integer.MIN_VALUE ;

        for(int s = 0 ; s<n; s++)
         for(int e=s; e<n; e++)
          max = Math.max(max,subArray(A,s,e));

        return max ;
    }
    int subArray(int[] A,int s, int e){
        int min = Integer.MAX_VALUE ;

        for(int k=s; k<=e; k++)
         min = Math.min(min,A[k]) ;

         return min*(e-s+1) ;
    }
}

//Given a 2D binary matrix of integers A containing 0's and 1's of size N x M.
//
//Find the largest rectangle containing only 1's and return its area.
//
//Note: Rows are numbered from top to bottom and columns are numbered from left to right.
//
//
//Input Format
//
//The only argument given is the integer matrix A.
//Output Format
//
//Return the area of the largest rectangle containing only 1's.
//Constraints
//
//1 <= N, M <= 1000
//0 <= A[i] <= 1
//For Example
//
//Input 1:
//    A = [   [0, 0, 1]
//            [0, 1, 1]
//            [1, 1, 1]   ]
//Output 1:
//    4
//
//Input 2:
//    A = [   [0, 1, 0, 1]
//            [1, 0, 1, 0]    ]
//Output 2:
//    1
