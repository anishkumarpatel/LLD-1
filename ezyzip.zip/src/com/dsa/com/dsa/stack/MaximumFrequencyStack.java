package com.dsa.stack;

import java.util.*;

public class MaximumFrequencyStack {

	public static void main(String[] args) {
		int[][] A = {
		            {1, 5},
		                    {1, 7},
		                    {1, 5},
		                    {1, 7},
		                    {1, 4},
		                    {1, 5},
		                    {2, 0},
		                    {2, 0},
		                    {2, 0},
		                    {2, 0}  };
		
		int[] B = solveA(A) ;
		for(int a : B )
			System.out.print(a+" ");
	}

	static int[] solveA(int[][] A) {
		HashMap<Integer, Stack<Integer>> freStack = new HashMap();
		HashMap<Integer, Integer> map = new HashMap();
		int max = 0;
		int[] outPut = new int[A.length];

		for (int i = 0; i < A.length; i++) {
			int a = A[i][0];
			if (a == 1) {
				int b = A[i][1];
				int fre = map.getOrDefault(b, 0) + 1;
				map.put(b, fre);

				max = Math.max(max, fre);

				if (freStack.get(fre) == null) {
					Stack<Integer> temp = new Stack();
					temp.push(b);
					freStack.put(fre, temp);
				} else {
					Stack<Integer> temp = freStack.get(fre);
					temp.push(b);
				}
				outPut[i] = -1;
			} else {
				Stack<Integer> temp = freStack.get(max);
				int x = temp.pop();
				outPut[i] = x;
				map.put(x, map.get(x) - 1);
				if (temp.empty())
					max--;
			}
		}
		return outPut;
	}
}

//Problem Description
//You are given a matrix A of size N x 2 which represents different operations.
//Assume initially you have a stack-like data structure you have to perform operations on it.
//
//Operations are of two types:
//
//1 x: push an integer x onto the stack and return -1.
//
//2 0: remove and return the most frequent element in the stack.
//
//If there is a tie for the most frequent element, the element closest to the top of the stack is removed and returned.
//
//A[i][0] describes the type of operation to be performed. A[i][1] describe the element x or 0 corresponding to the operation performed.
//
//
//
//Problem Constraints
//1 <= N <= 100000
//
//1 <= A[i][0] <= 2
//
//0 <= A[i][1] <= 109
//
//
//
//Input Format
//The only argument given is the integer array A.
//
//
//
//Output Format
//Return the array of integers denoting the answer to each operation.
//
//
//
//Example Input
//Input 1:
//
//A = [
//            [1, 5]
//            [1, 7]
//            [1, 5]
//            [1, 7]
//            [1, 4]
//            [1, 5]
//            [2, 0]
//            [2, 0]
//            [2, 0]
//            [2, 0]  ]
//Input 2:
//
// A =  [   
//        [1, 5]
//        [2, 0]
//        [1, 4]   ]
//
//
//Example Output
//Output 1:
//
// [-1, -1, -1, -1, -1, -1, 5, 7, 5, 4]
//Output 2:
//
// [-1, 5, -1]
//
//
//Example Explanation
//Explanation 1:
//
// Just simulate given operations.
//Explanation 2:
//
// Just simulate given operations.
