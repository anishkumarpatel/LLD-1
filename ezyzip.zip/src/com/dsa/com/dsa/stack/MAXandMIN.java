package com.dsa.stack;
import java.util.*;
public class MAXandMIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	 public int optimised(int[] A) {
	        int mod = 1000*1000*1000 + 7 ;
	          int n = A.length ;
	        int[] prevSmall = prevSmallIndex(A);
	        int[] preGreater = prevGreaterIndex(A);      
	        int[] nextSmall = nextSmallerIndex(A);  
	        int[] nextGreat = nextGreaterIndex(A);
	    
	        long sum = 0;

	        for(int i=0; i<A.length; i++){
	            int p1 = prevSmall[i] ;
	            int p2 =  nextSmall[i];
	            long prodMin = (1l*(i-p1)*(p2-i))%mod ;
	            long minContribution = (prodMin*A[i])%mod ;

	            int p3 = preGreater[i] ;
	            int p4 = nextGreat[i] ;
	            long prdMax = (1l*(i-p3)*(p4-i))%mod;
	            long maxContribution = (prdMax*A[i])%mod ;

	            sum = ( sum + maxContribution - minContribution + mod )% mod  ;
	       //     sum = sum%mod + (maxContribution-minContribution)%mod ;

	            sum = sum%mod ;
	        }
	    return (int)(sum%mod) ;
	    }
	    int[] prevSmallIndex(int[] A){
	        int n = A.length ;
	        int[] result = new int[n] ;
	        Stack<Integer> stack = new Stack() ;

	        for(int i=0; i<n; i++){
	            while(!stack.empty() && A[stack.peek()] >= A[i] )
	              stack.pop() ;
	            
	            if(stack.empty())
	             result[i] = -1;
	            else
	             result[i] = stack.peek();
	            stack.push(i) ;
	        }
	        return result ;
	    }
	    int[] prevGreaterIndex(int[] A){
	        int n = A.length ;
	        int[] result = new int[n] ;
	        Stack<Integer> stack = new Stack() ;

	        for(int i=0; i<n; i++){
	            while(!stack.empty() && A[stack.peek()] <= A[i] )
	              stack.pop() ;
	            
	            if(stack.empty())
	             result[i] = -1;
	            else
	             result[i] = stack.peek();
	            stack.push(i) ;
	        }
	        return result ;
	    }
	    int[] nextGreaterIndex(int[] A){
	        int n = A.length ;
	        int[] result = new int[n] ;
	        Stack<Integer> stack = new Stack() ;

	        for(int i=n-1; i>=0; i--){
	            while(!stack.empty() && A[stack.peek()] <= A[i] )
	              stack.pop() ;
	            
	            if(stack.empty())
	             result[i] = n;
	            else
	             result[i] = stack.peek();
	            stack.push(i) ;
	        }
	        return result ;
	    }
	     int[] nextSmallerIndex(int[] A){
	        int n = A.length ;
	        int[] result = new int[n] ;
	        Stack<Integer> stack = new Stack() ;

	        for(int i=n-1; i>=0; i--){
	            while(!stack.empty() && A[stack.peek()] >= A[i] )
	              stack.pop() ;
	            
	            if(stack.empty())
	             result[i] = n;
	            else
	             result[i] = stack.peek();
	            stack.push(i) ;
	        }
	        return result ;
	    }
	public int solveBrute2(int[] A) {
        int n = A.length;
        long sum = 0;
        int mod = 1000*1000*1000+7 ;

        for(int i=0; i<n; i++){
            int max= A[i];
            int min = A[i];
            for(int j=i; j<n; j++){
                max = Math.max(max,A[j]);
                min = Math.min(min,A[j]);
                sum = (sum + max - min + mod)%mod;
            }
        }
        return (int)sum ;
    }
	public int solvebrute1(int[] A) {
        int n = A.length ;
        int mod = 1000000007 ;
        long sum = 0;
        for(int s=0; s<n; s++)
         for(int e=s; e<n; e++)
          {
              sum = (sum + subArray(A,s,e) + mod)% mod ;
          }

        return (int)sum;
    }
    long subArray(int[] A, int s,int e){
        long max=A[s];
        long min = A[e];

        for(int k=s; k<=e; k++){
            max = Math.max(max,A[k]);
            min = Math.min(min,A[k]);
        }
        return (max - min) ;
    }
}


//Problem Description
//Given an array of integers A.
//
//value of a array = max(array) - min(array).
//
//Calculate and return the sum of values of all possible subarrays of A modulo 109+7.
//
//
//
//Problem Constraints
//1 <= |A| <= 100000
//
//1 <= A[i] <= 1000000
//
//
//
//Input Format
//The first and only argument given is the integer array A.
//
//
//
//Output Format
//Return the sum of values of all possible subarrays of A modulo 109+7.
//
//
//
//Example Input
//Input 1:
//
// A = [1]
//Input 2:
//
// A = [4, 7, 3, 8]
//
//
//Example Output
//Output 1:
//
// 0
//Output 2:
//
// 26
//
//
//Example Explanation
//Explanation 1:
//
//Only 1 subarray exists. Its value is 0.
//Explanation 2:
//
//value ( [4] ) = 4 - 4 = 0
//value ( [7] ) = 7 - 7 = 0
//value ( [3] ) = 3 - 3 = 0
//value ( [8] ) = 8 - 8 = 0
//value ( [4, 7] ) = 7 - 4 = 3
//value ( [7, 3] ) = 7 - 3 = 4
//value ( [3, 8] ) = 8 - 3 = 5
//value ( [4, 7, 3] ) = 7 - 3 = 4
//value ( [7, 3, 8] ) = 8 - 3 = 5
//value ( [4, 7, 3, 8] ) = 8 - 3 = 5
//sum of values % 10^9+7 = 26