package com.dsa.stack;
import java.util.* ;
class Solution {
    Stack<Integer> stack = new Stack() ;
    Stack<Integer> minStack = new Stack() ;
    public void push(int x) {
        stack.push(x);

        if(minStack.empty())
          minStack.push(x);
        else
          if(x <= minStack.peek())
          minStack.push(x) ;
    }

    public void pop() {
      if(stack.empty()) return ;

       int a = stack.pop() ; 
       if(a == minStack.peek())
        minStack.pop() ; 
    }

    public int top() {
        if(stack.empty()) return -1 ;

        return stack.peek() ;
    }

    public int getMin() {
       if(minStack.empty()) return -1;

      return minStack.peek() ;   
    }
}
public class MinStack {
	ArrayList<Integer> stack = new ArrayList() ;
    ArrayList<Integer> getMinStack = new ArrayList() ;
    int min = Integer.MAX_VALUE ;
    public void push(int x) {
        stack.add(x);
        min = Math.min(x,min);
        getMinStack.add(min) ;
    }

    public void pop() {
          if(stack.isEmpty()) return ;
        stack.remove(stack.size()-1) ;
        getMinStack.remove(getMinStack.size()-1) ;
           if(getMinStack.size() != 0)
        min = getMinStack.get(getMinStack.size()-1) ;
        else
        min =  Integer.MAX_VALUE;
    }

    public int top() {
       if(stack.isEmpty()) return -1;
       else
        return stack.get(stack.size()-1);
    }

    public int getMin() {
      if(getMinStack.isEmpty()) return -1 ;

   //  return getMinStack.get(getMinStack.size()-1) ;
      return min ;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}

//Q4. Min Stack
//Solved
//character backgroundcharacter
//Stuck somewhere?
//Ask for help from a TA and get it resolved.
//Get help from TA.
//Problem Description
//
//Design a stack that supports push, pop, top, and retrieve the minimum element in constant time.
//push(x) -- Push element x onto stack.
//pop() -- Removes the element on top of the stack.
//top() -- Get the top element.
//getMin() -- Retrieve the minimum element in the stack.
//NOTE:
//All the operations have to be constant time operations.
//getMin() should return -1 if the stack is empty.
//pop() should return nothing if the stack is empty.
//top() should return -1 if the stack is empty.
//Problem Constraints
//
//1 <= Number of Function calls <= 107
//Input Format
//
//Functions will be called by the checker code automatically.
//Output Format
//
//Each function should return the values as defined by the problem statement.
//Example Input
//
//Input 1:
//push(1)
//push(2)
//push(-2)
//getMin()
//pop()
//getMin()
//top()
//Input 2:
//getMin()
//pop()
//top()
//Example Output
//
//Output 1:
// -2 1 2
//Output 2:
// -1 -1
//Example Explanation
//
//Explanation 1:
//Let the initial stack be : []
//1) push(1) : [1]
//2) push(2) : [1, 2]
//3) push(-2) : [1, 2, -2]
//4) getMin() : Returns -2 as the minimum element in the stack is -2.
//5) pop() : Return -2 as -2 is the topmost element in the stack.
//6) getMin() : Returns 1 as the minimum element in stack is 1.
//7) top() : Return 2 as 2 is the topmost element in the stack.
//Explanation 2:
//Let the initial stack be : []
//1) getMin() : Returns -1 as the stack is empty.
//2) pop() :  Returns nothing as the stack is empty.
//3) top() : Returns -1 as the stack is empty.
//See Expected Output