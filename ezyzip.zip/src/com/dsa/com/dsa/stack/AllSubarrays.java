package com.dsa.stack;
import java.util.*;
public class AllSubarrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public int solve(int[] A) {
        int n= A.length ;
        int res = 0;
       Stack<Integer> stack = new Stack() ;

       for(int i=0; i<n; i++){
           while(!stack.empty() && stack.peek() <= A[i])
            res = Math.max( A[i]^stack.pop() , res ) ;

            if(!stack.empty()) res = Math.max(res , A[i]^stack.peek());

            stack.push(A[i]);
       }
       return res ;
    }
	public int solveBrute(int[] A) {
        int n = A.length ;
        int max = Integer.MIN_VALUE ;

        for(int start=0; start<n; start++){
            for(int end = start; end<n; end++){
                if(end-start+1 > 1)
                max = Math.max(max, subArray(A,start,end)) ;
            }
        }
        return max ;
    }
    int subArray(int[] A, int s, int e ){
        int max = Integer.MIN_VALUE;

        for(int k=s; k<=e; k++)
          max = Math.max(A[k],max) ;
        
        int secMax = Integer.MIN_VALUE ;
        
        for(int k=s; k<=e; k++)
          if(A[k] == max) continue ;
        else
        if(A[k]> secMax)
         secMax = A[k];

       if(secMax == Integer.MIN_VALUE) return 0;
       
        return max ^ secMax ;
    }

}

//Problem Description
//Given an integer array A of size N. You have to generate it's all subarrays having a size greater than 1.
//
//Then for each subarray, find Bitwise XOR of its maximum and second maximum element.
//
//Find and return the maximum value of XOR among all subarrays.



//Problem Constraints
//2 <= N <= 105
//
//1 <= A[i] <= 107
//
//
//
//Input Format
//The only argument is an integer array A.
//
//
//
//Output Format
//Return an integer, i.e., the maximum value of XOR of maximum and 2nd maximum element among all subarrays.
//
//
//
//Example Input
//Input 1:
//
// A = [2, 3, 1, 4]
//Input 2:
//
// A = [1, 3]
//
//
//Example Output
//Output 1:
//
// 7
//Outnput 2:
//
// 2
//
//
//Example Explanation
//Explanation 1:
//
// All subarrays of A having size greater than 1 are:
// Subarray            XOR of maximum and 2nd maximum no.
// 1. [2, 3]           1
// 2. [2, 3, 1]        1
// 3. [2, 3, 1, 4]     7
// 4. [3, 1]           2
// 5. [3, 1, 4]        7
// 6. [1, 4]           5
// So maximum value of Xor among all subarrays is 7.
//Explanation 2:
//
// Only subarray is [1, 3] and XOR of maximum and 2nd maximum is 2.