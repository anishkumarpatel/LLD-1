package com.dsa.stack;
import java.util.*;
public class LargestRectangleinHistogram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	 public int optimised(int[] A) {
	        int n = A.length ;
	        int[] psl = prevSmaller(A);
	        int[] nsr = nextSmaller(A);
	int area = 0;
	        for(int i=0; i<n; i++){
	            int width = nsr[i] - psl[i] - 1;

	            area = Math.max(area,width*A[i]);
	        }
	        return area ;
	    }
	    int[] prevSmaller(int[] A){
	        int n = A.length ;
	        int[] result = new int[n];
	        Stack<Integer> s = new Stack();

	        for(int i=0; i<n; i++){
	             while(!s.empty() && A[s.peek()] >= A[i] )
	               s.pop();

	            if(s.empty()) result[i] = -1;
	          else
	             result[i] = s.peek() ;
	            s.push(i);
	        }
	        return result ;
	    }
	     int[] nextSmaller(int[] A){
	        int n = A.length ;
	        int[] result = new int[n];
	        Stack<Integer> s = new Stack();

	        for(int i=n-1; i>=0; i--){
	             while(!s.empty() && A[s.peek()] >= A[i] )
	               s.pop();

	            if(s.empty()) result[i] = n;
	          else
	             result[i] = s.peek() ;
	            s.push(i);
	        }
	        return result ;
	    }
	public int largestRectangleArea1(int[] A) {
        int n = A.length ;
        int area = 0;

           
        for(int i=0; i<n; i++){
            int left = i;
            int right = i;

            while(left >=0 && A[left]>=A[i]) left--;

            while(right <n && A[right]>=A[i]) right++;

            area = Math.max(area,(right-left-1)*A[i]) ; 
        }
        return area ;
    }
	public int largestRectangleArea(int[] A) {  // brute force approach
        int n = A.length;

        int max = Integer.MIN_VALUE ;

        for(int s = 0 ; s<n; s++)
         for(int e=s; e<n; e++)
          max = Math.max(max,subArray(A,s,e));

        return max ;
    }
    int subArray(int[] A,int s, int e){
        int min = Integer.MAX_VALUE ;

        for(int k=s; k<=e; k++)
         min = Math.min(min,A[k]) ;

         return min*(e-s+1) ;
    }
}
