package com.dsa.stack;

import java.util.ArrayList;
import java.util.Scanner;

public class CustomStack {
	static ArrayList<Integer> list = new ArrayList<>();
	
	static int push(int data) {
		list.add(data);
		return data ;
	}
	static int pop() {
		int n = list.size();
		int a = list.get(n-1);
		list.remove(n-1) ;
		return a ;
	}
	static int peek() {
		int n = list.size();
		int a = list.get(n-1);
		return a ;
	}
	static boolean isEmpty() {
		int n = list.size();
		if(n-1 == 0) return true;
		else
			return false ;
	} 
	public static void main(String[] args) {
		
	   push(1); push(2); push(3); push(4); push(5);
	   System.out.println(peek());
	   System.out.println(list);
	}
}
