package com.dsa;

public class MinimumSwap {

	public static void main(String[] args) {

	}

	static int solve(int[] A, int B) {
		int num = A.length;
		// brute force
		int cnt = 0;
		for (int i = 0; i < num; i++) {
			if (A[i] <= B) {
				cnt++;
			}
		}
		// cnt --> 3
		int ans = 10000000;
		int y = 0;
		for (int i = 0; i <= cnt - 1; i++) {
			if (A[i] > B) {
				y++;
			}
		}
		ans = Math.min(ans, y);
		for (int i = cnt; i <= num - 1; i++) {
			int start = i - cnt;
			if (A[i] > B) {
				y++;
			}
			if (A[start] > B) {
				y--;
			}
			ans = Math.min(ans, y);
			// int y = 0 ;
			// for(int j = i ; j <= i+cnt-1 ; j++) {
			// if ( A[j] > B ) {
			// y++;
			// }
			// }
			// ans = Math.min(ans , y);
		}
		return ans;
	}

	static int solve1(int[] A, int B) {
		int num = A.length;
		// brute force
		int cnt = 0;
		for (int i = 0; i < num; i++) {
			if (A[i] <= B) {
				cnt++;
			}
		}
		// cnt --> 3
		int ans = 10000000;
		for (int i = 0; i <= num - cnt; i++) {
			int y = 0;
			for (int j = i; j <= i + cnt - 1; j++) {
				if (A[j] > B) {
					y++;
				}
			}
			ans = Math.min(ans, y);
		}
		return ans;
	}
}
