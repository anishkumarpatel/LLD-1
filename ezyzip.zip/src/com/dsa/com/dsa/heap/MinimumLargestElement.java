package com.dsa.heap;

import java.util.*;

public class MinimumLargestElement {
	public int optimised(int[] A, int B) {
		int n = A.length;
		int[] curState = new int[n];
		PriorityQueue<Pair> pq = new PriorityQueue<>((a, b) -> a.val - b.val);

		for (int i = 0; i < n; i++) {
			curState[i] = A[i];
			Pair p = new Pair(2 * A[i], i);
			pq.add(p);
		}
		while (B-- > 0) {
			Pair p = pq.poll();
			// curState[p.idx] += A[p.idx]; top mistake
			curState[p.idx] = p.val;
			p = new Pair(curState[p.idx] + A[p.idx], p.idx);
			pq.add(p);
		}
		int max = Integer.MIN_VALUE;
		for (int i = 0; i < n; i++)
			max = Math.max(max, curState[i]);
		return max;
	}
}

class Pair {
	int val;
	int idx;

	Pair(int val, int idx) {
		this.val = val;
		this.idx = idx;
	}

	public int brute(int[] A, int B) {
		int n = A.length;
		int[] res = new int[n];
		int ans = Integer.MIN_VALUE;

		for (int i = 0; i < n; i++) {
			res[i] = A[i];
			ans = Math.max(ans, A[i]);
		}

		for (int i = 0; i < B; i++) {
			int min = A[0] + res[0];
			int j = 0;
			for (int k = 0; k < n; k++) {
				if (min > A[k] + res[k]) {
					min = A[k] + res[k];
					j = k;
				}
			}
			res[j] += A[j];
			ans = Math.max(ans, res[j]);
		}
		return ans;
	}
}

/*
 * Problem Description Given an array A of N numbers, you have to perform B
 * operations. In each operation, you have to pick any one of the N elements and
 * add the original value(value stored at the index before we did any
 * operations) to its current value. You can choose any of the N elements in
 * each operation.
 * 
 * Perform B operations in such a way that the largest element of the modified
 * array(after B operations) is minimized. Find the minimum possible largest
 * element after B operations.
 * 
 * 
 * 
 * Problem Constraints 1 <= N <= 106 0 <= B <= 105 -105 <= A[i] <= 105
 * 
 * 
 * 
 * Input Format The first argument is an integer array A. The second argument is
 * an integer B.
 * 
 * 
 * 
 * Output Format Return an integer denoting the minimum possible largest element
 * after B operations.
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * A = [1, 2, 3, 4] B = 3 Input 2:
 * 
 * A = [5, 1, 4, 2] B = 5
 * 
 * 
 * Example Output Output 1:
 * 
 * 4 Output 2:
 * 
 * 5
 * 
 * 
 * Example Explanation Explanation 1:
 * 
 * Apply operation on element at index 0, the array would change to [2, 2, 3, 4]
 * Apply operation on element at index 0, the array would change to [3, 2, 3, 4]
 * Apply operation on element at index 0, the array would change to [4, 2, 3, 4]
 * Minimum possible largest element after 3 operations is 4. Explanation 2:
 * 
 * Apply operation on element at index 1, the array would change to [5, 2, 4, 2]
 * Apply operation on element at index 1, the array would change to [5, 3, 4, 2]
 * Apply operation on element at index 1, the array would change to [5, 4, 4, 2]
 * Apply operation on element at index 1, the array would change to [5, 5, 4, 2]
 * Apply operation on element at index 3, the array would change to [5, 5, 4, 4]
 * Minimum possible largest element after 5 operations is 5.
 */
