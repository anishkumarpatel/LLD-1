package com.dsa.heap;

import java.util.*;

public class SpecialMedian {
	public int solve(int[] A) { // optimsed
		int n = A.length;
		PriorityQueue<Integer> minHeap = new PriorityQueue();
		PriorityQueue<Integer> maxHeap = new PriorityQueue(Collections.reverseOrder());

		for (int i = 1; i < n; i++) {
			if (maxHeap.size() > 0 && A[i - 1] > maxHeap.peek())
				minHeap.add(A[i - 1]);
			else
				maxHeap.add(A[i - 1]);

			if (maxHeap.size() > minHeap.size() + 1)
				minHeap.add(maxHeap.poll());
			else if (minHeap.size() > maxHeap.size())
				maxHeap.add(minHeap.poll());

			if (maxHeap.size() == minHeap.size()) {
				int a = maxHeap.peek();
				int b = minHeap.peek();
				float f = (a + b) / 2f;
				if (f == A[i])
					return 1;
			} else if (maxHeap.peek() == A[i])
				return 1;
		}

		minHeap = new PriorityQueue();
		maxHeap = new PriorityQueue(Collections.reverseOrder());

		for (int i = n - 2; i >= 0; i--) {
			if (maxHeap.size() > 0 && A[i + 1] > maxHeap.peek())
				minHeap.add(A[i + 1]);
			else
				maxHeap.add(A[i + 1]);

			if (maxHeap.size() > minHeap.size() + 1)
				minHeap.add(maxHeap.poll());
			else if (minHeap.size() > maxHeap.size())
				maxHeap.add(minHeap.poll());

			if (maxHeap.size() == minHeap.size()) {
				int a = maxHeap.peek();
				int b = minHeap.peek();
				float f = (a + b) / 2f;
				if (f == A[i])
					return 1;
			} else if (maxHeap.peek() == A[i])
				return 1;
		}

		return 0;
	}

	public int brute(int[] A) {
		int n = A.length;
		for (int i = 1; i < n; i++) {//
			int[] temp = new int[i];

			for (int j = 0; j < i; j++)
				temp[j] = A[j];
			Arrays.sort(temp);

			// For A[0] consider only the median of elements [A[1], A[2], ..., A[N-1]] (as
			// there are no elements to the left of it)

			int size = temp.length;

			if (size % 2 == 0) {
				int a = temp[size / 2];
				int b = temp[size / 2 - 1];
				float f = (a + b) / 2f;
				if (f == A[i])
					return 1;
			} else {
				int a = temp[size / 2];
				if (a == A[i])
					return 1;
			}
		}
		for (int i = n - 2; i >= 0; i--) {//
			int[] temp = new int[n - i - 1];
			// For A[N-1] consider only the median of elements [A[0], A[1], ...., A[N-2]]
			int idx = 0;
			for (int j = n - 1; j > i; j--)
				temp[idx++] = A[j];
			Arrays.sort(temp);

			int size = temp.length;

			if (size % 2 == 0) {

				int a = temp[size / 2];
				int b = temp[size / 2 - 1];
				float f = (a + b) / 2f;
				if (f == A[i])
					return 1;
			} else {
				int a = temp[size / 2];
				if (a == A[i])
					return 1;
			}
		}
		return 0;
	}
}

/*
 * Problem Description You are given an array A containing N numbers. This array
 * is called special if it satisfies one of the following properties:
 * 
 * There exists an element A[i] in the array such that A[i] is equal to the
 * median of elements [A[0], A[1], ...., A[i-1]] There exists an element A[i] in
 * the array such that A[i] is equal to the median of elements [A[i+1], A[i+2],
 * ...., A[N-1]] The Median is the middle element in the sorted list of
 * elements. If the number of elements is even then the median will be (sum of
 * both middle elements) / 2.
 * 
 * Return 1 if the array is special else return 0.
 * 
 * NOTE:
 * 
 * Do not neglect decimal point while calculating the median For A[0] consider
 * only the median of elements [A[1], A[2], ..., A[N-1]] (as there are no
 * elements to the left of it) For A[N-1] consider only the median of elements
 * [A[0], A[1], ...., A[N-2]]
 * 
 * 
 * Problem Constraints 1 <= N <= 1000000. A[i] is in the range of a signed
 * 32-bit integer.
 * 
 * 
 * 
 * Input Format The first and only argument is an integer array A.
 * 
 * 
 * 
 * Output Format Return 1 if the given array is special else return 0.
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * A = [4, 6, 8, 4] Input 2:
 * 
 * A = [2, 7, 3, 1]
 * 
 * 
 * Example Output Output 1:
 * 
 * 1 Output 2:
 * 
 * 0
 * 
 * 
 * Example Explanation Explantion 1:
 * 
 * Here, 6 is equal to the median of [8, 4]. Explanation 2:
 * 
 * No element satisfies any condition.
 */
