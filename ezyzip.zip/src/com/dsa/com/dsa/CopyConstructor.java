package com.dsa;

public class CopyConstructor {

	public static void main(String[] args) {
		Test11 t = new Test11();

		System.out.println("t.x " + t.x);
		System.out.println("t.y " + t.y);

		t.x = 888;
		t.y = 999;
		System.out.println("updated t.x " + t.x);
		System.out.println("updated t.y " + t.y);

		Test11 t1 = new Test11(t);
		System.out.println("t1.x " + t1.x);
		System.out.println("t1.y " + t1.y);
	}
}

class Test11 {

	int x = 111;
	int y = 222;

	Test11() {
	}

	Test11(Test11 ref) // copy constructor
	{
		this.x = ref.x;
		this.y = ref.y;
	}

}