package com.dsa.traverse_link;

public class FlattenBinaryTreetoLinkedList {
	TreeNode next = new TreeNode(100);
	TreeNode head = next;

	public TreeNode flatten2(TreeNode a) { // brute force approach
		pre(a);
		return head.right;
	}

	void pre(TreeNode a) {
		if (a == null)
			return;

		next.right = new TreeNode(a.val);
		next = next.right;
		pre(a.left);
		pre(a.right);
	}

	public TreeNode flatten3(TreeNode a) {
		pre1(a);
		return prev;
	}

	TreeNode prev;

	void pre1(TreeNode A) {
		if (A == null)
			return;

		pre(A.right);
		pre(A.left);
		if (prev != null) {
			A.right = prev;
			A.left = null;
		}
		prev = A;
	}

	public TreeNode flatten1(TreeNode a) { // optimsed
		TreeNode cur = a;
		while (cur != null) {
			if (cur.left != null) {
				TreeNode rmtree = cur.left;
				while (rmtree.right != null)
					rmtree = rmtree.right;

				rmtree.right = cur.right;
				cur.right = cur.left;
				cur.left = null;
			}
			cur = cur.right;
		}
		return a;
	}
}
