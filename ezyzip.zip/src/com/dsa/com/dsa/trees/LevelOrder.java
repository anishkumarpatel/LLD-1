package com.dsa.trees;

import java.util.*;

/*
 Approach
 There are two ways to solve this problem.

Approach 1: Maintain a vector of size ‘depth’ of the tree. Do any tree traversals keep track of the current depth? Append the current element to vector[currentDepth]. Since we need stuff left to right, make sure the left subtree is visited before the right subtree ( Any traditional pre/post/inorder traversal should suffice ).

Approach 2: This is important. A lot of times, you’d be asked to do a traditional level order traversal. Or, to put informal words, a traversal where the extra memory used should be proportional to the nodes on a level rather than the depth of the tree. To do that, you need to make sure you are accessing all the nodes on a level before accessing the nodes next. This is a typical breadth-first search problem—queue FTW.
 
 Problem Description
Given a binary tree, return the level order traversal of its nodes' values. (i.e., from left to right, level by level).



Problem Constraints
1 <= number of nodes <= 105



Input Format
First and only argument is root node of the binary tree, A.



Output Format
Return a 2D integer array denoting the level order traversal of the given binary tree.



Example Input
Input 1:

    3
   / \
  9  20
    /  \
   15   7
Input 2:

   1
  / \
 6   2
    /
   3


Example Output
Output 1:

 [
   [3],
   [9, 20],
   [15, 7]
 ]
Output 2:

 [ 
   [1]
   [6, 2]
   [3]
 ]


Example Explanation
Explanation 1:

 Return the 2D array. Each row denotes the traversal of each level.



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A Binary Tree, -1 signifies a NULL child, For e.g 6 9 4 -1 -1 8 -1 -1 3 -1 -1
tree-icon
 
 */

public class LevelOrder {
	public ArrayList<ArrayList<Integer>> solve1(TreeNode A) {
		ArrayList<ArrayList<Integer>> ans = new ArrayList<>();

		Queue<TreeNode> q = new LinkedList<>();
		q.offer(A);

		while (!q.isEmpty()) {
			int size = q.size();
			ArrayList<Integer> a = new ArrayList<>();
			for (int i = 0; i < size; i++) {
				TreeNode cur = q.poll();
				a.add(cur.val);

				if (cur.left != null)
					q.offer(cur.left);

				if (cur.right != null)
					q.offer(cur.right);
			}
			ans.add(a);
		}
		return ans;
	}

	public ArrayList<ArrayList<Integer>> solve121(TreeNode A) {
		ArrayList<ArrayList<Integer>> ans = new ArrayList<>();
		Queue<TreeNode> q = new LinkedList<>();
		q.offer(A);
		q.offer(null);

		ArrayList<Integer> a = new ArrayList<>();
		while (!q.isEmpty()) {
			TreeNode cur = q.poll();
			if (cur == null) {
				ans.add(a);
				if (q.isEmpty())
					return ans;
				q.offer(null);
				a = new ArrayList<>();
				continue;
			}
			a.add(cur.val);
			if (cur.left != null)
				q.offer(cur.left);

			if (cur.right != null)
				q.offer(cur.right);
		}
		return ans;
	}

	public ArrayList<ArrayList<Integer>> levelOrder11(TreeNode A) { // brute
		ArrayList<ArrayList<Integer>> a = new ArrayList();

		for (int i = 1; i <= height(A); i++) {
			ArrayList<Integer> t = new ArrayList();
			a.add(levelO(A, i, t));
		}
		return a;
	}

	ArrayList<Integer> levelO(TreeNode A, int level, ArrayList<Integer> a) {
		if (A == null)
			return a;

		if (level == 1)
			a.add(A.val);
		else {
			levelO(A.left, level - 1, a);
			levelO(A.right, level - 1, a);
		}
		return a;
	}

	int height(TreeNode A) {
		if (A == null)
			return 0;

		return Math.max(height(A.left), height(A.right)) + 1;
	}

	public ArrayList<ArrayList<Integer>> solve(TreeNode A) {
		Queue<Pair> q = new LinkedList<>();
		Map<Integer, ArrayList<Integer>> map = new TreeMap<>();
		q.offer(new Pair(0, A));

		while (!q.isEmpty()) {
			Pair cur = q.poll();

			if (map.containsKey(cur.dis))
				map.get(cur.dis).add(cur.node.val);
			else {
				ArrayList<Integer> temp = new ArrayList<>();
				temp.add(cur.node.val);
				map.put(cur.dis, temp);

			}

			if (cur.node.left != null)
				q.offer(new Pair(cur.dis + 1, cur.node.left));

			if (cur.node.right != null)
				q.offer(new Pair(cur.dis + 1, cur.node.right));
		}
		ArrayList<ArrayList<Integer>> ans = new ArrayList<>();
		for (Map.Entry<Integer, ArrayList<Integer>> entry : map.entrySet())
			ans.add(entry.getValue());
		return ans;
	}

	class Pair {
		int dis;
		TreeNode node;

		Pair(int x, TreeNode y) {
			dis = x;
			node = y;
		}
	}
}
