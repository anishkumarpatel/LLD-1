package com.dsa.trees;

public class SymmetricOrMiror {
	public int isSymmetric(TreeNode A) {
		if (check(A, A))
			return 1;
		else
			return 0;
	}

	boolean check(TreeNode A, TreeNode B) {
		if (A == null && B == null)
			return true;

		if (A == null || B == null)
			return false;

		if (A.val != B.val)
			return false;

		boolean a = check(A.left, B.right);
		boolean b = check(A.right, B.left);

		if (a && b)
			return true;
		else
			return false;
		// return check(A.left,B.right) && check(A.right,B.left) ;
	}
}
