package com.dsa.trees;

/*
 Approach
 
 We will be using 2 stacks to solve this problem. One for the current layer and other one for the next layer. Also keep a flag which indicates the direction of traversal on any level.

You need to pop out the elements from current layer stack and depending upon the value of flag push the childs of current element in next layer stack. You should maintain the output sequence in the process as well. Remember to swap the stacks before next iteration.

When should you terminate this algorithm?
 
 Problem Description
Given a binary tree, return the zigzag level order traversal of its nodes values. (ie, from left to right, then right to left for the next level and alternate between).


Problem Constraints
1 <= number of nodes <= 105



Input Format
First and only argument is root node of the binary tree, A.



Output Format
Return a 2D integer array denoting the zigzag level order traversal of the given binary tree.



Example Input
Input 1:

    3
   / \
  9  20
    /  \
   15   7
Input 2:

   1
  / \
 6   2
    /
   3


Example Output
Output 1:

 [
   [3],
   [20, 9],
   [15, 7]
 ]
Output 2:

 [ 
   [1]
   [2, 6]
   [3]
 ]


Example Explanation
Explanation 1:

 Return the 2D array. Each row denotes the zigzag traversal of each level.



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A Binary Tree, -1 signifies a NULL child, For e.g 6 9 4 -1 -1 8 -1 -1 3 -1 -1
tree-icon
Enter Input Here
Arg 2: Multi Dimensional Array with Integers, For e.g [[2,3,6,7],[2,3,4,5]]
Enter Input Here

 
 */
import java.util.*;

public class ZigZagLevelOrderTraversalBT {
	/**
	 * Definition for binary tree class TreeNode { int val; TreeNode left; TreeNode
	 * right; TreeNode(int x) { val = x; left=null; right=null; } }
	 */
	public ArrayList<ArrayList<Integer>> zigzagLevelOrder122(TreeNode A) {

		Queue<TreeNode> q = new LinkedList<>();
		q.offer(A);
		int toggle = 0;
		ArrayList<ArrayList<Integer>> ans = new ArrayList<>();

		while (!q.isEmpty()) {
			int size = q.size();
			toggle = 1 - toggle;
			ArrayList<Integer> a = new ArrayList<>();
			for (int i = 0; i < size; i++) {
				TreeNode cur = q.poll();
				if (toggle == 1)
					a.add(cur.val);
				else
					a.add(cur.val);
				if (cur.left != null)
					q.offer(cur.left);
				if (cur.right != null)
					q.offer(cur.right);
			}

			if (toggle == 0)
				Collections.reverse(a);
			ans.add(a);
		}
		return ans;
	}

	public ArrayList<ArrayList<Integer>> zigzagLevelOrder1(TreeNode A) {
		ArrayList<ArrayList<Integer>> ans = new ArrayList();
		Queue<TreeNode> q = new LinkedList();
		q.add(A);
		int toggle = 0;

		while (!q.isEmpty()) {
			int size = q.size();
			toggle = 1 - toggle;
			ArrayList<Integer> a = new ArrayList();
			if (toggle == 1)
				for (int i = 0; i < size; i++) {
					TreeNode cur = q.poll();
					a.add(cur.val);

					if (cur.left != null)
						q.add(cur.left);

					if (cur.right != null)
						q.add(cur.right);
				}

			if (toggle == 0)
				for (int i = size - 1; i >= 0; i--) {
					TreeNode cur = q.poll();
					a.add(cur.val);
					if (cur.left != null)
						q.add(cur.left);

					if (cur.right != null)
						q.add(cur.right);
				}

			if (toggle == 0)
				Collections.reverse(a);
			ans.add(a);
		}
		return ans;
	}

	public ArrayList<ArrayList<Integer>> zigzagLevelOrder(TreeNode A) {
		Stack<TreeNode> stack1 = new Stack<>(), stack2 = new Stack<>();
		ArrayList<ArrayList<Integer>> zigzag = new ArrayList<>();
		if (A == null)
			return null;

		stack1.push(A);
		while (!stack1.isEmpty() || !stack2.isEmpty()) {
			ArrayList<Integer> level = new ArrayList<>();
			while (!stack1.isEmpty()) {
				TreeNode node = stack1.pop();
				level.add(node.val);
				if (node.left != null)
					stack2.push(node.left);
				if (node.right != null)
					stack2.push(node.right);
			}
			if (level.size() != 0)
				zigzag.add(level);
			level = new ArrayList<>();

			while (!stack2.isEmpty()) {
				TreeNode node = stack2.pop();
				level.add(node.val);
				if (node.right != null)
					stack1.push(node.right);
				if (node.left != null)
					stack1.push(node.left);
			}
			if (level.size() != 0)
				zigzag.add(level);
		}
		return zigzag;
	}

}
