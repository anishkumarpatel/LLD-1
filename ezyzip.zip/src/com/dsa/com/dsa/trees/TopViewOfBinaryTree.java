package com.dsa.trees;

/*
 Approach
 You need to return every node to be visible from the top.
In other words, it should be the leftmost or the rightmost till that level.
This can be found using a queue and modifying the level order
traversal algorithm. You may need to maintain the level of each
node along with the nodes themselves.
 
 Problem Description
Given a binary tree of integers denoted by root A. Return an array of integers representing the top view of the Binary tree.

The top view of a Binary Tree is a set of nodes visible when the tree is visited from the top.

Return the nodes in any order.



Problem Constraints
1 <= Number of nodes in binary tree <= 100000

0 <= node values <= 10^9



Input Format
First and only argument is head of the binary tree A.



Output Format
Return an array, representing the top view of the binary tree.



Example Input
Input 1:

 
            1
          /   \
         2    3
        / \  / \
       4   5 6  7
      /
     8 
Input 2:

 
            1
           /  \
          2    3
           \
            4
             \
              5


Example Output
Output 1:

 [1, 2, 4, 8, 3, 7]
Output 2:

 [1, 2, 3]


Example Explanation
Explanation 1:

Top view is described.
Explanation 2:

Top view is described.



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A Binary Tree, -1 signifies a NULL child, For e.g 6 9 4 -1 -1 8 -1 -1 3 -1 -1
tree-icon
 
 */

import java.util.*;

public class TopViewOfBinaryTree {
	class Pair {
		int dis;
		TreeNode node;

		Pair(int x, TreeNode y) {
			dis = x;
			node = y;
		}
	}

	public ArrayList<Integer> solve(TreeNode A) {

		Queue<Pair> q = new LinkedList<>();
		q.offer(new Pair(0, A));
		Map<Integer, Integer> map = new HashMap<>();
		while (!q.isEmpty()) {
			Pair cur = q.poll();
			int dis = cur.dis;
			int val = cur.node.val;
			if (!map.containsKey(dis))
				map.put(dis, val);

			if (cur.node.left != null)
				q.offer(new Pair(dis - 1, cur.node.left));

			if (cur.node.right != null)
				q.offer(new Pair(dis + 1, cur.node.right));
		}

		ArrayList<Integer> ans = new ArrayList<>();

		for (Map.Entry<Integer, Integer> entry : map.entrySet())
			ans.add(entry.getValue());
		return ans;
		
		// return new ArrayList<>(map.values()) ;
	}
}
