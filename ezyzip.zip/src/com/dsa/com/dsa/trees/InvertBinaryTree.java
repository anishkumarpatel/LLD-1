package com.dsa.trees;

public class InvertBinaryTree {
	public TreeNode invertTree(TreeNode root) {
		swap(root);

		return root;
	}

	void swap(TreeNode root) {
		if (root == null)
			return;

		swap(root.left);
		swap(root.right);

		TreeNode temp = root.left;
		root.left = root.right;
		root.right = temp;
	}
}
