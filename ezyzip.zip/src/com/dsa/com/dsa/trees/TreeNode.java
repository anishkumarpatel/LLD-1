package com.dsa.trees;
import java.util.*;
public class TreeNode {
	TreeNode left;
	TreeNode right;
	int val;
	
	TreeNode(int x){
		val = x;
		left = null;
		right = null;
	}
	public static void main(String... argds) {
		Deque<Integer> q = new ArrayDeque();
		q.offer(null);
		System.out.println(q);
	}
}
