package com.dsa.trees;

import java.util.*;

public class CommonNodesinTwoBST {
	public int solve11(TreeNode A, TreeNode B) {
		HashSet<Integer> s1 = new HashSet();
		inOrder(A, s1);
		HashSet<Integer> s2 = new HashSet();
		inOrder(B, s2);

		Iterator<Integer> itr = s1.iterator();
		int sum = 0;
		int mod = 1000 * 1000 * 1000 + 7;
		while (itr.hasNext()) {
			int x = itr.next();
			if (s2.contains(x)) {
				sum = (sum + x + mod) % mod;
				s2.remove(x);
			}
		}
		return sum;
	}

	void inOrder(TreeNode A, HashSet<Integer> s) {
		if (A == null)
			return;

		inOrder(A.left, s);

		s.add(A.val);

		inOrder(A.right, s);
	}

	public int solve(TreeNode A, TreeNode B) {
		Queue<TreeNode> q = new LinkedList();
		q.add(A);
		int sum = 0;
		int mod = 1000 * 1000 * 1000 + 7;
		while (!q.isEmpty()) {
			TreeNode temp = q.poll();
			if (temp != null) {
				if (check(B, temp.val))
					sum = (sum + temp.val + mod) % mod;

				q.add(temp.left);
				q.add(temp.right);
			}
		}
		return sum;
	}

	boolean check(TreeNode B, int val) {
		if (B == null)
			return false;

		if (B.val == val)
			return true;
		else if (B.val > val)
			return check(B.left, val);
		else
			return check(B.right, val);
	}
}
