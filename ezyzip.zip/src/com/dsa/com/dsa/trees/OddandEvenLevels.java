package com.dsa.trees;

/*
 Approach
 Use level Order traversal to calculate the sum of nodes at odd level and even level.

If the level is odd add the node value in the odd variable,
Else, add it in variable storing the sum of even levels.

After completing the traversal, return odd - even.
 
 Problem Description
Given a binary tree of integers. Find the difference between the sum of nodes at odd level and sum of nodes at even level.

NOTE: Consider the level of root node as 1.



Problem Constraints
1 <= Number of nodes in binary tree <= 100000

0 <= node values <= 109



Input Format
First and only argument is a root node of the binary tree, A



Output Format
Return an integer denoting the difference between the sum of nodes at odd level and sum of nodes at even level.



Example Input
Input 1:

        1
      /   \
     2     3
    / \   / \
   4   5 6   7
  /
 8 
Input 2:

        1
       / \
      2   10
       \
        4


Example Output
Output 1:

 10
Output 2:

 -7


Example Explanation
Explanation 1:

 Sum of nodes at odd level = 23
 Sum of ndoes at even level = 13
Explanation 2:

 Sum of nodes at odd level = 5
 Sum of ndoes at even level = 12



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A Binary Tree, -1 signifies a NULL child, For e.g 6 9 4 -1 -1 8 -1 -1 3 -1 -1
tree-icon
Enter Input Here

 
 */

import java.util.*;

public class OddandEvenLevels {

	public int solve(TreeNode A) {
		Queue<TreeNode> q = new LinkedList();
		int oddSum = 0;
		int evenSum = 0;
		q.add(A);
		int toggle = 0;

		while (!q.isEmpty()) {
			int size = q.size();

			toggle = 1 - toggle; // decide level for even & odd where root as odd then it should be alternate
									// level

			for (int i = 0; i < size; i++) {
				TreeNode cur = q.poll();

				if (toggle == 1)
					oddSum += cur.val;
				else
					evenSum += cur.val;

				if (cur.left != null)
					q.add(cur.left);

				if (cur.right != null)
					q.add(cur.right);

			}
		}
		return oddSum - evenSum;
	}

}
