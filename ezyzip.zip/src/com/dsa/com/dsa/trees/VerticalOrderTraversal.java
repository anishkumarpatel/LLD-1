package com.dsa.trees;
import java.util.*;
public class VerticalOrderTraversal {

	public static void main(String[] args) {
		
	}
	public ArrayList<ArrayList<Integer>> verticalOrderTraversal(TreeNode A) {
	       Map<Integer,ArrayList<Integer>> map = new TreeMap();
	        Queue<Pair> q = new LinkedList();
	         q.add(new Pair(0,A));

	         while(!q.isEmpty()){
	             Pair cur = q.poll();

	             if(map.containsKey(cur.distance))
	              map.get(cur.distance).add(cur.node.val);
	            else{
	                ArrayList<Integer> temp = new ArrayList();
	                 temp.add(cur.node.val) ;
	                map.put(cur.distance,temp);
	            }
	            if(cur.node.left != null) q.add(new Pair(cur.distance-1,cur.node.left));

	            if(cur.node.right != null) q.add(new Pair(cur.distance+1,cur.node.right));
	         }
	         ArrayList<ArrayList<Integer>> ans = new ArrayList();

	         for(Map.Entry<Integer, ArrayList<Integer>> entry : map.entrySet())
	                        ans.add(entry.getValue()) ;
	        return ans ;
	    }
	    class Pair{
	        int distance;
	        TreeNode node;
	        Pair(int x, TreeNode n){
	            distance = x;
	            node = n;
	        }
	    }

}
