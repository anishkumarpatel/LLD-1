package com.dsa.trees;
import java.util.*;
public class PostorderTraversal {
	 static ArrayList<Integer> postorderTraversal(TreeNode A) {// without recursion
	        Stack<TreeNode> s1 = new Stack();
	       ArrayList<Integer> a = new ArrayList();
	        s1.push(A);

	        while(!s1.isEmpty()){
	            TreeNode temp = s1.pop();
	              a.add(temp.val); 
	            if(temp.left != null) s1.push(temp.left);

	            if(temp.right != null) s1.push(temp.right);
	        }
	        Collections.reverse(a);
	      return a ;
	    }
	 ArrayList<Integer> a = new ArrayList();
	    public ArrayList<Integer> postorderTraversal1(TreeNode A) {

	        if(A == null) return a;

	        postorderTraversal(A.left);
	        postorderTraversal(A.right);
	        a.add(A.val);
	      return a ;
	    }
}
