package com.dsa.trees;

/*
 Approach
 We can clearly see that only one node will be visible for each level.

For each level the rightmost node will be visible.

So to get the answer we can simply find for each level whenever you encounters the last node on that level append it to the answer.

We can solve the problem using level order traversal.
We will store all the nodes from the right to left of a level in a queue. We will put a null value in the queue to mark the end of the current level.
For each level, the first value in the queue is the rightmost node. We push this node value to our answer.
Then we traverse and pop the remaining nodes of the same level and push the nodes of the next level in the queue.


 Problem Description
Given a binary tree of integers denoted by root A. Return an array of integers representing the right view of the Binary tree.

Right view of a Binary Tree is a set of nodes visible when the tree is visited from Right side.



Problem Constraints
1 <= Number of nodes in binary tree <= 100000

0 <= node values <= 10^9



Input Format
First and only argument is head of the binary tree A.



Output Format
Return an array, representing the right view of the binary tree.



Example Input
Input 1:

 
            1
          /   \
         2    3
        / \  / \
       4   5 6  7
      /
     8 
Input 2:

 
            1
           /  \
          2    3
           \
            4
             \
              5


Example Output
Output 1:

 [1, 3, 7, 8]
Output 2:

 [1, 3, 4, 5]


Example Explanation
Explanation 1:

Right view is described.
Explanation 2:

Right view is described.



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A Binary Tree, -1 signifies a NULL child, For e.g 6 9 4 -1 -1 8 -1 -1 3 -1 -1
tree-icon
Enter Input Here

 */

import java.util.* ;
public class LeftViewofBinaryTree {

	
	 public ArrayList<Integer> solve(TreeNode A) {
	        ArrayList<Integer> ans = new ArrayList();
	         Deque<TreeNode> q = new ArrayDeque();
	          q.add(A);

	          while(!q.isEmpty()){
	              int  size = q.size() ;

	                ans.add(q.peek().val);
	              
	              for(int i=0; i<size; i++){
	                  TreeNode cur = q.poll();
	                   
	                    if(cur.left != null)
	                  q.add(cur.left);
	                    
	                     if(cur.right != null)
	                  q.add(cur.right);
	              }
	          }
	          return ans;
	    }
}
