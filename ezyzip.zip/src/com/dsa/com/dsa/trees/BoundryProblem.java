package com.dsa.trees;

/*
 Given a binary tree, return the values of its boundary in anti-clockwise direction starting from the root. Boundary includes left boundary, leaves, and right boundary in order without duplicate nodes.

Left boundary is defined as the path from the root to the left-most node. Right boundary is defined as the path from the root to the right-most node. If the root doesn't have left subtree or right subtree, then the root itself is left boundary or right boundary. Note this definition only applies to the input binary tree, and not applies to any subtrees.

The left-most node is defined as a leaf node you could reach when you always firstly travel to the left subtree if exists. If not, travel to the right subtree. Repeat until you reach a leaf node.

The right-most node is also defined by the same way with left and right exchanged.

Return an array of integers denoting the boundary values of tree in anti-clockwise order.

For Example

Input 1:
               _____1_____
              /           \
             2             3
            / \            / 
           4   5          6   
              / \        / \
             7   8      9  10  
Output 1:
    [1, 2, 4, 7, 8, 9, 10, 6, 3]
    Explanation 1:
        The left boundary are node 1,2,4. (4 is the left-most node according to definition)
        The leaves are node 4,7,8,9,10.
        The right boundary are node 1,3,6,10. (10 is the right-most node).
        So order them in anti-clockwise without duplicate nodes we have [1,2,4,7,8,9,10,6,3].

Input 2:
                1
               / \
              2   3
             / \  / \
            4   5 6  7
Output 2:
     [1, 2, 4, 5, 6, 7, 3] 
Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A Binary Tree, -1 signifies a NULL child, For e.g 6 9 4 -1 -1 8 -1 -1 3 -1 -1
 */

import java.util.*;

public class BoundryProblem {

	ArrayList<Integer> ans;

	public ArrayList<Integer> solve(TreeNode A) {
		ans = new ArrayList<Integer>();
		ans.add(A.val);
		leftBoundry(A.left);
		bottom(A);
		rightBoundry(A.right);
		return ans;
	}

	public void leftBoundry(TreeNode node) {
		if (node == null)
			return;
		ans.add(node.val);
		if (node.left != null)
			leftBoundry(node.left);
		else
			leftBoundry(node.right);
	}

	public void bottom(TreeNode node) {
		if (node == null)
			return;
		if (node.left == null && node.right == null) {
			if (ans.get(ans.size() - 1) != node.val)
				ans.add(node.val);
		}
		bottom(node.left);
		bottom(node.right);
	}

	public void rightBoundry(TreeNode node) {
		if (node == null)
			return;
		if (node.right != null)
			rightBoundry(node.right);
		else
			rightBoundry(node.left);
		if (ans.get(ans.size() - 1) != node.val)
			ans.add(node.val);
	}
}
