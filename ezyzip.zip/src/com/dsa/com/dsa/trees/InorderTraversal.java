package com.dsa.trees;
import java.util.*;
public class InorderTraversal {
	
	 static ArrayList<Integer> inorderTraversal(TreeNode A) {
	        ArrayList<Integer> a = new ArrayList();
	        Stack<TreeNode> s = new Stack();
	        TreeNode cur = A;

	        while(cur != null || !s.isEmpty()){
	            while(cur != null){
	                s.push(cur);
	                cur = cur.left ;
	            }
	            cur = s.pop();
	            a.add(cur.val);
	            cur = cur.right ;
	        }
	        return a ;
	    }
}
