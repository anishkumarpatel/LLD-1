package com.dsa.trees;

/*
 Approach
 There are several ways of looking at this problem.
If we knew that root R is going to be a part of the longest path. Then we can look at the longest path to any leaf in the left subtree, longest path in the right subtree, and add them up along with root’s value to get the answer ( Obviously we only consider a path if its value is not negative ). To calculate the longest path till a leaf is O(n) [ Recursive call carrying forward the cumulative sum to a node ].
Given N possible roots, and then the O(n) leaf path calculation, the bruteforce becomes O(n^2).

However, note that the calculation of the longest path to the leaf is very redundant. So, to calculate the result for root R, can you reuse the results you have for R->left / R->right ?

Problem Description
Given a binary tree T, find the maximum path sum.

The path may start and end at any node in the tree.

Note: A maximum sum path is any path which has the maximum sum of the nodes lying on the path.



Problem Constraints
1 <= Number of Nodes <= 7e4

-1000 <= Value of Node in T <= 1000



Input Format
The first and the only argument contains a pointer to the root of T, A.



Output Format
Return an integer representing the maximum sum path.



Example Input
Input 1:

  
    1
   / \
  2   3
Input 2:

       20
      /  \
   -10   20
        /  \
      -10  -50


Example Output
Output 1:

 6
Output 2:

 40


Example Explanation
Explanation 1:

     The path with maximum sum is: 2 -> 1 -> 3
Explanation 2:

     The path with maximum sum is: 20 -> 20



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A Binary Tree, -1 signifies a NULL child, For e.g 6 9 4 -1 -1 8 -1 -1 3 -1 -1
tree-icon
Enter Input Here
Arg 2: A single Integer, For e.g 9
Enter Input Here


 */

public class MaxSumPathInBinaryTree {
	int globalAns = Integer.MIN_VALUE;

	public int maxPathSum(TreeNode A) {
		find(A);
		return globalAns;
	}

	int find(TreeNode A) {
		if (A == null)
			return 0;

		int l = find(A.left);
		int r = find(A.right);
		// l = Math.max(Integer.MIN_VALUE, l) ; top mistake
		// r = Math.max(Integer.MIN_VALUE, r) ; top mistake

		l = Math.max(0, l);
		r = Math.max(0, r);

//  https://www.scaler.com/academy/mentee-dashboard/class/51566/homework/problems/15/hints?navref=cl_pb_nv_tb

		globalAns = Math.max(globalAns, l + r + A.val);

		return A.val + Math.max(l, r);
	}
}
