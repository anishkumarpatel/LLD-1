package com.dsa.trees;

public class PathSumRootToLeaf {

}
