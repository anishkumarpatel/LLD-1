package com.dsa.trees;

public class Diameterofbinarytree {
	public int solve(TreeNode A) {
		int[] arr = new int[1];

		maxPath(A, arr);
		return arr[0];
	}

	int maxPath(TreeNode A, int[] arr) {
		if (A == null)
			return -1;

		int l = 1 + maxPath(A.left, arr);
		int r = 1 + maxPath(A.right, arr);

		arr[0] = Math.max(arr[0], l + r);

		return Math.max(l, r);
	}

	public int solve11(TreeNode A) {
		TreeInfo t = ch(A);
		return t.diameter;
	}

	TreeInfo ch(TreeNode A) {
		if (A == null)
			return new TreeInfo(-1, -1);

		TreeInfo l = ch(A.left);
		TreeInfo r = ch(A.right);
		int d = Math.max(Math.max(l.diameter, r.diameter), l.path + r.path + 2);
		int p = 1 + Math.max(l.path, r.path);
		return new TreeInfo(d, p);
	}

	class TreeInfo {
		int diameter;
		int path;

		TreeInfo(int d, int p) {
			diameter = d;
			path = p;
		}
	}
}

/*
 * 
 * Problem Description Given a Binary Tree A consisting of N integer nodes, you
 * need to find the diameter of the tree.
 * 
 * The diameter of a tree is the number of edges on the longest path between two
 * nodes in the tree.
 * 
 * 
 * 
 * Problem Constraints 0 <= N <= 105
 * 
 * 
 * 
 * Input Format First and only Argument represents the root of binary tree A.
 * 
 * 
 * 
 * Output Format Return an single integer denoting the diameter of the tree.
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * 1 / \ 2 3 / \ 4 5 Input 2:
 * 
 * 1 / \ 2 3 / \ \ 4 5 6
 * 
 * 
 * Example Output Output 1:
 * 
 * 3 Output 2:
 * 
 * 4
 * 
 * 
 * Example Explanation Explanation 1:
 * 
 * Longest Path in the tree is 4 -> 2 -> 1 -> 3 and the number of edges in this
 * path is 3 so diameter is 3. Explanation 2:
 * 
 * Longest Path in the tree is 4 -> 2 -> 1 -> 3 -> 6 and the number of edges in
 * this path is 4 so diameter is 4.
 * 
 */