package com.dsa.trees;

import java.util.*;

public class PreorderTraversal {
	ArrayList<Integer> a = new ArrayList();

	public ArrayList<Integer> preorderTraversal1(TreeNode A) {
		if (A == null)
			return a;

		a.add(A.val);
		preorderTraversal(A.left);
		preorderTraversal(A.right);

		return a;
	}

	public ArrayList<Integer> preorderTraversal(TreeNode A) {
		ArrayList<Integer> a = new ArrayList();
		TreeNode cur = A;
		Stack<TreeNode> s = new Stack();
		s.push(cur);
		while (!s.isEmpty()) {
			TreeNode data = s.pop();
			a.add(data.val);
			if (data.right != null) {

				s.push(data.right);
			}
			if (data.left != null) {

				s.push(data.left);
			}
		}
		return a;
	}
}
