package com.dsa.trees;
import java.util.*;
public class DeserializeBinaryTree {

	public TreeNode solve(int[] A) {
        TreeNode root = new TreeNode(A[0]);
        Queue<TreeNode> q = new LinkedList();
               q.add(root) ;
        for(int i=1; i<A.length; i+=2){
              TreeNode cur = q.poll();

              if(A[i] != -1)
              {
                  cur.left = new TreeNode(A[i]);
                 q.add(cur.left);
              }
            if(A[i+1] != -1)
              {
                  cur.right = new TreeNode(A[i+1]);
                 q.add(cur.right);
              }
        }
        return root ;
    }

}
