package com.dsa;
import java.util.*;
public class Backtracking {
	public ArrayList<ArrayList<Integer>> subsets(ArrayList<Integer> A) {
        ArrayList<ArrayList<Integer>> ans = new ArrayList<>();
        ArrayList<Integer> list = new ArrayList<>() ;
         ans.add(new ArrayList<>());
         Collections.sort(A);
       generate(A,ans,list,0,A.size()) ;

       return ans ;
    }
void generate(ArrayList<Integer> A,ArrayList<ArrayList<Integer>> ans,ArrayList<Integer> list,int idx, int n){
            if(idx==n) return ;

         list.add(A.get(idx));
        ans.add(new ArrayList<>(list));

        generate(A,ans,list,idx+1, n);
        
        list.remove(list.size()-1);

        generate(A,ans,list,idx+1,n);
    }
}

/*
 
 */