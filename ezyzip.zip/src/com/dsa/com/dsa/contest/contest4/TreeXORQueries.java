package com.dsa.contest.contest4;

/*Given a tree with n nodes and each node having a value associated with it, you need to perform q XOR queries on the tree. Each query is of the form (u, v, x), which means that you need to find the XOR value of the node values on the path from node u to node v in the tree, and then XOR the result with the value x.
Write a function that takes the root node of the tree, the number of nodes n, and the list of q queries as input, and returns a list of the XOR values for each query.
For example, consider the following binary tree with values associated with each node:
       5
      / \
     3  7
    / \  \
   1  6  9
Suppose that we have the following two queries:
(1, 6, 2)
(3, 9, 1)
(1,9,1)

output:- [6,9,8]

Explain:-

Path :- 1->3->6 then xo of 1, 3, 6, 2 where path u (1) to path v(6) & then xor of x (2) must be 6

Path :- 3->5->7->9->1 then xo of3,5,7,9,1 where path u (3) to path v(9) & then xor of x (1) must be 9

and so on..  */
import java.util.*;

public class TreeXORQueries {
	public static int[] xorQueries(TreeNode root, int n, int[][] queries) {
		int[] result = new int[queries.length];

		for (int i = 0; i < queries.length; i++) {
			int u = queries[i][0];
			int v = queries[i][1];
			int x = queries[i][2];

			TreeNode lca = findLCA(root, u, v);

			int pathXOR = xorPath(lca, u) ^ xorPath(lca, v) ^ lca.val;
			result[i] = pathXOR ^ x;
		}

		return result;
	}

	public static TreeNode findLCA(TreeNode root, int u, int v) {
		if (root == null || root.val == u || root.val == v) {
			return root;
		}

		TreeNode left = findLCA(root.left, u, v);
		TreeNode right = findLCA(root.right, u, v);

		if (left != null && right != null) {
			return root;
		}

		return (left != null) ? left : right;
	}

	public static int xorPath(TreeNode root, int target) {
		if (root == null) {
			return 0;
		}

		if (root.val == target) {
			return root.val;
		}

		int left = xorPath(root.left, target);
		int right = xorPath(root.right, target);

		return (left == 0 && right == 0) ? 0 : (left ^ right ^ root.val);
	}

	public static void main(String[] args) {
		System.out.println(9 ^ 7 ^ 1);
		System.out.println(3 ^ 5 ^ 7 ^ 2);

		TreeNode root = new TreeNode(5);
		root.left = new TreeNode(3);
		root.right = new TreeNode(7);
		root.left.left = new TreeNode(1);
		root.left.right = new TreeNode(6);
		root.right.right = new TreeNode(9);

		int[][] queries = { { 9, 7, 1 }, { 3, 7, 2 }, { 6, 9, 1 }, { 7, 7, 5 } };

		int[] result = xorQueries(root, 12, queries);
		System.out.println(Arrays.toString(result));
	}
}
/*
 * The worst-case time complexity of the xorQueries function is O(q * h), where
 * q is the number of queries and h is the height of the tree. This is because
 * for each query, we need to find the LCA of u and v, and then calculate the
 * XOR value of the path from u to v. Finding the LCA can take up to O(h) time,
 * and calculating the XOR value of the path from u to v takes up to O(h) time
 * as well (assuming that we use a recursive approach as in the xorPath
 * function). Therefore, the total time complexity is O(q * h).
 */
