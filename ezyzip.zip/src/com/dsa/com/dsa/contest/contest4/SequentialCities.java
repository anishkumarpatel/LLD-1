package com.dsa.contest.contest4;

import java.util.* ;

public class SequentialCities {
	public class Solution {
		public int brute(TreeNode A, int B) {
			int[] count = new int[1];
			pre(A, B, 0, count);
			return count[0];
		}

		void pre(TreeNode A, int B, int sum, int[] count) {
			if (A == null)
				return;
			pre1(A, B, 0, count);
			pre(A.left, B, 0, count);
			pre(A.right, B, 0, count);
		}

		void pre1(TreeNode A, int B, int sum, int[] count) {
			if (A == null)
				return;

			sum += A.val;
			if (sum == B)
				count[0]++;
			pre1(A.left, B, sum, count);
			pre1(A.right, B, sum, count);
		}
	}
	//===============
	int count;
    public int solve(TreeNode A, int B) {
        HashMap<Integer,Integer> map = new HashMap<>();
        dfs(A,B,0,map);
       return count;
    }
    void dfs(TreeNode A,int B,int prefixSum,HashMap<Integer,Integer> map){
        prefixSum += A.val ;
        if(prefixSum == B) {
            count++;
        }
        
        if(map.containsKey(prefixSum-B)){
        count = count + map.get(prefixSum-B);
        }
        int fre = map.getOrDefault(prefixSum,0)+1;
        map.put(prefixSum,fre);
  
        if(A.left != null) dfs(A.left,B,prefixSum,map);
        
        if(A.right != null) dfs(A.right,B,prefixSum,map);
        
        fre = map.get(prefixSum);
        if(fre > 1) map.put(prefixSum,fre-1);
      else
        map.remove(prefixSum);
        prefixSum -= A.val ;
    }
}
