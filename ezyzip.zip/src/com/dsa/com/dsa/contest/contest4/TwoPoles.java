package com.dsa.contest.contest4;

import java.util.*;

public class TwoPoles {
	public int solve(int[] A) {
		int n = A.length;
		int ans = 0;
		Stack<Integer> s = new Stack();

		for (int i = 0; i < n; i++) {
			while (!s.isEmpty() && A[s.peek()] <= A[i]) {
				s.pop();
				ans++;
			}
			s.push(i);
		}
		s = new Stack();
		for (int i = n - 1; i >= 0; i--) {
			while (!s.isEmpty() && A[s.peek()] <= A[i]) {
				s.pop();
				ans++;
			}
			s.push(i);
		}
		return ans;
	}

	public int solve1(int[] A) {

		int n = A.length;

		int ans = 0;

		for (int i = 0; i < n; i++) {

			for (int j = i + 1; j < n; j++) {

				if (A[j] > A[i]) {
					ans += 1;

					break;

				}
			}

		}

		for (int i = n - 1; i >= 0; i--) {

			for (int j = i - 1; j >= 0; j--) {

				if (A[j] > A[i]) {
					ans += 1;
					break;
				}
			}

		}
		return ans;
	}
}
