package com.dsa.contest.contest4;

/*
 Aman likes identiti binary tree . He bought two binary tree denoted by root node A and B. He wants to make both the trees  identical but he is only  allowed to do operation on Binary A. In each operation you can swap the left pointer and right pointer of any node. Return the minimum number of operations required to make both trees identical. if it not possible then return -1. Note two binry trees are considered identically if they are structurally identical and the nodes have same values -->9 1 2 3 5 -1 -1 -1 -1 -1 
9 1 3 2 -1 -1 -1 5 -1 -1  output must be 2 which are minimum operation
 */

import java.util.*;

public class AmanAndIdenticalTree {
	public int solve(TreeNode A, TreeNode B) {
		if (A == null && B == null) {
			return 0;
		} else if (A == null || B == null) {
			return -1;
		} else if (A.val != B.val) {
			return -1;
		}

		int leftSwap = solve(A.left, B.left);
		int rightSwap = solve(A.right, B.right);

		if (leftSwap == -1 || rightSwap == -1) {
			// At least one subtree is not identical
			// So we need to swap the current node's left and right children
			TreeNode temp = A.left;
			A.left = A.right;
			A.right = temp;

			// Check if the trees are identical now
			int newLeftSwap = solve(A.left, B.left);
			int newRightSwap = solve(A.right, B.right);

			if (newLeftSwap == -1 || newRightSwap == -1) {
				// Swapping did not make the trees identical
				return -1;
			} else {
				// Swapping made the trees identical
				return 1 + newLeftSwap + newRightSwap;
			}
		} else {
			// Both subtrees are identical
			return leftSwap + rightSwap;
		}
	}
}
