package com.dsa.contest.contest4;

import java.util.*;

public class MaxsProd {
	public int maxSpecialProduct(int[] A) { // TLE
		int n = A.length;
		int[] pse = new int[n];
		int[] nse = new int[n];

		for (int i = 0; i < n; i++) {
			for (int j = i - 1; j >= 0; j--)
				if (A[j] > A[i]) {
					pse[i] = j;
					break;
				}
		}
		for (int i = n - 1; i >= 0; i--) {
			for (int j = i + 1; j < n; j++)
				if (A[j] > A[i]) {
					nse[i] = j;
					break;
				}
		}
		long mod = 1000 * 1000 * 1000 + 7 ; //or (int)1e9+7 ;
		long max = 0;
		for (int i = 0; i < n; i++) {
			long prod = (1l * pse[i] * nse[i]);
			max = Math.max(max, prod);
		}
		return (int) (max % mod);
	}

	public int maxSpecialProduct1(int[] A) { // optimised
		int n = A.length;
		int[] left = new int[n];
		int[] right = new int[n];

		Stack<Integer> s = new Stack<>();
		for (int i = 0; i < n; i++) {
			while (!s.isEmpty() && A[s.peek()] <= A[i])
				s.pop();

			if (s.isEmpty())
				left[i] = -1;
			else
				left[i] = s.peek();
			s.push(i);
		}
		s = new Stack<>();
		for (int i = n - 1; i >= 0; i--) {
			while (!s.isEmpty() && A[s.peek()] <= A[i])
				s.pop();

			if (s.isEmpty())
				right[i] = -1;
			else
				right[i] = s.peek(); 
			s.push(i);
		}
		long mod = 1000 * 1000 * 1000 + 7; // (int)1e9 + 7 ;
		long max = 0;
		for (int i = 0; i < n; i++) {
			if (left[i] == -1)
				left[i] = 0;
			if (right[i] == -1)
				right[i] = 0;
			long prod = (1l * left[i] * right[i]);
			max = Math.max(prod, max);
		}
		return (int) (max % mod);
	}
}
