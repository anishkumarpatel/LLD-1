package com.dsa.contest.contest1;

import java.util.*;
public class LittlePonnyAndStringPeriod {

public int solve(String A) {
    int n = A.length();
    
HashMap<Character,Integer> map = new HashMap<>();

for(int i=0; i<n; i++){
    char c = A.charAt(i);
    int fre = map.getOrDefault(c,0)+1;
    map.put(c,fre);
}
    int x = 0;
    for(Map.Entry<Character,Integer> entry : map.entrySet()){
        x = gcd(x,entry.getValue());
    }
    if(x==1)
    return n;
 else 
    return n/x ;
    
}
 public int gcd(int a,int b){
    if(b==0)
    return a;
    else
   return gcd(b,a%b);
}
}
