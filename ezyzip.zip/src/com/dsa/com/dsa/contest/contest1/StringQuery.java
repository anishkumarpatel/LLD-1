package com.dsa.contest.contest1;

import java.util.*;

public class StringQuery {
	static String[] bruteForce(String[] A, String B, int[][] C) {
		int n = A.length;
		char b = B.charAt(0);
		int q = C.length;
		String[] ans = new String[q];

		for (int i = 0; i < q; i++) {
			int x = C[i][0];
			int y = C[i][1];
			for (int j = 0; j < n; j++) {
				String temp = A[j];
				char ch = temp.charAt(0);
				int l = 1;
				int max_l = 1;
				int count = 0;
				if (ch == B.charAt(0)) {
					count++;
				}
				for (int k = 1; k < temp.length(); k++) {
					if (ch + 1 == temp.charAt(k)) {
						l++;
						if (l > max_l) {
							max_l = l;
						}
					} else {
						l = 1;
					}
					ch = temp.charAt(k);
					if (ch == B.charAt(0))
						count++;
				}
				if (max_l == x && count == y) {
					ans[i] = temp;
					break;
				} else
					ans[i] = "NULL";
			}
		}
		return ans;
	}

	public String[] optimised(String[] A, String B, int[][] C) {
		int n = A.length;
		char b = B.charAt(0);
		int q = C.length;
		String[] ans = new String[q];

		HashMap<String, Integer> map = new HashMap<>();

		for (int j = 0; j < n; j++) {
			String temp = A[j];
			char ch = temp.charAt(0);
			int l = 1;
			int max_l = 1;
			int count = 0;
			if (ch == B.charAt(0)) {
				count++;
			}
			for (int k = 1; k < temp.length(); k++) {
				ch = temp.charAt(k - 1); // why this staement is not working
				if (ch + 1 == temp.charAt(k)) {
					l++;
					// System.out.println(temp+" "+K+" "+l+" "+max_l);
					if (l > max_l) {
						max_l = l;

					}
					// System.out.println(temp+" "+k+" "+l+" "+max_l);
				} else {
					l = 1;
				}
				// ch = temp.charAt(k) ;
				if (temp.charAt(k) == b)
					count++;
			}
			String key = max_l + " " + count;
			if (!map.containsKey(key))
				map.put(key, j);

		}
		for (int i = 0; i < q; i++) {
			int x = C[i][0];
			int y = C[i][1];
			String key = x + " " + y;
			if (map.containsKey(key))
				ans[i] = A[map.get(key)];
			else
				ans[i] = "NULL";
		}
		return ans;
	}
}
