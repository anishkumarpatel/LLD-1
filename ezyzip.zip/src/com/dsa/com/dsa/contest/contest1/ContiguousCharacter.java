package com.dsa.contest.contest1;

public class ContiguousCharacter {
	public int optimised(String A, int B, String C) {
		int n = A.length();
		int ans = 0;
		int j = 0, other = 0;
		for (int i = 0; i < n; i++) {
			char c = A.charAt(i);
			if (c != C.charAt(0))
				other++;

			if (other > B) {
				if (A.charAt(j) != C.charAt(0))
					other--;
				j++;
			}
			ans = Math.max(ans, i - j + 1);
		}
		return ans;
	}

	public int solveBrute(String A, int B, String C) {
		int n = A.length();
		int ans = 0;
		for (int i = 0; i < n; i++) {
			int other = 0;
			for (int j = i; j < n; j++) {
				char c = A.charAt(j);
				if (c != C.charAt(0))
					other++;
				if (other <= B && ans <= j - i + 1)
					ans = j - i + 1;
			}
		}
		return ans;
	}
}
