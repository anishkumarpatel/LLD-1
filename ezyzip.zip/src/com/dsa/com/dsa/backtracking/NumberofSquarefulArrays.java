package com.dsa.backtracking;

import java.util.*;

public class NumberofSquarefulArrays {
	int count;

	public int brute(ArrayList<Integer> A) {
		if (A.size() == 1)
			return 0;
		HashSet<ArrayList<Integer>> set = new HashSet<>();
		ArrayList<Integer> list = new ArrayList<>();
		sqrt(A, list, set, 0);
		return count;
	}

	void sqrt(ArrayList<Integer> A, ArrayList<Integer> list, HashSet<ArrayList<Integer>> set, int idx) {
		if (list.size() == A.size()) {
			if (set.add(new ArrayList<Integer>(list))) {
				// System.out.println(list);
				int i = 0;
				boolean flag = true;
				for (i = 0; i < list.size() - 1; i++) {
					int sum = A.get(i) + A.get(i + 1);
					double d = Math.sqrt(sum);
					if (d != (int) d) {
						flag = false;
					}
				}
				if (flag)
					count++;
			}
			return;
		}
		for (int i = idx; i < A.size(); i++) {
			list.add(A.get(i));
			swap(A, i, idx);
			sqrt(A, list, set, idx + 1);
			list.remove(list.size() - 1);
			swap(A, i, idx);
		}
	}

	void swap(ArrayList<Integer> A, int i, int j) {
		int temp = A.get(i);
		A.set(i, A.get(j));
		A.set(j, temp);
	}
	// =====
/*
	int count;

	public int solve(ArrayList<Integer> A) {
		if (A.size() == 1)
			return 0;
		HashSet<ArrayList<Integer>> set = new HashSet<>();
		ArrayList<Integer> list = new ArrayList<>();
		sqrt(A, list, set, 0);
		return count;
	}

	void sqrt(ArrayList<Integer> A, ArrayList<Integer> list, HashSet<ArrayList<Integer>> set, int idx) {
		if (list.size() == A.size()) {
			if (set.add(new ArrayList<Integer>(list))) {
				count++;
			}
			return;
		}
		for (int i = idx; i < A.size(); i++) {
			int sum = A.get(i);
			if (idx > 0) {
				sum += list.get(idx - 1);
				double d = Math.sqrt(sum);
				if (d != (int) d) {
					continue;
				}

			}
			list.add(A.get(i));
			swap(A, i, idx);
			sqrt(A, list, set, idx + 1);
			list.remove(list.size() - 1);
			swap(A, i, idx);
		}
	}

	void swap(ArrayList<Integer> A, int i, int j) {
		int temp = A.get(i);
		A.set(i, A.get(j));
		A.set(j, temp);
	}*/
}
/*
 * Problem Description Given an array of integers A, the array is squareful if
 * for every pair of adjacent elements, their sum is a perfect square.
 * 
 * Find and return the number of permutations of A that are squareful. Two
 * permutations A1 and A2 differ if and only if there is some index i such that
 * A1[i] != A2[i].
 * 
 * 
 * 
 * Problem Constraints 1 <= length of the array <= 12
 * 
 * 1 <= A[i] <= 109
 * 
 * 
 * 
 * Input Format The only argument given is the integer array A.
 * 
 * 
 * 
 * Output Format Return the number of permutations of A that are squareful.
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * A = [2, 2, 2] Input 2:
 * 
 * A = [1, 17, 8]
 * 
 * 
 * Example Output Output 1:
 * 
 * 1 Output 2:
 * 
 * 2
 * 
 * 
 * Example Explanation Explanation 1:
 * 
 * Only permutation is [2, 2, 2], the sum of adjacent element is 4 and 4 and
 * both are perfect square. Explanation 2:
 * 
 * Permutation are [1, 8, 17] and [17, 8, 1].
 */