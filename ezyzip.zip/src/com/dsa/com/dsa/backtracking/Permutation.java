package com.dsa.backtracking;
import java.util.*;
public class Permutation {
	public ArrayList<ArrayList<Integer>> permute(ArrayList<Integer> A) {
		ArrayList<ArrayList<Integer>> ans = new ArrayList<>();
		ArrayList<Integer> list = new ArrayList<>();
		reArrange(ans, list, A);
		return ans;
	}

	void reArrange(ArrayList<ArrayList<Integer>> ans, ArrayList<Integer> list, ArrayList<Integer> A) {
		if (list.size() == A.size()) {
			ans.add(new ArrayList<Integer>(list));
			return;
		}
		for (int i = 0; i < A.size(); i++) {
			if (list.contains(A.get(i)))
				continue;
			list.add(A.get(i));
			reArrange(ans, list, A);
			list.remove(list.size() - 1);
		}
	}
	 void reArrange1(ArrayList<ArrayList<Integer>> ans,ArrayList<Integer> list,ArrayList<Integer> A,int idx){
	        if(list.size()== A.size()){
	                ans.add(new ArrayList<Integer>(list));
	                return;
	            }
	        for(int i=idx; i<A.size(); i++){
	            
	            list.add(A.get(i)) ;
	            swap(A,i,idx);
	            reArrange1(ans,list,A,idx+1);
	            list.remove(list.size()-1) ;
	            swap(A,i,idx);
	        }
	    }
	    void swap(ArrayList<Integer> A, int a, int b){
	        int temp = A.get(a);
	         A.set(a,A.get(b));
	         A.set(b,temp);
	    }
}
