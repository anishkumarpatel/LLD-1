package com.dsa.backtracking;

import java.util.*;

public class RemoveInvalidParentheses {
	public String[] solve(String A) {

		int minReq = getMin(A);
		if (minReq == 0)
			return new String[] { A };
		Map<String, Boolean> hashset = new HashMap<>();
		ArrayList<String> ans = new ArrayList<>();
		Solution(A, minReq, hashset, ans);
		String[] result = new String[ans.size()];
		int idx = 0;
		for (String s : ans)
			result[idx++] = s;

		return result;
	}

	public void Solution(String A, int minReq, Map<String, Boolean> hashset, ArrayList<String> ans) {
		if (hashset.get(A) != null && hashset.get(A))
			return;
		hashset.put(A, true);
		if (minReq == 0) {
			if (getMin(A) == 0) {
				ans.add(A);
			}
			return;
		}

		for (int i = 0; i < A.length(); i++) {
			String left = A.substring(0, i);
			String right = A.substring(i + 1);
			Solution(left + right, minReq - 1, hashset, ans);
		}
	}

	public int getMin(String A) {

		// gives minimum character to remove
		Stack<Character> stk = new Stack();
		for (int i = 0; i < A.length(); i++) {
			if (A.charAt(i) == '(') {
				stk.push('(');
			} else if (A.charAt(i) == ')') {
				if (stk.isEmpty()) {
					stk.push(')');
				} else {

					if (stk.peek() == '(') {
						stk.pop();
					} else {
						stk.push(')');
					}
				}
			}
		}
		return stk.size();
	}
}
/*
 * ============== public String[] timeLimitExceeded(String A) {
 * 
 * int minReq = getMin(A); if(minReq==0) return new String[]{A};
 * Map<String,Boolean> hashset = new HashMap<>(); Solution(A,minReq,hashset);
 * String[] result = new String[hashset.size()]; int idx = 0;
 * for(Map.Entry<String,Boolean> entry : hashset.entrySet()) result[idx++] =
 * entry.getKey(); return result; }
 * 
 * public void Solution(String A, int minReq, Map<String,Boolean> hashset){
 * if(hashset.get(A)!= null && hashset.get(A)) return; // hashset.put(A,true);
 * if(minReq==0){ if(getMin(A)==0){ if(!hashset.containsKey(A)){
 * hashset.put(A,true); } } return ; }else if(minReq < 0) return ;
 * 
 * for(int i=0;i<A.length();i++){ String left = A.substring(0,i); String right =
 * A.substring(i+1); Solution(left+right, minReq-1, hashset); } } public int
 * getMin(String A){
 * 
 * // gives minimum character to remove Stack<Character> stk = new Stack();
 * for(int i=0;i<A.length();i++){ if(A.charAt(i)=='('){ stk.push('('); }else
 * if(A.charAt(i)==')'){ if(stk.isEmpty()){ stk.push(')'); }else{
 * 
 * if(stk.peek()=='('){ stk.pop(); }else{ stk.push(')'); } } } } return
 * stk.size(); } ==============
 * 
 * Problem Description Given a string A consisting of lowercase English
 * alphabets and parentheses '(' and ')'. Remove the minimum number of invalid
 * parentheses in order to make the input string valid.
 * 
 * Return all possible results.
 * 
 * You can return the results in any order.
 * 
 * 
 * 
 * Problem Constraints 1 <= length of the string <= 20
 * 
 * 
 * 
 * Input Format The only argument given is string A.
 * 
 * 
 * 
 * Output Format Return all possible strings after removing the minimum number
 * of invalid parentheses.
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * A = "()())()" Input 2:
 * 
 * A = "(a)())()"
 * 
 * 
 * Example Output Output 1:
 * 
 * ["()()()", "(())()"] Output 2:
 * 
 * ["(a)()()", "(a())()"]
 * 
 * 
 * Example Explanation Explanation 1:
 * 
 * By removing 1 parentheses we can make the string valid. 1. Remove the
 * parentheses at index 4 then string becomes : "()()()" 2. Remove the
 * parentheses at index 2 then string becomes : "(())()" Explanation 2:
 * 
 * By removing 1 parentheses we can make the string valid. 1. Remove the
 * parentheses at index 5 then string becomes : "(a)()()" 2. Remove the
 * parentheses at index 2 then string becomes : "(a())()"
 */
