package com.dsa.backtracking;

/*
 
public class Solution {
    ArrayList<ArrayList<Integer>> finalArray;
    ArrayList<Integer> Arr;
    HashSet<ArrayList<Integer>> hs;
    int target;
    public ArrayList<ArrayList<Integer>> combinationSum(ArrayList<Integer> A, int B) {
        target =B;
        finalArray = new ArrayList<ArrayList<Integer>>();
        Arr =new ArrayList<Integer>(A);
        Collections.sort(Arr);
        hs = new HashSet<ArrayList<Integer>>();
        findAll(0,B,new ArrayList<Integer>());
        return finalArray;
    }
    public void findAll(int index,int target,ArrayList<Integer> temp){      
        if(index==Arr.size()){
            if(hs.add(new ArrayList<Integer>(temp))){
                if(target==0){
                    finalArray.add(new ArrayList<Integer>(temp));
                }
            }
               return;
        }
        if(Arr.get(index)<=target){
            temp.add(Arr.get(index));
            findAll(index,(target-Arr.get(index)),temp);
            temp.remove(temp.size()-1);
        }
        findAll(index+1,target,temp);
    }
}
Problem Description
Given an array of candidate numbers A and a target number B, find all unique combinations in A where the candidate numbers sums to B.

The same repeated number may be chosen from A unlimited number of times.

Note:

1) All numbers (including target) will be positive integers.

2) Elements in a combination (a1, a2, … , ak) must be in non-descending order. (ie, a1 ≤ a2 ≤ … ≤ ak).

3) The combinations themselves must be sorted in ascending order.

4) CombinationA > CombinationB iff (a1 > b1) OR (a1 = b1 AND a2 > b2) OR ... (a1 = b1 AND a2 = b2 AND ... ai = bi AND ai+1 > bi+1)

5) The solution set must not contain duplicate combinations.



Problem Constraints
1 <= |A| <= 20

1 <= A[i] <= 50

1 <= B <= 500



Input Format
The first argument is an integer array A.

The second argument is integer B.



Output Format
Return a vector of all combinations that sum up to B.



Example Input
Input 1:

A = [2, 3]
B = 2
Input 2:

A = [2, 3, 6, 7]
B = 7


Example Output
Output 1:

[ [2] ]
Output 2:

[ [2, 2, 3] , [7] ]


Example Explanation
Explanation 1:

All possible combinations are listed.
Explanation 2:

All possible combinations are listed. 
  */
import java.util.*;

public class CombinationSum {
	public ArrayList<ArrayList<Integer>> combinationSum(ArrayList<Integer> A, int B) {
		LinkedHashSet<ArrayList<Integer>> ans = new LinkedHashSet<>();
		ArrayList<Integer> list = new ArrayList<>();
		Collections.sort(A);
		com(A, B, ans, list, 0);
		ArrayList<ArrayList<Integer>> finalAns = new ArrayList<>();
		for (ArrayList<Integer> itr : ans)
			finalAns.add(itr);
		return finalAns;
	}

	void com(ArrayList<Integer> A, int B, HashSet<ArrayList<Integer>> ans, ArrayList<Integer> list, int idx) {

		if (B == 0) {
			ans.add(new ArrayList<>(list));
			return;
		}

		for (int i = idx; i < A.size(); i++) {
			if (B - A.get(i) >= 0) {
				list.add(A.get(i));
				com(A, B - A.get(i), ans, list, i);
				list.remove(A.get(i));
			}
		}
	}
}

//Time Complexity: O(k*(2^n)) where n is the size of array, and k is average length
//Auxiliary Space: O(k*x) where is x is number of possible combinations

