package com.dsa.backtracking;

import java.util.*;

public class SubsetsII {
	public ArrayList<ArrayList<Integer>> subsetsWithDup(ArrayList<Integer> A) {
		LinkedHashSet<ArrayList<Integer>> ans = new LinkedHashSet<>();
		ArrayList<Integer> list = new ArrayList<>();
		ans.add(new ArrayList<Integer>());
		Collections.sort(A);
		generate(A, list, ans, 0);
		ArrayList<ArrayList<Integer>> res = new ArrayList<>();
		for (ArrayList<Integer> itr : ans) {
			res.add(itr);
		}
		return res;
	}

	void generate(ArrayList<Integer> A, ArrayList<Integer> list, LinkedHashSet<ArrayList<Integer>> ans, int idx) {
		if (idx == A.size()) {
			return;
		}
		list.add(A.get(idx));
		ans.add(new ArrayList<Integer>(list));
		generate(A, list, ans, idx + 1);

		list.remove(list.size() - 1);

		generate(A, list, ans, idx + 1);
	}
}

/*
 * Problem Description Given a collection of integers denoted by array A of size
 * N that might contain duplicates, return all possible subsets.
 * 
 * NOTE:
 * 
 * Elements in a subset must be in non-descending order. The solution set must
 * not contain duplicate subsets. The subsets must be sorted lexicographically.
 * 
 * 
 * Problem Constraints 0 <= N <= 16
 * 
 * 
 * 
 * Input Format Only argument is an integer array A of size N.
 * 
 * 
 * 
 * Output Format Return a 2-D vector denoting all the possible subsets.
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * A = [1, 2, 2] Input 2:
 * 
 * A = [1, 1]
 * 
 * 
 * Example Output Output 1:
 * 
 * [ [], [1], [1, 2], [1, 2, 2], [2], [2, 2] ] Output 2:
 * 
 * [ [], [1], [1, 1] ]
 * 
 * 
 * Example Explanation Explanation 1:
 * 
 * All the subsets of the array [1, 2, 2] in lexicographically sorted order.
 * 
 */