package com.dsa;

public class StrangeEquality {

	public static void main(String[] args) {
		System.out.println(solve(5));
		System.out.println(brute(5));
	}

	static int brute(int A) {
		int x = 0, y = 0;

		for (int i = 0; i < A; i++)
			if (A + i == (A ^ i))
				x = i;

		for (int i = A + 1; i < Integer.MAX_VALUE; i++)
			if (A + i == (A ^ i)) {
				y = i;
				break;
			}
		return x ^ y;
	}

	static int solve(int A) {
		int x = 0, bit = 0;

		while (A > 0) {
			if (A % 2 == 0) {
				x |= (1 << bit);
			}
			bit++;
			A /= 2;
		}

		int y = 1 << bit;

		return x ^ y;
	}
}
