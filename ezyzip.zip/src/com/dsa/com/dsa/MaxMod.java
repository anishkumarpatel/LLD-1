package com.dsa;

import java.util.*;

public class MaxMod {

	public static void main(String[] args) {

	}

	static int solve1(int[] A) {
		// Arrays.sort(A) ;

		int max = 0;
		int max2 = 0;
		int n = A.length - 1;

		for (int i = 0; i <= n; i++) {
			if (A[i] > max)
				max = A[i];
		}
		for (int i = 0; i <= n; i++) {
			if (A[i] != max && A[i] > max2)
				max2 = A[i];

		}
		return max2;
	}

	static int solve(int[] A) {
		Arrays.sort(A);

		int n = A.length - 1;

		int max = A[n];

		for (int i = n; i >= 0; i--) {
			if (A[i] != max)
				return A[i];
		}
		return 0;
	}

}
