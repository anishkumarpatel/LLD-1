package com.dsa;

public class CheckBit {

	public static void main(String[] args) {
		System.out.println(countSet(10));
	}

	static int countSet(int n) {
		int c = 0;
		for (int i = 0; i < 32; i++)
			if (checkBit(n, i))
				c++;
		return c;
	}

	static boolean checkBit(int n, int i) {
		if (((n >> i) & 1) == 1)
			return true;
		else
			return false;
	}
}
