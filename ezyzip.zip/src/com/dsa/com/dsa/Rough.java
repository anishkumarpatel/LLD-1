package com.dsa;

public class Rough {

	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		System.out.println("Main");
		myThread.start();
		/*
		 * String s1 = "IT Technical" ;
		 * 
		 * String[] words = s1.split("\\s");
		 * 
		 * for(String w : words) System.out.print(w+" ");
		 * 
		 * /System.out.println((int)Math.pow(2, 4)); //System.out.println(po(2, 4));
		 * System.out.println("ANSH: "+solveVery(80,61));
		 * 
		 * System.out.println(1l<<31);
		 * 
		 * int a[][] = {{2,-1,3,2},{3,2,6,2},{10,9,8,2},{4,-1,2,3},{3,2,6,9}};
		 * 
		 * for(int i=0; i<a.length; i++) { for(int j=0; j<a[0].length; j++)
		 * System.out.print(a[i][j]+"\t"); System.out.println(); } int sum=0; for(int
		 * i=2; i<=4; i++) for(int j=1; j<=2; j++) sum += a[i][j];
		 * 
		 * System.out.println("\n\nsum= "+sum);
		 * 
		 * int arr[] = { 10, 4, 16, 20 };
		 * 
		 * int prefixSum[] = new int[arr.length];
		 * 
		 * prefixSum[0] = arr[0];
		 * 
		 * for(int i=1; i<arr.length; i++) prefixSum[i] = prefixSum[i-1]+arr[i];
		 * 
		 * for(int i=0; i<arr.length; i++) System.out.print(prefixSum[i]+",");
		 * 
		 * // Prefix sum of 2D array int a[][] = { {5, 17, 100, 11}, {0, 0, 2, 8} };
		 * 
		 * for(int i=0; i<a.length; i++) { for(int j=0; j<a[0].length; j++)
		 * System.out.print(a[i][j]+"\t"); System.out.println(); }
		 * 
		 * int pf[][] = new int[a.length][a[0].length];
		 * 
		 * for(int i=0; i<a.length; i++) // rowWise sum { pf[i][0]=a[i][0];
		 * 
		 * for(int j=1; j<a[0].length; j++) pf[i][j] = pf[i][j-1] + a[i][j]; }
		 * 
		 * for(int i=0; i<a[0].length; i++) // columnWise sum { pf[0][i] = pf[0][i];
		 * 
		 * for(int j=1; j<a.length; j++) pf[j][i] = pf[j][i]+pf[j-1][i]; }
		 * System.out.println(); for(int i=0; i<a.length; i++) { for(int j=0;
		 * j<a[0].length; j++) System.out.print(pf[i][j]+"\t"); System.out.println(); }
		 * System.out.println();
		 * 
		 * 
		 * 
		 * System.out.println(-5%3); } static String solve(String A) { StringBuilder s =
		 * new StringBuilder(); int n = A.length();
		 * 
		 * for(int i=n-1; i>=0; i--) s.append(A.charAt(i));
		 * 
		 * String s1 = s.toString(); StringBuilder s2 = new StringBuilder();
		 * 
		 * for(int i=0; i<n; i++) { int a = i; while(s1.charAt(i)!= '\0') i++; int a1 =
		 * i; for(int j=a1-1; j>=a; j--) s2.append(s1.charAt(j)); i+=1; } return
		 * s2.toString(); } public long[] solve(int[] A) { int n = A.length;
		 * 
		 * long a[] = new long[n];
		 * 
		 * for(int i=0; i<n; i++) a[i]= A[i]*A[i]*A[i];
		 * 
		 * return a; }
		 * 
		 * 
		 * 
		 * int a=3,b=5;
		 * 
		 * System.out.println((a+b)%b+" "+(a%b+b)%b);
		 * 
		 * int a1[][] = {{1,2,3,4},{4,5,6,7},{8,9,10,11},{13,15,17,19}};
		 * 
		 * 
		 * ArrayList<ArrayList<Integer>> list = new ArrayList<>();
		 * 
		 * int r= a1.length, c=a1[0].length;
		 * 
		 * for(int i=0; i<r; i++) { ArrayList<Integer> x = new ArrayList<>();
		 * 
		 * for(int j=0; j<c; j++) { if(a1[i][j]%2==0) x.add(a1[i][j]); } list.add(x); }
		 * System.out.println(list); for(int i=0; i<list.size(); i++) { for(int j=0;
		 * j<list.get(0).size(); j++) System.out.print(list.get(i).get(j)+" ");
		 * System.out.println(); } int r1 = list.size(); System.out.println(list);
		 * for(int i=0; i<r1; i++) { for(int j=0; j<list.get(0).size(); j++)
		 * //System.out.print(list.get(i).get(j)+" "); System.out.println(); }
		 * 
		 * int ss = '\0'; System.out.println(ss);
		 * 
		 * System.out.println((4<<1)+"\n\n "+(4>>1)); int a = 10; // 1010 int c=0;
		 * for(int i=0; i<32; i++) if(checkBit(a,i)) c++ ; System.out.println(c);
		 * System.out.println((2147483647-1)%1000000007);
		 * System.out.println((2147483647+1)%1000000007);
		 * 
		 * System.out.println("Hello: "+(1<<32)); } static boolean checkBit(int n , int
		 * i) { if(( ( n >> i ) & 1 ) == 1) return true; else return false;
		 * 
		 * System.out.println(sum(5)); // 5 4 3 2 1 print(5); des(5); } static int
		 * sum(int n) { System.out.print(n+" "); if(n == 0 ) return 0; return sum(n-1)+
		 * n ; } static void print(int n) { if(n==0)return; System.out.println("Hi "+n);
		 * 
		 * print(n-1); } static void des(int n) { if(n==0) { return; } des(n-1);
		 * System.out.print(n+" ");
		 * 
		 * String s = "Anish"; rev(s); } static void rev(String s) { if(s.length() == 0
		 * ) return ;
		 * 
		 * rev(s.substring(1));
		 * 
		 * System.out.print(s.charAt(0)); } static int po(int n, int p) { int ans=1;
		 * for(int i=0; i<p; i++) ans *= n; return ans; } static int solveVery(int A,
		 * int B) { long mod = 1000*1000*1000 + 7;long ans = 1; for(long i=1; i<=
		 * fac(B); i++) ans *= (A%mod); ans %= mod; return (int)ans ; }
		 * 
		 * static long fac(long n) { long fact = 1; long mod = 1000*1000*1000 + 7;
		 * for(long i=1; i<=n; i++ ) fact *= i; return fact%mod ; }
		 * 
		 */
	}
}

class MyThread extends Thread {
	public void run() {
		System.out.println("Run");
	}
}
