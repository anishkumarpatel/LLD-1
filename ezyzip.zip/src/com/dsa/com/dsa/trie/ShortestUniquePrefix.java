package com.dsa.trie;

public class ShortestUniquePrefix {
	public String[] prefix(String[] A) {
		TrieNode root = new TrieNode();
		for (String s : A)
			insert(root, s);

		for (int i = 0; i < A.length; i++)
			A[i] = search(root, A[i]);

		return A;
	}

	String search(TrieNode A, String key) {
		TrieNode curNode = A;
		String s = "";
		for (int i = 0; i < key.length(); i++) {
			char c = key.charAt(i);
			if (curNode.children[c - 'a'].fre > 1)
				s = s + c;
			else
				return s + c;
			curNode = curNode.children[c - 'a'];
		}
		return s;
	}

	void insert(TrieNode A, String key) {
		TrieNode curNode = A;
		for (int i = 0; i < key.length(); i++) {
			char c = key.charAt(i);
			if (curNode.children[c - 'a'] == null)
				curNode.children[c - 'a'] = new TrieNode();
			curNode.children[c - 'a'].fre++;
			curNode = curNode.children[c - 'a'];
		}
	}

	class TrieNode {
		TrieNode[] children = new TrieNode[26];
		int fre = 0;
	}
}

