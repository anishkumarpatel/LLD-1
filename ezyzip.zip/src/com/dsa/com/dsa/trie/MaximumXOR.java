package com.dsa.trie;

public class MaximumXOR {
	public int solve(int[] A) {
		int n = A.length;
		int max = Integer.MIN_VALUE;

		for (int i = 0; i < n; i++) {
			for (int j = i + 1; j < n; j++)
				max = Math.max(max, A[i] ^ A[j]);
		}
		return max;
	}

	class TrieNode {
		TrieNode one, zero;
	}

	void insert(TrieNode A, int n) {
		TrieNode cur = A;
		for (int i = 31; i >= 0; i--) {
			int bit = (n >> i) & 1;
			if (bit == 0) {
				if (cur.zero == null)
					cur.zero = new TrieNode();
				cur = cur.zero;
			} else {
				if (cur.one == null)
					cur.one = new TrieNode();
				cur = cur.one;
			}
		}
	}

	int findMaxXOR(TrieNode A, int n) {
		TrieNode cur = A;
		int ans = 0;
		for (int i = 31; i >= 0; i--) {
			int bit = (n >> i) & 1;
			if (bit == 1) {
				if (cur.zero != null) {
					ans += (1 << i);
					cur = cur.zero;
				} else
					cur = cur.one;
			} else {
				if (cur.one != null) {
					ans += (1 << i);
					cur = cur.one;
				} else
					cur = cur.zero;
			}
		}
		return ans;
	}

	public int solve1(int[] A) { // optimised
		TrieNode root = new TrieNode();
		for (int a : A)
			insert(root, a);

		int max = 0;
		for (int a : A)
			max = Math.max(max, findMaxXOR(root, a));

		return max;
	}
}

/*
 * Problem Description Given an array of integers A, find and return the maximum
 * result of A[i] XOR A[j], where i, j are the indexes of the array.
 * 
 * 
 * 
 * Problem Constraints 1 <= length of the array <= 100000 0 <= A[i] <= 109
 * 
 * 
 * 
 * Input Format The only argument given is the integer array A.
 * 
 * 
 * 
 * Output Format Return an integer denoting the maximum result of A[i] XOR A[j].
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * A = [1, 2, 3, 4, 5] Input 2:
 * 
 * A = [5, 17, 100, 11]
 * 
 * 
 * Example Output Output 1:
 * 
 * 7 Output 2:
 * 
 * 117
 * 
 * 
 * Example Explanation Explanation 1:
 * 
 * Maximum XOR occurs between element of indicies(0-based) 1 and 4 i.e. 2 ^ 5 =
 * 7. Explanation 2:
 * 
 * Maximum XOR occurs between element of indicies(0-based) 1 and 2 i.e. 17 ^ 100
 * = 117.
 * 
 */
