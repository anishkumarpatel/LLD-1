package com.dsa.trie;
/*
Solution Approach
Build a prefXor array in which the ith element represents the xor of all elements from 0 to i. To find the xor of any subarray[l..r], 
we can just take the xor of prefXor[r] and prefXor[l-1].

To find the maximum xor subarray ending at the index i, insert the bit representation(starting from most significant bit) of 
all the elements of prefXor array upto i-1 into the trie data structure.
We have two possible cases at ith index.

The prefix itself has maximum xor.
We need to remove some prefix (ending at index from 0 to i-1).Try to have most significant bit to be set bit i.e. 1. 
As we have maintained the trie data structure of bit representation of i-1 elements of prefXor array, we can find the maximum xor 
in O(logm) where m is the maximum number present in the given array.
We can find the maximum subarray ending at every index and return the subarray, which has the maximum XOR value.
*/


/*
 Hint 1
Suppose the ith element of the prefXor array represents the xor of all elements from 0 to i. To find the xor of any subarray[l..r], 
Just take the xor of prefXor[r] and prefXor[l-1].
For every r find the index l which gives maximum xor and take the maximum of all of them.
 */
public class MaximumXORSubarray {
	public int[] solve2(int[] A) {
		int[] res = new int[2];
		int max = Integer.MIN_VALUE;
		int ans = 0;

		for (int s = 0; s < A.length; s++) {
			int xor = 0;
			for (int e = s; e < A.length; e++) {
				xor = xor ^ A[e];
				if (max <= xor) {
					if (xor == max) {
						if (res[1] - res[0] + 1 > e - s + 1) {
							res[0] = s + 1;
							res[1] = e + 1;
						}
					} else {
						max = xor;
						res[0] = s + 1;
						res[1] = e + 1;
					}
				}
			}
		}
		return res;
	}

	public int[] brute(int[] A) {
		int[] res = new int[2];
		int max = Integer.MIN_VALUE, l = Integer.MAX_VALUE;
		for (int s = 0; s < A.length; s++) {
			for (int e = s; e < A.length; e++) {
				if (max <= subArray(A, s, e)) {
					if (max == subArray(A, s, e)) {
						if (res[1] - res[0] + 1 > e - s + 1) {
							res[0] = s + 1;
							res[1] = e + 1;
						}
					} else {
						max = subArray(A, s, e);
						res[0] = s + 1;
						res[1] = e + 1;
					}
				}
			}
		}
		return res;
	}

	int subArray(int[] A, int s, int e) {
		int xor = 0;
		for (int i = s; i <= e; i++)
			xor = xor ^ A[i];
		return xor;
	}
}
