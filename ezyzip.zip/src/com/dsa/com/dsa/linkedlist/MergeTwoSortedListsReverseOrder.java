package com.dsa.linkedlist;

public class MergeTwoSortedListsReverseOrder {
	public ListNode mergeTwoLists(ListNode A, ListNode B) {
		if (A == null && B == null)
			return null;

		ListNode cur1 = A;
		ListNode cur2 = B;
		ListNode prev = null;

		while (cur1 != null && cur2 != null) {
			if (cur1.val <= cur2.val) {
				ListNode temp = cur1.next;
				cur1.next = prev;
				prev = cur1;
				cur1 = temp;
			} else {
				ListNode temp = cur2.next;
				cur2.next = prev;
				prev = cur2;
				cur2 = temp;
			}

		}
		while (cur1 != null) {
			ListNode temp = cur1.next;
			cur1.next = prev;
			prev = cur1;
			cur1 = temp;
		}
		while (cur2 != null) {
			ListNode temp = cur2.next;
			cur2.next = prev;
			prev = cur2;
			cur2 = temp;
		}
		return prev;
	}
}
