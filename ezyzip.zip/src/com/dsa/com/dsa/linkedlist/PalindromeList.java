package com.dsa.linkedlist;
import java.util.* ;

public class PalindromeList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public int brute(ListNode A) {
        List<Integer> list = new ArrayList() ;

        while(A!=null){
            list.add(A.val);
            A = A.next ;
        }
        int n = list.size() ;

        int i=0, j = n-1 ;
        while(i<=j){
             int a = list.get(i) ;
             int b = list.get(j) ;
            if(a != b )
              return 0;
            i++ ;
            j-- ;
        }
        return 1 ;
    }
	 public int lPalin(ListNode A) {
	        ListNode t = mid(A) ;
	         t = rev(t) ;
	         while(A != null && t != null){
	             if(A.val != t.val)
	               return 0;
	            A = A.next ;
	            t = t.next ;
	         }
	         return 1 ;
	    }
	    ListNode rev(ListNode A){
	       ListNode prev = null ;
	        while(A!= null){
	            ListNode temp = A.next ;
	             A.next = prev ;
	             prev = A ;
	             A = temp ;
	        }
	        return prev ;
	    }
	    ListNode mid(ListNode A){
	        ListNode slow = A ;
	        ListNode fast = A ;
	        ListNode prev = null ;

	        while(fast != null && fast.next != null){
	            prev = slow ;
	            slow = slow.next ;
	            fast = fast.next.next ;
	        }
	      //  prev = null ;
	        return slow ;
	    }
}
