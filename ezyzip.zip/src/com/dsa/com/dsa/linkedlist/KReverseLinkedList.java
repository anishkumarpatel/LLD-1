package com.dsa.linkedlist;

public class KReverseLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	static ListNode reverseList(ListNode A, int B) {

		ListNode head = A, prev = null;
		int c = 0;
		while (c < B && head != null) {
			c++;
			ListNode temp = head.next;
			head.next = prev;
			prev = head;
			head = temp;
		}
		if (head != null)
			A.next = reverseList(head, B);

		return prev;
	}

	static class ListNode {
		public int val;
		public ListNode next;

		ListNode(int x) {
			val = x;
			next = null;
		}
	}

}
