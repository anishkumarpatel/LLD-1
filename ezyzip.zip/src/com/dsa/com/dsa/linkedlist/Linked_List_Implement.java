package com.dsa.linkedlist;

public class Linked_List_Implement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	 static class Node{
	        int data;
	        Node next;
	        Node(int x)
	        {
	            data = x ;
	            next = null ;
	        }
	    }
	    static Node head = new Node(1) ;
	    public static void insert_node(int position, int value) {
	        // @params position, integer
	        // @params value, integer
	        position -=1 ;

	        if(position<0) return ;
	        Node node = head ;
	        while(position>0){
	          position -= 1;
	          if(node.next == null) break ;
	          node = node.next ;
	        }
	        Node t = node.next;
	        node.next = new Node(value) ;
	        node.next.next = t;
	    }

	    public static void delete_node(int position) {
	        // @params position, integer
	        position -= 1;

	        if(position<0) return ;
	        Node node = head ;
	        while(position>0){
	            position -= 1;
	            node = node.next ;
	            if(node == null) return ;
	        }
	        if(node.next != null){
	        Node prev = node ;
	        Node cur = node.next ;
	        prev.next = cur.next ;
	        cur.next = null ;
	        }
	    }

	    public static void print_ll() {
	        // Output each element followed by a space
	        Node node = head.next ;

	        while(node != null)
	        {
	            System.out.print(node.data);
	            node = node.next ;
	            if(node != null)
	            System.out.print(" ") ;
	        }
	    }

}
