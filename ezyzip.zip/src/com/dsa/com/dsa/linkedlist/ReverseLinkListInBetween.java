package com.dsa.linkedlist;

public class ReverseLinkListInBetween {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	class ListNode {
		public int val;
		public ListNode next;

		ListNode(int x) {
			val = x;
			next = null;
		}
	}

	public ListNode reverseBetween(ListNode A, int B, int C) {
		ListNode cur = A;
		int c = 0;
		ListNode newHead = null;
		ListNode newTal = null;
		while (cur != null) {
			c++;
			ListNode flag = cur;
			if (c == B) {
				ListNode prev = null;
				ListNode cur1 = cur;
				for (; c <= C; c++) {
					ListNode temp = cur1.next;
					cur1.next = prev;
					prev = cur1;
					cur1 = temp;
				}
				if (newHead == null) 
					newHead = prev;

				if (newTal != null)
					newTal.next = prev;

				newTal = flag;

				if (cur1 != null)
					newTal.next = cur1;

			} else if (newHead == null) {
				newHead = cur;
				newTal = cur;
			} else
				newTal = cur;

			// if(cur != null)
			cur = cur.next;
		}
		return newHead;
	}

}
