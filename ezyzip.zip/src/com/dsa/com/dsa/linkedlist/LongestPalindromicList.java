package com.dsa.linkedlist;

public class LongestPalindromicList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public int solve(ListNode A) {
        ListNode cur = A;
        ListNode prev = null ;
        int max = Integer.MIN_VALUE ;

        while(cur != null){
            ListNode prevItr = prev, nextItr = cur.next ;
            int l=1;  // odd length;
            while(prevItr != null && nextItr != null)
             if(prevItr.val == nextItr.val){
                 prevItr = prevItr.next;
                 nextItr = nextItr.next;
                 l++;
             }else break ;

            max = Math.max(max,2*l-1) ;
            prevItr = prev; nextItr = cur;
            l=0;
            while(prevItr != null && nextItr != null)
             if(prevItr.val == nextItr.val){
                 prevItr = prevItr.next;
                 nextItr = nextItr.next;
                 l++;
             }else break ;

              max = Math.max(max,2*l) ;

              ListNode temp = cur.next;
               cur.next = prev;
               prev = cur ;
               cur = temp ;
        }
        return max ;
    }
}
