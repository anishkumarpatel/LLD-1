package com.dsa.linkedlist;

public class MergeTwoSortedLists {

	public static void main(String[] args) {
		
	}
	 static ListNode mergeTwoLists(ListNode A, ListNode B) {
	        ListNode dummy = new ListNode(-1) ;
	        ListNode cur = dummy ;

	        while(A != null && B != null){
	            if(A.val < B.val){
	                cur.next = A;
	                A = A.next ;
	            }else{
	                cur.next = B ;
	                 B = B.next ;
	            }
	            cur = cur.next ;
	        }
	        if(A != null)
	         cur.next = A;
	      else
	       cur.next = B ;

	     return dummy.next ;
	    }

}
