package com.dsa.linkedlist;

public class ReorderList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public ListNode brute(ListNode A) {
        ListNode cur = A;

        while(cur != null){
            ListNode next = cur.next ;
            ListNode prev = null ;
            ListNode cur1 = cur ;
            while(cur1.next != null){
                prev = cur1 ;
                cur1 = cur1.next ;
            }
            if(prev != null)
             prev.next = null ;
           cur.next = cur1 ;
           cur = cur.next ;
           if(cur != next)
           cur.next = next ;

           cur = next ;
        }
        return A;
    }
	//SIDHARTH PANTULA CODE

	// APPROACH IS SIMPLE ! DIVIDE THE LIST INTO 2 BY THE MID POINT.
	// REVERSE THE SECOND LIST
	// THEN MERGE THESE 2 LISTS. I USED DUMMY HEAD TO MERGE

	public class Solution {
	    public ListNode reverse(ListNode A)
	    {
	        ListNode prev=null;
	        ListNode curr=A;
	        while(curr.next!=null)
	        {
	            ListNode temp=curr.next;
	            curr.next=prev;
	            prev=curr;
	            curr=temp;
	        }
	        curr.next=prev;
	        return curr;
	    }
	    public ListNode midfunc(ListNode A)
	    {
	        ListNode fast=A;
	        ListNode slow=A;
	        while(fast.next!=null && fast.next.next!=null)
	        {
	            fast=fast.next.next;
	            slow=slow.next;
	        }
	        return slow;
	    }
	    public ListNode merge(ListNode firsthead,ListNode secondhead)
	    {
	       
	        ListNode dummyhead=new ListNode(10);
	        ListNode temp=dummyhead;
	        while(firsthead!=null)
	        {
	            temp.next=firsthead;
	            temp=firsthead;
	            firsthead=firsthead.next;
	           
	            if(secondhead!=null)
	            {
	            temp.next=secondhead;
	            temp=secondhead;
	            secondhead=secondhead.next;
	            }

	        }
	        return dummyhead.next;
	    }
	    public ListNode reorderList(ListNode A) {
	        if(A==null || A.next==null || A.next.next==null)
	        {
	            return A;
	        }
	        ListNode mid=midfunc(A);
	        ListNode secondhead=mid.next;
	        ListNode firsthead=A;
	        mid.next=null;
	        secondhead=reverse(secondhead);
	        return merge(firsthead,secondhead);
	       // return secondhead;
	    }
	}
}
