package com.dsa.linkedlist;

public class SortList {
	
	/*
	 * We can try to implement either merge sort or qsort.
	 * 
	 * Let us look at the merge sort. We start traversing the singly linked list to
	 * find the midpoint of the singly linked list. Now, we will sort the first half
	 * and second half separately by calling the merge sort function on them. Then
	 * we only have to merge the 2 lists ( Note that we already have solved a
	 * problem to merge 2 lists ).
	 */
	
	 public ListNode sortList(ListNode A) {
	        if(A == null || A.next == null) return A;

	        ListNode slow = A ;
	        ListNode head = A ;
	        ListNode fast = A ;
	        ListNode temp = null ;

	        while(fast != null && fast.next != null){
	            temp = slow ;
	            slow = slow.next ;
	            fast = fast.next.next ;
	        }
	           temp.next = null ;
	           ListNode temp1 =  sortList(head);
	           ListNode temp2 =  sortList(slow) ;
	           ListNode sorted = mergeTwoLists(temp1,temp2);
	           
	           return sorted ;
	    }
	    public ListNode mergeTwoLists(ListNode A, ListNode B) {
	        ListNode dummy = new ListNode(-1) ;
	        ListNode cur = dummy ;

	        while(A != null && B != null){
	            if(A.val < B.val){
	                cur.next = A;
	                A = A.next ;
	            }else{
	                cur.next = B ;
	                 B = B.next ;
	            }
	            cur = cur.next ;
	        }
	        if(A != null)
	         cur.next = A;
	      else
	       cur.next = B ;

	     return dummy.next ;
	    }
}
