package com.dsa.linkedlist;
import java.util.Scanner;
public class Linked {
	public static void main(String[] args) {
		
	Node head = create1(1);
	}

	static Node create1(int n) {
		Node h1 = new Node(5) ;
		Node h2 = new Node(10) ;
		Node h3 = new Node(15) ;
		Node h4 = new Node(24) ;
		Node h5 = new Node(40) ;
         Node head = h1;  
		h1.next = h2;
          h2.next= h3;
          h3.next = h4;
          h4.next = h5;
          System.out.println(head.next+" ");
         for(int i=0; i<3-1; i++) {
        	  System.out.print(head.next+" ");
        	  head = head.next;
          }
		return head;
	}
}
class Node {
	Node next;
	int data;

	Node(int x) {
		data = x;
		next = null;
	}
}


