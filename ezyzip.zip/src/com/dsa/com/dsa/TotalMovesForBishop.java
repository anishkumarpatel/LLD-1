package com.dsa;

public class TotalMovesForBishop {

	public static void main(String[] args) {
		System.out.println(best(4, 4));
		System.out.println(Describe(4, 4));
	}

	static int best(int A, int B) {
		return Math.min(Math.abs(8 - A), Math.abs(8 - B)) + Math.min(Math.abs(8 - A), Math.abs(1 - B))
				+ Math.min(Math.abs(1 - A), Math.abs(1 - B)) + Math.min(Math.abs(1 - A), Math.abs(8 - B));
	}

	static int Describe(int A, int B) {
		int topLeft = 0;
		int topRight = 0;
		int bottomLeft = 0;
		int bottomRight = 0;

		int A2 = A;
		int B2 = B;
		// Calc top left
		while (A > 1 && B < 8) {
			topLeft++;
			A--;
			B++;
		}
		A = A2;
		B = B2;

		while (A < 8 && B < 8) {
			topRight++;
			A++;
			B++;
		}

		A = A2;
		B = B2;

		while (A > 1 && B > 1) {
			bottomLeft++;
			A--;
			B--;
		}

		A = A2;
		B = B2;

		while (A < 8 && B > 1) {
			bottomRight++;
			A++;
			B--;
		}

		return topLeft + topRight + bottomLeft + bottomRight;
	}

}
