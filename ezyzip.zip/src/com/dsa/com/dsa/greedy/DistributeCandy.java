package com.dsa.greedy;

/*
 Problem Description
N children are standing in a line. Each child is assigned a rating value.

You are giving candies to these children subjected to the following requirements:

Each child must have at least one candy.
Children with a higher rating get more candies than their neighbors.
What is the minimum number of candies you must give?



Problem Constraints
1 <= N <= 105
-109 <= A[i] <= 109



Input Format
The first and only argument is an integer array A representing the rating of children.



Output Format
Return an integer representing the minimum candies to be given.



Example Input
Input 1:

 A = [1, 2]
Input 2:

 A = [1, 5, 2, 1]


Example Output
Output 1:

 3
Output 2:

 7


Example Explanation
Explanation 1:

 The candidate with 1 rating gets 1 candy and candidate with rating 2 cannot get 1 candy as 1 is its neighbor. 
 So rating 2 candidate gets 2 candies. In total, 2 + 1 = 3 candies need to be given out.
Explanation 2:

 Candies given = [1, 3, 2, 1]
 */
import java.util.*;

public class DistributeCandy {
	public int candy(int[] A) {
		int n = A.length;
		int[] left = new int[n];
		Arrays.fill(left, 1);

		for (int i = 1; i < n; i++) {
			if (A[i] > A[i - 1])
				left[i] = 1 + left[i - 1];
		}
		int[] right = new int[n];
		Arrays.fill(right, 1);

		for (int i = n - 2; i >= 0; i--) {
			if (A[i] > A[i + 1])
				right[i] = 1 + right[i + 1];
		}
		/*
		 * why we took Math.max(candy[i], candy[i+1]+1); instead of Math.min(candy[i],
		 * 
		 * 
		 * candy[i+1]+1); The reason why we use Math.max(candy[i], candy[i+1]+1) instead
		 * of Math.min(candy[i], candy[i+1]+1) is because we need to make sure that the
		 * current child gets at least one more candy than its right neighbor if the
		 * rating of the current child is greater than its right neighbor.
		 * 
		 * If we used Math.min, it would give the current child fewer candies than its
		 * right neighbor, which would violate the condition that children with higher
		 * ratings should get more candies than their neighbors. So, using Math.max
		 * ensures that we give the current child at least one more candy than its right
		 * neighbor while maintaining the minimum number of candies required.
		 */
		for (int i = 0; i < n; i++)
			left[i] = Math.max(left[i], right[i]);

		int ans = 0;
		for (int a : left)
			ans += a;
		return ans;
	}
}
/*
 * according to the problem both statement are same :-
 * "What is the minimum number of candies you must give?" or
 * "What is the maximum number of candies you must give?" No, the two statements
 * have different meanings.
 * 
 * "What is the minimum number of candies you must give?" means that you need to
 * give out the minimum possible number of candies to satisfy the conditions.
 * 
 * "What is the maximum number of candies you must give?" means that you need to
 * give out the maximum possible number of candies while still satisfying the
 * conditions.
 * 
 * These are opposite objectives - in one case you want to minimize, and in the
 * other you want to maximize, the number of candies given.
 * 
 * 
 * 
 * 
 * ANISH PATEL give me java code for both Sure, here's the Java code for both
 * the minimum and maximum number of candies you must give:
 * 
 * Minimum number of candies:
 * 
 * java public int candyMin(int[] A) { int n = A.length; int[] candies = new
 * int[n]; Arrays.fill(candies, 1);
 * 
 * // Scan from left to right for (int i = 1; i < n; i++) { if (A[i] > A[i - 1])
 * { candies[i] = candies[i - 1] + 1; } }
 * 
 * // Scan from right to left for (int i = n - 2; i >= 0; i--) { if (A[i] > A[i
 * + 1]) { candies[i] = Math.max(candies[i], candies[i + 1] + 1); } }
 * 
 * int sum = 0; for (int i = 0; i < n; i++) { sum += candies[i]; } return sum; }
 * 
 * Maximum number of candies:
 * 
 * public int candyMax(int[] A) { int n = A.length; int[] candies = new int[n];
 * Arrays.fill(candies, 1);
 * 
 * // Scan from left to right for (int i = 1; i < n; i++) { if (A[i] > A[i - 1])
 * { candies[i] = candies[i - 1] + 1; } }
 * 
 * // Scan from right to left for (int i = n - 2; i >= 0; i--) { if (A[i] > A[i
 * + 1]) { candies[i] = candies[i + 1] + 1; } }
 * 
 * int sum = 0; for (int i = 0; i < n; i++) { sum += candies[i]; } return sum; }
 * 
 */
