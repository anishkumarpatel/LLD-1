package com.dsa.string;

/*
 
 Approach:-
 Since there are 26 characters we can find frequency of each character.
Sort them in ascending order. Since we have to minimize the number of distinct characters, we will change characters whose frequency is less into the character which has the highest frequency.
We will check the maximum number of distinct characters we can successfully change.
 
 Problem Description
You are given a string A of size N consisting of lowercase alphabets.

You can change at most B characters in the given string to any other lowercase alphabet such that the number of distinct characters in the string is minimized.

Find the minimum number of distinct characters in the resulting string.



Problem Constraints
1 <= N <= 100000

0 <= B < N



Input Format
The first argument is a string A.

The second argument is an integer B.



Output Format
Return an integer denoting the minimum number of distinct characters in the string.



Example Input
A = "abcabbccd"
B = 3



Example Output
2



Example Explanation
We can change both 'a' and one 'd' into 'b'.So the new string becomes "bbcbbbccb".
So the minimum number of distinct character will be 2.




Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A single String, For e.g 'anagram'
Enter Input Here
Arg 2: A single Integer, For e.g 9
Enter Input Here

 */

import java.util.*;

public class ChangeCharacter {
	public int solve(String A, int B) {
		int[] c = new int[26];

		for (int i = 0; i < A.length(); i++) {
			char ch = A.charAt(i);
			c[ch - 'a']++;
		}

		Arrays.sort(c);

		int count = 0;

		for (int x : c) {
			if (x > B)
				count++;
			else
				B -= x;
		}
		if (count == 0)
			return 1;
		return count;
	}
}
