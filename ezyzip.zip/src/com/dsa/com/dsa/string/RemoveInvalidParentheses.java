package com.dsa.string;

public class RemoveInvalidParentheses {
	public static void main(String... args) {
		String s = "a)b(c)d(e";
		System.out.println(parenthesis(s));
	}

	static String parenthesis(String s) {
		char[] c = s.toCharArray();
		int count = 0;
		for (int i = 0; i < c.length; i++) {
			if (c[i] == '(')
				count++;
			else if (c[i] == ')') {
				if (count > 0) {
					count--;
				} else
					c[i] = 0;
			}
		}
		// C:\Users\Admin\OneDrive\Desktop\javac>java Test
		// ab(c)de
		count = 0;
		for (int i = c.length - 1; i >= 0; i--) {
			if (c[i] == ')')
				count++;
			else if (c[i] == '(') {
				if (count > 0) {
					count--;
				} else
					c[i] = 0;
			}
		}
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < c.length; i++) {
			if (c[i] != 0)
				sb.append(c[i]);
		}
		return sb.toString();
	}
}
