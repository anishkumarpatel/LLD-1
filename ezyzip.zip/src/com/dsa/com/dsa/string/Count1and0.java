package com.dsa.string;

public class Count1and0 {
	public class Solution {
	    public int solve(String A) {
	        int n = A.length();
	        int count=0;
	        
	        for(int i=0; i<n; i++){
	            char c = A.charAt(i);
	            if('1' == c )
	             count++ ;
	        }
	        return (count*(count-1))/2 + count;
	    }
	    
	}
	//We know that if count of 1’s is m, then there will be m * (m – 1) / 2 possible subarrays.
}
