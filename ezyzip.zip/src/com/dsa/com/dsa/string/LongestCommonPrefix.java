package com.dsa.string;

/*
 Approach
 Note: the prefix has to be the prefix of ALL the strings.

So, you can pick any random string from the array and start checking its characters from the beginning to see if they can be a part of the common substring.

Take 5-10 mins to reflect on the hint given and relate it to what you have learned to figure out the solution on your own. If you're still having trouble, then move on to the next hint. Remember that the more you challenge yourself to think critically about the concepts and solve problems on your own, the better you will understand and remember the material.


 Problem Description
Given the array of strings A, you need to find the longest string S, which is the prefix of ALL the strings in the array.

The longest common prefix for a pair of strings S1 and S2 is the longest string S which is the prefix of both S1 and S2.

Example: the longest common prefix of "abcdefgh" and "abcefgh" is "abc".



Problem Constraints
0 <= sum of length of all strings <= 1000000



Input Format
The only argument given is an array of strings A.



Output Format
Return the longest common prefix of all strings in A.



Example Input
Input 1:

A = ["abcdefgh", "aefghijk", "abcefgh"]
Input 2:

A = ["abab", "ab", "abcd"];


Example Output
Output 1:

"a"
Output 2:

"ab"


Example Explanation
Explanation 1:

Longest common prefix of all the strings is "a".
Explanation 2:

Longest common prefix of all the strings is "ab".



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A String Array, For e.g ['hello','world']
Enter Input Here
Arg 2: A single String, For e.g 'anagram'
Enter Input Here

 
 */
public class LongestCommonPrefix {
	public String longestCommonPrefix(String[] A) {
		int length = A.length, min = Integer.MAX_VALUE;

		for (int i = 0; i < length; i++)
			if (min > A[i].length())
				min = A[i].length();

		StringBuilder stringBuilder = new StringBuilder();

		for (int i = 0; i < min; i++) {
			boolean flag = true;

			char ch = A[0].charAt(i);

			for (int j = 1; j < A.length; j++)
				if (ch != A[j].charAt(i))
					return stringBuilder.toString();
			if (flag)
				stringBuilder.append(A[0].charAt(i));
		}
		return stringBuilder.toString();
	}
	/*
	 * Therefore, the total time complexity is O(N * M).
	 * 
	 * The space complexity of the function is O(1) because the space used is
	 * constant throughout the execution. There are no data structures or arrays
	 * created that scale with the input size.
	 * 
	 * So, in summary:
	 * 
	 * Time complexity: O(N * M) Space complexity: O(1)
	 */
}
