package com.dsa.string;

/*
 Approach
 The main idea to solve this problem is to traverse the string and when you encounter a vowel, add ( length(string) - position_of_curr_char ) to the answer.

Take 5-10 mins to reflect on the hint given and relate it to what you have learned to figure out the solution on your own. If you're still having trouble, then move on to the next hint. Remember that the more you challenge yourself to think critically about the concepts and solve problems on your own, the better you will understand and remember the material.


 You are given a string S, and you have to find all the amazing substrings of S.

An amazing Substring is one that starts with a vowel (a, e, i, o, u, A, E, I, O, U).

Input

Only argument given is string S.
Output

Return a single integer X mod 10003, here X is the number of Amazing Substrings in given the string.
Constraints

1 <= length(S) <= 1e6
S can have special characters
Example

Input
    ABEC

Output
    6

Explanation
    Amazing substrings of given string are :
    1. A
    2. AB
    3. ABE
    4. ABEC
    5. E
    6. EC
    here number of substrings are 6 and 6 % 10003 = 6.
Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases

 */
public class AmazingSubarrays {
	public int solve(String A) {
		int n = A.length();

		long ans = 0;

		for (int i = 0; i < n; i++) {
			char ch = A.charAt(i);
			if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I'
					|| ch == 'O' || ch == 'U')
				ans += n - i;
			// ans = ans%10003 ;
		}

		return (int) (ans % 10003);
	}
}
