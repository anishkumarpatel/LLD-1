package com.dsa.string;

/*
 
 A simpler approach, O(N2) time and O(1) space:

In fact, we could solve it in O(N2) time without any extra space.

We observe that a palindrome mirrors around its center. Therefore, a palindrome can be expanded from its center, and there are only 2N-1 such centers.

You might be asking why there are 2N-1 but not N centers?

The reason is that the center of a palindrome can be in between two letters.

Such palindromes have even number of letters (such as “abba”) and their center are between the two ‘b’s.

Since expanding a palindrome around its center could take O(N) time, the overall complexity is O(N2).

Take 5-10 mins to reflect on the hint given and relate it to what you have learned to figure out the solution on your own. If you're still having trouble, then move on to the next hint. Remember that the more you challenge yourself to think critically about the concepts and solve problems on your own, the better you will understand and remember the material.
 
 Problem Description
Given a string A of size N, find and return the longest palindromic substring in A.

Substring of string A is A[i...j] where 0 <= i <= j < len(A)

Palindrome string:
A string which reads the same backwards. More formally, A is palindrome if reverse(A) = A.

Incase of conflict, return the substring which occurs first ( with the least starting index).



Problem Constraints
1 <= N <= 6000



Input Format
First and only argument is a string A.



Output Format
Return a string denoting the longest palindromic substring of string A.



Example Input
Input 1:
A = "aaaabaaa"
Input 2:
A = "abba


Example Output
Output 1:
"aaabaaa"
Output 2:
"abba"


Example Explanation
Explanation 1:
We can see that longest palindromic substring is of length 7 and the string is "aaabaaa".
Explanation 2:
We can see that longest palindromic substring is of length 4 and the string is "abba".



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A single String, For e.g 'anagram'
Enter Input Here
Arg 2: A single String, For e.g 'anagram'
Enter Input Here

 */

public class LongestPalindromicSubstring {
	public String longestPalindrome(String A) {
		String s = "";

		for (int i = 0; i < A.length(); i++) {
			String ans = expand(A, i, i);

			if (ans.length() > s.length())
				s = ans;

			ans = expand(A, i, i + 1);

			if (ans.length() > s.length())
				s = ans;
		}
		return s;
	}

	String expand(String A, int p1, int p2) {
		while (p1 >= 0 && p2 < A.length() && A.charAt(p1) == A.charAt(p2)) {
			p1--;
			p2++;
		}
		return A.substring(p1 + 1, p2);
	}
}
