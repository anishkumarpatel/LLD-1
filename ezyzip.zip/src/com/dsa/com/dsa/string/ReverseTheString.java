package com.dsa.string;

/*
 Solution Approach
One simple approach is a two-pass solution:

First pass to split the string by spaces into an array of words
Then second pass to extract the words in reversed order
We can do better in one-pass. While iterating the string in reverse order, we keep track of a word’s beginning and end position.

When we are at the beginning of a word, we append it.

 Problem Description
You are given a string A of size N.

Return the string A after reversing the string word by word.

NOTE:

A sequence of non-space characters constitutes a word.
Your reversed string should not contain leading or trailing spaces, even if it is present in the input string.
If there are multiple spaces between words, reduce them to a single space in the reversed string.


Problem Constraints
1 <= N <= 3 * 105



Input Format
The only argument given is string A.



Output Format
Return the string A after reversing the string word by word.



Example Input
Input 1:
A = "the sky is blue"
Input 2:
A = "this is ib"


Example Output
Output 1:
"blue is sky the"
Output 2:
"ib is this"    


Example Explanation
Explanation 1:
We reverse the string word by word so the string becomes "blue is sky the".
Explanation 2:
We reverse the string word by word so the string becomes "ib is this".



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
 */

public class ReverseTheString {
	public String solve1(String A) {
		A = A.trim();

		String[] s = A.split(" ");

		String sb = "";

		for (int i = s.length - 1; i >= 0; i--)
			sb += s[i] + " ";

		return sb.trim();
	}

	public String solve(String A) {

		A = A.trim();
		int n = A.length();
		String rev = "";

		int i = n - 1, j = n;
		while (i >= 0) {
			if (A.charAt(i) == ' ') {
				rev = rev + A.substring(i + 1, j) + ' ';
				j = i;
			}
			i--;
		}
		rev = rev + A.substring(0, j);
		return rev;
	}
}
