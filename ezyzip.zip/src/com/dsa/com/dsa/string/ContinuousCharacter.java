package com.dsa.string;

public class ContinuousCharacter {
	public int brute(String A, int B, String C) {
		int n = A.length();
		int ans = 0;
		for (int i = 0; i < n; i++) {
			int match = 0, other = 0;
			for (int j = i; j < n; j++) {
				char c = C.charAt(0);
				char a = A.charAt(j);
				if (a == c)
					match++;
				else
					other++;
				if (other <= B)
					ans = Math.max(ans, j - i + 1);
			}
		}
		return ans;
	}

	public int optimised(String A, int B, String C) {
		int n = A.length();
		char c = C.charAt(0);
		int p1 = 0, p2 = 0;
		int ans = 0;
		String s="";
		int match = 0, other = 0;
		for (p1 = 0; p1 < n; p1++) {
			char ch = A.charAt(p1);
			if (c != ch)
				other++;
			if (other > B) {
				if (A.charAt(p2) != c)
					other--;
				p2++;
			}
			if(ans<p1-p2+1)
			{
				ans = p1-p2+1;
				s = A.substring(p2,p1+1);
			}
		}
		System.out.println(s);
		return ans;
	}
}
/*
 * Contiguous character:-
 * 
 * You are given a string A, tell how many continuous character c you can get in
 * a given string? You are allowed to do at most B numbers of changes in the
 * string. A change is defined as changing a character at any index in the given
 * string
 * 
 * Hint 1 check for each substring will result in tle to try to be smart and use
 * two pointers approach try to maintain a window of continuous character c,
 * using a left and right pointers
 * 
 * Solution Approach :-
 * 
 * Take a left and right pointers , both initialized to zero. Now traverse
 * string s, for each i th character if character is same as C, move right
 * pointers forward if ith character not same as character C, decrement numbers
 * of changes B by one and move right pointers forward if numbers B is become
 * zero move left pointers forward. By doing this return maximum window length
 * you can achieve.
 * 
 */