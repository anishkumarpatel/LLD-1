
package com.dsa;

public class Single2 {

	public static void main(String[] args) {
		int a[] = { 1, 1, 2, 2, 3, 3, 7, 18 };

		int res[] = single11(a);
		System.out.println(res[0] + " " + res[1]);

		int re[] = singleNumber(a);

		System.out.println(re[0] + " " + re[1]);
		// int []a1 = {10, 8, 8, 9, 12, 9, 6, 11, 10, 6, 12, 17};
	}

	static int[] single11(int a[]) {

		int xor = 0;
		for (int ans : a)
			xor ^= ans;

		int pos = checkBit1(xor, 3);

		System.out.println(pos + " ");
		int a1[] = new int[2];
		for (int ele : a)
			if (checkBit2(ele, pos))
				a1[0] ^= ele;
			else
				a1[1] ^= ele;

		return a1;
	}

	static int checkBit1(int xor, int i) {
		while ((xor & (1 << i++)) == 0)
			;
		--i;
		System.out.println(i + " i");
		System.out.println("shift " + (4 & (1 << 2)));
		return i;
	}

	static boolean checkBit2(int ele, int pos) {
		if (((ele >> pos) & 1) == 0)
			return true;
		else
			return false;
	}

	static int[] singleNumber(int[] nums) {
		int xor2no = 0;
		for (int num : nums) {
			xor2no ^= num;
		}
		int lowestBit = xor2no & (-xor2no);

		int[] result = new int[2];
		for (int num : nums) {
			if ((lowestBit & num) == 0) {
				result[0] ^= num;
			} else {
				result[1] ^= num;
			}
		}
		return result;
	}
}
