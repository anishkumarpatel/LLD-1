package com.dsa.bst;

public class SortedArrayToBalancedBST {
	public TreeNode sortedArrayToBST(final int[] A) {
        return buildBST(A,0,A.length-1) ;
    }   
    TreeNode buildBST(int[] A,int s,int e){
        if(s>e) return null;

        int mid = s + (e-s)/2 ;
        TreeNode root = new TreeNode(A[mid]) ;
        root.left = buildBST(A,s,mid-1);
        root.right = buildBST(A,mid+1,e);

        return root ;
    }
}
