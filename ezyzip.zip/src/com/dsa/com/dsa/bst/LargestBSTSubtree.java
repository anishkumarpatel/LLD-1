package com.dsa.bst;

public class LargestBSTSubtree {
	class Pair {
		boolean isBST;
		int max;
		int min;
		int size;

		Pair(boolean is, int n, int mn, int mx) {
			isBST = is;
			size = n;
			min = mn;
			max = mx;
		}
	}
	public int solve(TreeNode A) {
		Pair p = large(A);
		return p.size;
	}

	Pair large(TreeNode A) {
		if (A == null)
			return new Pair(true, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);

		Pair lst = large(A.left);
		Pair rst = large(A.right);

		if (lst.isBST && rst.isBST && lst.min < A.val && rst.max > A.val)
			return new Pair(true, lst.size + rst.size + 1, Math.max(A.val, lst.min), Math.min(A.val, rst.max));
		else
			return new Pair(false, Math.max(lst.size, rst.size), 0, 0);
	}
}