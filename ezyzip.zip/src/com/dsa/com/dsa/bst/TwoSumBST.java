package com.dsa.bst;

import java.util.*;

public class TwoSumBST {

	boolean check = false;
	HashSet<Integer> set = new HashSet();

	public int t2Sum1(TreeNode A, int B) { // brute
		inOrder(A, B);

		if (check)
			return 1;
		else
			return 0;
	}

	void inOrder(TreeNode A, int B) {
		if (A == null)
			return;

		inOrder(A.left, B);

		if (set.contains(B - A.val))
			check = true;
		else
			set.add(A.val);

		inOrder(A.right, B);
	}

	public int t2Sum(TreeNode A, int B) {
		Stack<TreeNode> front = new Stack<>();
		Stack<TreeNode> rear = new Stack<>();
		TreeNode cur1 = A;
		TreeNode cur2 = A;

		while ((front.size() > 0 || cur1 != null) || (rear.size() > 0 || cur2 != null)) {
			if (cur1 != null || cur2 != null) {
				if (cur1 != null) {
					front.push(cur1);
					cur1 = cur1.left;
				}
				if (cur2 != null) {
					rear.push(cur2);
					cur2 = cur2.right;
				}
			} else {
				if (front.size() == 0 || rear.size() == 0)
					break;

				TreeNode node1 = front.peek();
				TreeNode node2 = rear.peek();

				int x = node1.val;
				int y = node2.val;
				if (x == y)
					return 0;

				if (x + y == B)
					return 1;

				if (x + y < B) {
					front.pop();
					cur1 = node1.right;
				} else {
					rear.pop();
					cur2 = node2.left;
				}
			}
		}
		return 0;
	}
}
