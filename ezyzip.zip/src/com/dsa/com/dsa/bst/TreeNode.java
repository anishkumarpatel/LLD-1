package com.dsa.bst;

public class TreeNode {

	public TreeNode left;
	public TreeNode right;
	public int val;

	TreeNode(int x) {
		val = x;
		left = null;
		right = null;
	}
}
