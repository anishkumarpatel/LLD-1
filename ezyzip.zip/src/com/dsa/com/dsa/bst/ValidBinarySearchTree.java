package com.dsa.bst;

import java.util.*;

public class ValidBinarySearchTree {
	public int isValidBSTaa(TreeNode A) {
		ArrayList<Integer> a = new ArrayList();
		TreeNode cur = A;
		Stack<TreeNode> s = new Stack();

		while (cur != null || !s.isEmpty()) {
			while (cur != null) {
				s.push(cur);
				cur = cur.left;
			}
			cur = s.pop();
			a.add(cur.val);
			cur = cur.right;
		}
		for (int i = a.size() - 1; i > 0; i--)
			if (a.get(i) <= a.get(i - 1))
				return 0;
		return 1;
	}

	TreeNode prev;
	int isBST = 1;

	public int isValidBST(TreeNode A) {
		if (A != null) {
			isValidBST(A.left);

			if (prev != null && prev.val >= A.val)
				isBST = 0;
			prev = A;

			isValidBST(A.right);
		}
		return isBST;
	}

	public int isValidBST1(TreeNode A) {
		boolean b = isBST(A, Integer.MIN_VALUE, Integer.MAX_VALUE);
		if (b)
			return 1;
		else
			return 0;
	}

	boolean isBST(TreeNode A, int min, int max) {
		if (A == null)
			return true;

		if (A.val < min || A.val > max)
			return false;

		boolean i = isBST(A.left, min, A.val - 1);
		boolean j = isBST(A.right, A.val + 1, max);

		return i && j;
	}

	//// brute force
	public int isValidBST2(TreeNode A) {
		if (A == null)
			return 1;

		if (A.left != null && getMAX(A.left) >= A.val)
			return 0;

		if (A.right != null && getMIN(A.right) <= A.val)
			return 0;

		if (isValidBST(A.left) != 1 || isValidBST(A.right) != 1)
			return 0;

		return 1;
	}

	int getMAX(TreeNode A) {
		if (A == null)
			return Integer.MIN_VALUE;

		int value = A.val;
		int left = getMAX(A.left);
		int right = getMAX(A.right);

		return Math.max(value, Math.max(left, right));
	}

	int getMIN(TreeNode A) {
		if (A == null)
			return Integer.MAX_VALUE;

		int value = A.val;
		int left = getMIN(A.left);
		int right = getMIN(A.right);

		return Math.min(value, Math.min(left, right));
	}
}
