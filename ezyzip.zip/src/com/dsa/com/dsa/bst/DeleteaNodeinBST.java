package com.dsa.bst;

public class DeleteaNodeinBST {

	public TreeNode solve(TreeNode A, int B) {
		if (A == null)
			return A;

		if (B < A.val)
			A.left = solve(A.left, B);
		else if (B > A.val)
			A.right = solve(A.right, B);
		else {

			if (A.left == null)
				return A.right;

			if (A.right == null)
				return A.left;

			A.val = getMax(A.left);

			A.left = solve(A.left, A.val);
		}
		return A;
	}

	int getMax(TreeNode A) {
		int max = A.val;
		while (A.right != null) {
			max = A.right.val;
			A = A.right;
		}
		return max;
	}
}
