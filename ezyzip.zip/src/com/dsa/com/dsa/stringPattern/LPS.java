package com.dsa.stringPattern;

public class LPS {

	public static void main(String[] args) {
		String s =  "abc$cba" ;
		
		int lps1[] = lps(s);
		  for(int i=0; i<lps1.length; i++)
		System.out.print(lps1[i]+" ");
	}
	
	static int[] lps(String s)
	{
		int n = s.length();
		
		int lps[] = new int[n];
		
		lps[0] = 0;
		
		for(int i=1; i<n; i++)
		{
			int x = lps[i-1];
			
			while(s.charAt(x) != s.charAt(i))
			{
				if(x == 0) {
					x = -1;
					break;
				}
				x = lps[x-1];
			}
			lps[i] = x+1;
		}
		return lps;
	}
	int[] computeLPS(String s) {
        int l = 0, i = 1;
        int lps[] = new int[s.length()];
        while (i < s.length()) {
            if (s.charAt(i) == s.charAt(l)) {
                lps[i] = ++l;
                i++;
            } else {
                if (l > 0) {
                    l = lps[l - 1];
                } else {
                    lps[i] = 0;
                    i++;
                }
            }
        }
        return lps;
    }
}
// time com = O(n)"AACECAAAA$AAAACECAA"
//{0, 1, 0, 0, 0, 1, 2, 2, 2, 0, 1, 2, 2, 2, 3, 4, 5, 6, 7} gfg
//{0, 1, 0, 0, 0, 1, 2, 2, 2, 0, 1, 2, 2, 2, 3, 4, 5, 6, 7} myOutput