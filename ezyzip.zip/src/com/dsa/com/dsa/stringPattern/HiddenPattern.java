package com.dsa.stringPattern;

public class HiddenPattern {
	/*
	 * 
	 * Problem Description
	 * 
	 * Given two strings - a text A and a pattern B, having lower-case alphabetic
	 * characters. You have to determine the number of occurrences of pattern B in
	 * text A as its substring. i.e. the number of times B occurs as a substring in
	 * A.
	 * 
	 * 
	 * 
	 * Problem Constraints
	 * 
	 * 1 <= |B| <= |A| <= 105
	 * 
	 * 
	 * 
	 * Input Format
	 * 
	 * First argument is a string A
	 * 
	 * Second argument is a string B
	 * 
	 * 
	 * 
	 * Output Format
	 * 
	 * Return the number of occurrences.
	 * 
	 * 
	 * 
	 * Example Input
	 * 
	 * Input 1:
	 * 
	 * A = "abababa" B = "aba" Input 2:
	 * 
	 * A = "mississipi" B = "ss" Input 3:
	 * 
	 * A = "hello" B = "hi"
	 * 
	 * 
	 * Example Output
	 * 
	 * Output 1:
	 * 
	 * 3 Output 2:
	 * 
	 * 2 Output 3:
	 * 
	 * 0
	 * 
	 * 
	 * Example Explanation
	 * 
	 * Explanation 1:
	 * 
	 * A has 3 substrings equal to B - A[1, 3], A[3, 5] and A[5, 7] Explanation 2:
	 * 
	 * B occurs two times in A - A[3, 4], A[6, 7]. Explanation 3:
	 * 
	 * B does not occur in A as a substring.
	 * 
	 * 
	 */
	public static void main(String[] args) {
	         String	 A = "abababa";
			String	 B = "aba" ;
					
	}

	public int solve1(final String A, final String B) {
		int n1 = A.length();
		int n2 = B.length();

		int i = 0;
		int c = 0;

		while (i < n1) {
			if (i + n2 <= n1) {
				String temp = A.substring(i, i + n2);

				if (temp.equals(B))
					c++;
			}
			i++;
		}
		return c;
	}

	public int solve2(final String A, final String B) {
		int n = A.length();
		int m = B.length();

		int ans = 0;

		long p = 31;
		int mod = 1000000009;

		long hashB = 0;

		for (int i = 0; i < m; i++) {
			hashB = (((hashB * p) % mod) + (B.charAt(i) - 'a' + 1)) % mod;
		}

		long curHashA = 0;
		long pp = 1;

		for (int i = 0; i < m - 1; i++) {
			pp = (pp * p) % mod;
		}

		for (int i = 0; i < m; i++) {
			curHashA = ((curHashA * p) % mod + (A.charAt(i) - 'a' + 1)) % mod;
		}

		if (curHashA == hashB) {
			ans++;
		}

		for (int i = m; i < n; i++) {
			long prvHashA = curHashA;
			curHashA = ((((prvHashA - (A.charAt(i - m) - 'a' + 1) * pp) % mod) * p) % mod + (A.charAt(i) - 'a' + 1))
					% mod;
			if (curHashA < 0)
				curHashA += mod;
			if (curHashA == hashB) {
				ans++;
			}
		}

		return ans;
	}

	int solve3(final String A, final String B) {

		String temp = B + "$" + A;

		int[] arr = lps(temp);
		int c = 0;
		for (int i = 0; i < arr.length; i++)
			if (B.length() == arr[i])
				c++;
		return c;

	}

	int[] lps(String s) {
		int n = s.length();
		int[] lps = new int[n];

		lps[0] = 0;
		int i = 1;
		while (i < n) {
			int x = lps[i - 1];

			while (s.charAt(x) != s.charAt(i)) {
				if (x == 0) {
					x = -1;
					break;
				}

				x = lps[x - 1];
			}
			lps[i] = x + 1;
			i++;
		}
		return lps;
	}
}
