package com.dsa.stringPattern;

public class PatternMatching {

	public static void main(String[] args) {
		String s = "abcdef";
		String p = "ef";

		System.out.println("pattern found: " + brute(s, p));
	}

	static boolean brute(String s, String p) {
		int n = s.length();
		int n1 = p.length();
		int i = 0;

		boolean find = false;
		while (i < n) {
			if (i + n1 <= n) 
				find = p.equals(s.substring(i, i + n1));
		  if(find) return true;	
			i++;
		}
		return false;
	}
	
	/*
	public static void main(String[] args) {
		String s = "abcedf";
		int n = s.length();

		String s1 = "df";
		int n1 = s1.length();

		int i = 0;
		boolean find = false;
		while (i < n) {
			
			if (check(i, s, s1)) {
				find = true;
				break;
			}
			i++;
		}
		System.out.println("Pattern match: " + find);
	}

	
	 * static boolean check(int i, String s, String s1) { String temp = ""; int n =
	 * s1.length();
	 * 
	 * while(i<i+n && i<s.length()) temp += s.charAt(i++);
	 * 
	 * if (temp.equals(s1)) return true; else return false; }
	 */
}
