package com.dsa.stringPattern;

public class MakeStringPalindrome {

	public static void main(String[] args) {
		String s =  "AACECAAAA" ;
		
		System.out.println(bruteForce(s));
		System.out.println(solve(s));
	}
	static int bruteForce(String A) {

        int c = 0;

        while(A.length()>0)
        {
            if(checkPalindrome(A))
             return c;
            else 
              c++;
            A = A.substring(0,A.length()-1) ;
        }
        return c;
    }
   static boolean checkPalindrome(String str)
    {
        int n = str.length();

         int i=0;
        while(i<n)
        {
            if(str.charAt(i) != str.charAt(n-i-1) )
               return false;
               i++;
        }
        return true;
    }
   
   //=============== OPTIMISE=====================
   
   static int solve(String A) {
       int n = A.length();

       String rev = "";
       StringBuilder sb = new StringBuilder();

       for(int i=n-1; i>=0; i--)
         sb.append(A.charAt(i)) ;
        
        rev = sb.toString();

       A = A+"$"+rev;

       int arr[] = lps(A) ;

       return n - arr[arr.length-1] ;
   }
  static  int[] lps(String s)
   {
       int n = s.length();
       
       int lps[] = new int[n];
       
       lps[0] = 0;
       
       for(int i=1; i<n; i++)
       {
           int x = lps[i-1];
           
           while(s.charAt(x) != s.charAt(i))
           {
               if(x == 0) {
                   x = -1;
                   break;
               }
               x = lps[x-1];
           }
           lps[i] = x+1;
       }
       return lps;
   }
}
 class Solution {
    public int solve(String A) {
        String s = new String(A);
        StringBuilder sb = new StringBuilder(A);
        s += sb.reverse();
        int lps[];
        // lps array contains the longest prefix, which is also a suffix
        lps = computeLPS(s);
        return Math.max(A.length() - lps[s.length() - 1], 0);
    }
    public int[] computeLPS(String s) {
        int l = 0, i = 1;
        int lps[] = new int[s.length()];
        while (i < s.length()) {
            if (s.charAt(i) == s.charAt(l)) {
                lps[i] = ++l;
                i++;
            } else {
                if (l > 0) {
                    l = lps[l - 1];
                } else {
                    lps[i] = 0;
                    i++;
                }
            }
        }
        return lps;
    }
}
