package com.dsa.hashing;

import java.util.*;

public class XORTRIPLETS {
	public int solve(int[] A) { // brute force approach
		int ans = 0;
		int mod = 1000 * 1000 * 1000 + 7;
		for (int i = 0; i < A.length; i++)
			for (int j = i + 1; j < A.length; j++)
				for (int k = j; k < A.length; k++) {
					int a = 0, b = 0;
					for (int l = i; l < j; l++)
						a = a ^ A[l];
					for (int m = j; m <= k; m++)
						b = b ^ A[m];
					if (a == b)
						ans = (ans + 1);
				}
		return ans;
	}

	public int optimised(int[] A) {
		HashMap<Integer, Pair> map = new HashMap();
		map.put(0, new Pair(0));

		int xor = 0, mod = 1000 * 1000 * 1000 + 7;
		long result = 0;
		for (int i = 0; i < A.length; i++) {
			xor = xor ^ A[i];
			if (!map.containsKey(xor))
				map.put(xor, new Pair(i + 1));
			else {
				Pair info = map.get(xor);
				result = (result + i * info.count - info.sum + mod) % mod;
				info.sum += i + 1;
				info.count++;
				map.put(xor, info);
			}
		}
		return (int) result;
	}

	class Pair {
		int count, sum;

		Pair(int a) {
			count = 1;
			sum = a;
		}
	}
}

/*
 * 
 * Problem Description Given an array of integers A of size N.
 * 
 * A triplet (i, j, k), i < j <= k is called a power triplet if A[i] ^ A[i+1]
 * ^....A[j-1] = A[j] ^.....^A[k].
 * 
 * Where, ^ denotes bitwise xor.
 * 
 * Return the count of all possible power triplets. Since the answer could be
 * large return answer % 109 +7.
 * 
 * 
 * 
 * Problem Constraints 1 <= N <= 100000 1 <= A[i] <= 100000
 * 
 * 
 * 
 * Input Format The first argument given is the integer array A.
 * 
 * 
 * 
 * Output Format Return the count of all possible power triplets % 109 + 7.
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * A = [5, 2, 7] Input 2:
 * 
 * A = [1, 2, 3]
 * 
 * 
 * Example Output Output 1:
 * 
 * 2 Output 2:
 * 
 * 2
 * 
 * 
 * Example Explanation Explanation 1:
 * 
 * All possible power triplets are: 1. (1, 2, 3) -> A[1] = A[2] ^ A[3] 2. (1, 3,
 * 3) -> A[1] ^ A[2] = A[3] Explanation 2:
 * 
 * All possible power triplets are: 1. (1, 2, 3) -> A[1] = A[2] ^ A[3] 2. (1, 3,
 * 3) -> A[1] ^ A[2] = A[3]
 * 
 */