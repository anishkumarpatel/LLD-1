package com.dsa.hashing;
import java.util.*;

public class PointsOnSameLine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	static int solve(int[] A, int[] B) {
	        int n = A.length;
	        int ans=0;

	        Map<Double,Integer> map = new HashMap() ;

	        for(int i=0; i<n; i++)
	        {
	            int count=0;
	            
	            for(int j=0; j<n; j++)
	            {
	                if(A[i]==A[j] && B[i] == B[j] )
	                {
	                    count++; 
	                    continue;
	                }
	                int X = A[j] - A[i] ;
	                int Y = B[j] - B[i] ;
	              //  double slope    = (double)(B[j] - B[i])/(double)(A[j] - A[i]) ;//= Y/X ;
	                double slope    = (double)Y/X ;
	                int fre = map.getOrDefault(slope,0) + 1 ;
	                map.put(slope,fre) ;
	            }
	            ans = Math.max(ans,count) ;

	            for(Double d : map.keySet())
	             ans = Math.max(ans,map.get(d)+count) ;

	             map.clear() ;
	        }
	        return ans ;
	    }
	 
		    static int __gcd(int x, int y) {
		        if (x == 0)
		            return y;
		        return __gcd(y % x, x);
		    }
		    static int solve1(int[] A, int[] B) {
		        return maxpointsonsameline(A, B);
		    }
		    static int maxpointsonsameline(int[] x, int[] y) {
		        int n = x.length;
		        if (n < 3)
		            return n;
		        int ans = 0;
		        int curmax = 0, overlap = 0, vertical = 0;
		        for (int i = 0; i < n; ++i) {
		            curmax = 0;
		            overlap = 0;
		            vertical = 0;
		            HashMap<ArrayList<Integer>, Integer> mp = new HashMap<ArrayList<Integer>, Integer>();
		            for (int j = i + 1; j < n; ++j) {
		                if (x[i] == x[j] && y[i] == y[j])
		                    ++overlap;
		                else if (x[i] == x[j])
		                    ++vertical;
		                else {
		                    int xdiff = x[j] - x[i];
		                    int ydiff = y[j] - y[i];
		                    int z = __gcd(xdiff, ydiff);
		                    xdiff /= z;
		                    ydiff /= z;
		                    ArrayList<Integer> tmp = new ArrayList<Integer>();
		                    tmp.add(xdiff);
		                    tmp.add(ydiff);
		                    // mp stores the slope of the line between i-th and j-th point
		                    if (mp.get(tmp) == null) {
		                        mp.put(tmp, 1);
		                    } else {
		                        mp.put(tmp, mp.get(tmp) + 1);
		                    }
		                    curmax = Math.max(curmax, mp.get(tmp));
		                }
		                curmax = Math.max(curmax, vertical);
		            }
		            ans = Math.max(ans, curmax + overlap + 1);
		        }
		        return ans;
		    }
}
/*
 * Problem Description Given two arrays of integers A and B describing a pair of
 * (A[i], B[i]) coordinates in a 2D plane. A[i] describe x coordinates of the
 * ith point in the 2D plane, whereas B[i] describes the y-coordinate of the ith
 * point in the 2D plane.
 * 
 * Find and return the maximum number of points that lie on the same line.
 * 
 * 
 * 
 * Problem Constraints 1 <= (length of the array A = length of array B) <= 1000
 * 
 * -105 <= A[i], B[i] <= 105
 * 
 * 
 * 
 * Input Format The first argument is an integer array A. The second argument is
 * an integer array B.
 * 
 * 
 * 
 * Output Format Return the maximum number of points which lie on the same line.
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * A = [-1, 0, 1, 2, 3, 3] B = [1, 0, 1, 2, 3, 4] Input 2:
 * 
 * A = [3, 1, 4, 5, 7, -9, -8, 6] B = [4, -8, -3, -2, -1, 5, 7, -4]
 * 
 * 
 * Example Output Output 1:
 * 
 * 4 Output 2:
 * 
 * 2
 * 
 * 
 * Example Explanation Explanation 1:
 * 
 * The maximum number of point which lie on same line are 4, those points are
 * {0, 0}, {1, 1}, {2, 2}, {3, 3}. Explanation 2:
 * 
 * Any 2 points lie on a same line.
 */
