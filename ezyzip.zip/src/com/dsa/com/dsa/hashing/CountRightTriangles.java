package com.dsa.hashing;
import java.util.*;
import java.util.Map.*;
public class CountRightTriangles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	static int solve(int[] A, int[] B) {

		HashMap<Integer, Integer> x_map = new HashMap<>();
		HashMap<Integer, Integer> y_map = new HashMap<>();

		for (int index = 0; index < A.length; index++)
			x_map.put(A[index], x_map.getOrDefault(A[index], 0) + 1);

		for (int index = 0; index < B.length; index++)
			y_map.put(B[index], y_map.getOrDefault(B[index], 0) + 1);

		long count = 0;
		int mod = 1000000007;
		for (int index = 0; index < A.length; index++) {
			int intersection_points = (x_map.get(A[index]) - 1) * (y_map.get(B[index]) - 1);
			count = (count + intersection_points) % mod;
		}

		return (int) count;

	}
	
	    static int solve9(int[] A, int[] B) {
	        int n = A.length;
	        int c = 0;
	        for(int i=0; i<n; i++)
	        {
	            for(int j=i+1; j<n; j++)
	            {
	                for(int k=j+1; k<n; k++)
	                {
	                    if(check(i,j,k ,A,B))
	                        c++;
	                }
	            }
	        }
	        return c;
	    }
	 static boolean check(int a, int b, int c,int[]A, int[] B)
	    {
	        if( ( A[a] == A[b] && B[a] == B[c] ) ||
	        (B[a] == B[b] && A[a]  == A[c]) )
	        return true;
	      return false ;
	    }
	    
	static int brute(int[] A, int[] B) {
		int n = A.length;
		int count = 0;

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (i != j)
					for (int k = 0; k < n; k++) {
						if (i != k && j != k) {
							if (B[i] == B[j] && A[i] == A[k]) {

								count++;

							}
							// if(B[i]==B[k] && A[i] ==A[j])
							// count++;
						}
					}
			}
		}
		return count;
	}
}

/*
 * Problem Description Given two arrays of integers A and B of size N each,
 * where each pair (A[i], B[i]) for 0 <= i < N represents a unique point (x, y)
 * in 2D Cartesian plane.
 * 
 * Find and return the number of unordered triplets (i, j, k) such that (A[i],
 * B[i]), (A[j], B[j]) and (A[k], B[k]) form a right-angled triangle with the
 * triangle having one side parallel to the x-axis and one side parallel to the
 * y-axis.
 * 
 * NOTE: The answer may be large so return the answer modulo (109 + 7).
 * 
 * 
 * 
 * Problem Constraints 1 <= N <= 105
 * 
 * 0 <= A[i], B[i] <= 109
 * 
 * 
 * 
 * Input Format The first argument given is an integer array A. The second
 * argument given is the integer array B.
 * 
 * 
 * 
 * Output Format Return the number of unordered triplets that form a right
 * angled triangle modulo (109 + 7).
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * A = [1, 1, 2] B = [1, 2, 1] Input 2:
 * 
 * A = [1, 1, 2, 3, 3] B = [1, 2, 1, 2, 1]
 * 
 * 
 * Example Output Output 1:
 * 
 * 1 Output 2:
 * 
 * 6
 * 
 * 
 * Example Explanation Explanation 1:
 * 
 * All three points make a right angled triangle. So return 1. Explanation 2:
 * 
 * 6 triplets which make a right angled triangle are: (1, 1), (1, 2), (2, 2) (1,
 * 1), (3, 1), (1, 2) (1, 1), (3, 1), (3, 2) (2, 1), (3, 1), (3, 2) (1, 1), (1,
 * 2), (3, 2) (1, 2), (3, 1), (3, 2)
 * 
 */