package com.dsa.hashing;
import java.util.*;
public class CountRectable {

	public static void main(String[] args) {
		int[] A = {1, 1, 2, 2, 3, 3 };
		int[] B = { 1, 2, 1, 2, 1, 2 };
		
		/*
		 * As mentioned in the hint, run two loops by fixing the two diagonally opposite
		 * rectangle ends.
		 * 
		 * We have fixed the one diagonal of the rectangle and two corner points. From
		 * this, we can easily find the other two rectangle points.
		 * 
		 * Suppose we have two diagonally opposite points: (x1, y1) and (x2, y2). Then
		 * the other two points of the rectangle must be (x1, y2) and (x2, y1).
		 * 
		 * We have to check if these two points (x1, y2) and (x2, y1) are given or not.
		 * If present, increment the answer.
		 * 
		 * We have incremented the answer twice for every rectangle because every
		 * rectangle has two diagonals. So, our final answer will be half of the answer
		 * obtained after running two loops.
		 */

		//System.out.println(brute(A, B));
		System.out.println(solve(A, B));
	}
	 static int solve(int[] A, int[] B) {
	        int N = A.length;
	        // 1. add all coordinates into a HashSet in form of String
	        HashSet<String> hs = new HashSet<>();
	        for(int i=0; i<N; i++){
	            String p = A[i] + "@" + B[i];
	            hs.add(p);
	        }
	        // 2. we are checking for every possible diagonal pair and searching for other diagonal pair
	        int count = 0;
	        for(int i=0; i<N; i++){
	            for(int j=i+1; j<N; j++){
	                if(A[i] != A[j] && B[i] != B[j]){ // skipping the diagonals that are parallel to x-axis or y-axis
	                    String p1 = A[i] + "@" + B[j];
	                    String p2 = A[j] + "@" + B[i];
	                    if(hs.contains(p1) && hs.contains(p2)){
	                    	System.out.println(i+" i "+p1+" "+j+" j "+p2);
	                        count++;
	                    }
	                }
	            }
	        }
	        return count/2; // as every rectangle will be counted twice
	    }
	static public int brute(int[] A, int[] B) {
		int n = A.length;
		int c = 0;

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (i == j)
					continue;
				for (int k = 0; k < n; k++) {
					if (i == k || j == k)
						continue;
					for (int l = 0; l < n; l++) {
						if (i == l || j == l || k == l)
							continue;
						if (A[i] == A[j] && A[k] == A[l] && B[i] == B[k] && B[j] == B[l])
							c++;
					}
				}
			}
		}
		return c / 4;
	}
}