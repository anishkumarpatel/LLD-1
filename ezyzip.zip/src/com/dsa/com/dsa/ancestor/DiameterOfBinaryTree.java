package com.dsa.ancestor;

/*
 
 Solution Approach
First, let’s see how to find the height or maxDepth of a tree:

If the tree is empty, then return 0
Else
(a) Get the max depth of each subtree recursively.

(b) Take the max depth and second max depth of any subtree. Get the max depth of the right subtree recursively, i.e., call height( tree->right-subtree)

(c) Get the max of max depths of left and right subtrees and add 1 to it for the current node.
max_depth = max(max dept of left subtree, max depth of right subtree) + 1

(d) Return max_depth

Diameter of a tree can be calculated by only using the height function, because the diameter of a tree is nothing but maximum value of (left_height + right_height + 1) for each node. So we need to calculate this value (left_height + right_height + 1) for each node and update the result. Time complexity – O(N).

Problem Description
Given a Binary Tree A consisting of N integer nodes, you need to find the diameter of the tree.

The diameter of a tree is the number of edges on the longest path between two nodes in the tree.



Problem Constraints
0 <= N <= 105



Input Format
First and only Argument represents the root of binary tree A.



Output Format
Return an single integer denoting the diameter of the tree.



Example Input
Input 1:

           1
         /   \
        2     3
       / \
      4   5
Input 2:

            1
          /   \
         2     3
        / \     \
       4   5     6


Example Output
Output 1:

 3
Output 2:

 4


Example Explanation
Explanation 1:

 Longest Path in the tree is 4 -> 2 -> 1 -> 3 and the number of edges in this path is 3 so diameter is 3.
Explanation 2:

 Longest Path in the tree is 4 -> 2 -> 1 -> 3 -> 6 and the number of edges in this path is 4 so diameter is 4.



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A Binary Tree, -1 signifies a NULL child, For e.g 6 9 4 -1 -1 8 -1 -1 3 -1 -1
tree-icon
 
 */

public class DiameterOfBinaryTree {
	int ans = 0;

	public int solve(TreeNode A) {
		diameter(A);
		return ans;
	}

	int diameter(TreeNode A) {
		if (A == null)
			return 0;
		int l = diameter(A.left);
		int r = diameter(A.right);
		ans = Math.max(ans, l + r);
		return 1 + Math.max(l, r);
	}
}
