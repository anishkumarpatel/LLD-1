package com.dsa.ancestor;

/*
 
 Solution Approach
Let’s look at the inorder traversal of the tree.

In the ideal case, the inorder traversal should be sorted.
But in this case, because of the swapping 2 cases might arise :


A sequence like {1, 4, 3, 7, 9}, where the swapped pair are adjacent to each other. Only one inversion ( Inversion here means pair of integer A[i], A[i+1] where A[i] > A[i+1] ).
A sequence like {1, 9, 4, 5, 3, 10} where the swapped pair are not adjacent. 2 inversions. We take the min and max of the inversion numbers, and we know the number we need to swap to get the right answer.


Now to figure this out, we need to do an inorder traversal. However, the traditional recursive inorder traversal has memory overhead of the depth of the tree. Using a stack has the same memory overhead.
So, we need something which does not use recursion or stack and can still do the inorder traversal. This part is a bit tricky.
Not all interviewers expect you to know this.

Morris traversal helps us achieve what we are after. It works on the fact that we can modify the tree when traversing and then resetting the tree to its original state once we are done.
The idea of Morris traversal is based on the Threaded Binary tree ( http://en.wikipedia.org/wiki/Threaded_binary_tree ).
In this traversal, we first create links to Inorder successor and print the data using these links, and finally revert the changes to restore the original tree.

On the current recursion,

Check if the root is less than the previous value.
Then update the 2 variables accordingly.
If the first variable is None, update it with the current value.
Then update the second variable with the currrent value.
After the traversal, return the first and second variable.
=======
 
 Problem Description
Two elements of a Binary Search Tree (BST), represented by root A are swapped by mistake. Tell us the 2 values, when swapped, will restore the Binary Search Tree (BST).

A solution using O(n) space is pretty straightforward. Could you devise a constant space solution?

Note: The 2 values must be returned in ascending order



Problem Constraints
1 <= size of tree <= 100000



Input Format
First and only argument is the head of the tree,A



Output Format
Return the 2 elements which need to be swapped.



Example Input
Input 1:

         1 
        / \ 
       2   3
Input 2:

 
         2
        / \
       3   1



Example Output
Output 1:

 [2, 1]
Output 2:

 [3, 1]


Example Explanation
Explanation 1:

Swapping 1 and 2 will change the BST to be 
         2
        / \
       1   3
which is a valid BST 
Explanation 2:

Swapping 1 and 3 will change the BST to be 
         2
        / \
       1   3
which is a valid BST 



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A Binary Tree, -1 signifies a NULL child, For e.g 6 9 4 -1 -1 8 -1 -1 3 -1 -1
tree-icon
Enter Input Here
Arg 2: An Integer Array, For e.g [1,2,3]
Enter Input Here

 
 */

import java.util.*;

public class RecoverBinarySearchTree {

	public int[] recoverTree1(TreeNode A) { // with extra space
		ArrayList<Integer> a = new ArrayList();
		inOrder(A, a);
		int[] res = new int[2];

		int flag = 0;
		for (int i = 1; i < a.size(); i++) {
			if (a.get(i - 1) > a.get(i) && flag == 0) {
				res[1] = a.get(i - 1);
				flag = 1;
			}
			if (a.get(i - 1) > a.get(i))
				res[0] = a.get(i);
		}
		return res;
	}

	void inOrder(TreeNode A, ArrayList<Integer> a) {
		if (A == null)
			return;

		inOrder(A.left, a);
		a.add(A.val);
		inOrder(A.right, a);
	}

	// without extra space
	TreeNode prev;
	int flag;

	public int[] recoverTree(TreeNode A) {
		int[] res = new int[2];
		inorder(A, res);

		return res;
	}

	void inorder(TreeNode A, int[] res) {
		if (A == null)
			return;

		inorder(A.left, res);
		if (prev != null && prev.val > A.val && flag == 0) {
			res[1] = prev.val;
			flag = 1;
		}
		if (prev != null && prev.val > A.val)
			res[0] = A.val;
		prev = A;
		inorder(A.right, res);
	}
}

/*
 * Problem Description Two elements of a binary search tree (BST), represented
 * by root A are swapped by mistake. Tell us the 2 values swapping which the
 * tree will be restored.
 * 
 * A solution using O(n) space is pretty straightforward. Could you devise a
 * constant space solution?
 * 
 * 
 * 
 * Problem Constraints 1 <= size of tree <= 100000
 * 
 * 
 * 
 * Input Format First and only argument is the head of the tree,A
 * 
 * 
 * 
 * Output Format Return the 2 elements which need to be swapped.
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * 
 * 1 / \ 2 3 Input 2:
 * 
 * 
 * 2 / \ 3 1
 * 
 * 
 * 
 * Example Output Output 1:
 * 
 * [2, 1] Output 2:
 * 
 * [3, 1]
 * 
 * 
 * Example Explanation Explanation 1:
 * 
 * Swapping 1 and 2 will change the BST to be 2 / \ 1 3 which is a valid BST
 * Explanation 2:
 * 
 * Swapping 1 and 3 will change the BST to be 2 / \ 1 3 which is a valid BST
 */