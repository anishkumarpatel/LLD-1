package com.dsa.ancestor;

/*
 Solution Approach
For Binary search tree, while traversing the tree from top to bottom the first node whose value 
lies in the range [min(B, C), max(B, C)] is the LCA of B and C.

So just recursively traverse the BST , if current node value is greater than both B and C, 
then the LCA lies in the left subtree of the current node. If it is smaller than both B and C, 
then the LCA lies on the right subtree. Otherwise, the current node is the LCA

Time Complexity : O(H)
Space Complexity : O(H)
where H is the height of the BST


 Problem Description
Given a Binary Search Tree A. Also given are two nodes B and C. Find the lowest common ancestor of the two nodes.

Note 1 :- It is guaranteed that the nodes B and C exist.

Note 2 :- The LCA of B and C in A is the shared ancestor of B and C that is located farthest from the root.



Problem Constraints
1 <= Number of nodes in binary tree <= 105

1 <= B , C <= 105



Input Format
First argument is a root node of the binary tree, A.

Second argument is an integer B.

Third argument is an integer C.



Output Format
Return the LCA of the two nodes



Example Input
Input 1:

            15
          /    \
        12      20
        / \    /  \
       10  14  16  27
      /
     8

     B = 8
     C = 20
Input 2:

            8
           / \
          6  21
         / \
        1   7

     B = 7
     C = 1


Example Output
Output 1:

 15
Output 2:

 6


Example Explanation
Explanation 1:

 The LCA of node 8 and 20 is the node 15.
Explanation 2:

 The LCA of node 7 and 1 is the node 6.



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A Binary Tree, -1 signifies a NULL child, For e.g 6 9 4 -1 -1 8 -1 -1 3 -1 -1
tree-icon
 
 */

public class LCAinBST {

}
