package com.dsa.ancestor;
/*
 Solution Approach
An efficient way to solve the above problem:

We start from the root and for every node, we do following.

If both keys are greater than the current node, we move to the right child of the current node.
If both keys are smaller than current node, we move to left child of current node.
If one keys is smaller and other key is greater, current node is Lowest Common Ancestor (LCA) of two nodes. We find distances of current node from two keys and return sum of the distances.

Time Complexity : O(h) (height of Tree)


 Problem Description
Given a binary search tree.
Return the distance between two nodes with given two keys B and C. It may be assumed that both keys exist in BST.

NOTE: Distance between two nodes is number of edges between them.



Problem Constraints
1 <= Number of nodes in binary tree <= 1000000

0 <= node values <= 109



Input Format
First argument is a root node of the binary tree, A.

Second argument is an integer B.

Third argument is an integer C.



Output Format
Return an integer denoting the distance between two nodes with given two keys B and C



Example Input
Input 1:

    
         5
       /   \
      2     8
     / \   / \
    1   4 6   11
 B = 2
 C = 11
Input 2:

    
         6
       /   \
      2     9
     / \   / \
    1   4 7   10
 B = 2
 C = 6


Example Output
Output 1:

 3
Output 2:

 1


Example Explanation
Explanation 1:

 Path between 2 and 11 is: 2 -> 5 -> 8 -> 11. Distance will be 3.
Explanation 2:

 Path between 2 and 6 is: 2 -> 6. Distance will be 1



Expected Output
Provide sample input and click run to see the correct output for the provided input. Use this to improve your problem understanding and test edge cases
Arg 1: A Binary Tree, -1 signifies a NULL child, For e.g 6 9 4 -1 -1 8 -1 -1 3 -1 -1
tree-icon
Enter Input Here
Arg 2: A single Integer, For e.g 9
Enter Input Here
Arg 3: A single Integer, For e.g 9
Enter Input Here

 
 */

import java.util.*;

public class DistanceBetweenNodesOfBST {
	public int solve1(TreeNode A, int B, int C) {
		return distanceBetween2Nodes(A, B, C);
	}

	int distanceFromRoot(TreeNode A, int val) {
		if (A.val == val)
			return 0;
		else if (A.val > val)
			return 1 + distanceFromRoot(A.left, val);

		return 1 + distanceFromRoot(A.right, val);
	}

	int distanceBetween2Nodes(TreeNode A, int B, int C) {
		if (A == null)
			return 0;

		if (A.val > B && A.val > C)
			return distanceBetween2Nodes(A.left, B, C);
		else if (A.val < B && A.val < C)
			return distanceBetween2Nodes(A.right, B, C);
		else
			return distanceFromRoot(A, B) + distanceFromRoot(A, C);
	}

	public TreeNode lca(TreeNode A, int B, int C) {
		if (A == null)
			return null;
		if (A.val == B || A.val == C)
			return A;
		TreeNode l = lca(A.left, B, C);
		TreeNode r = lca(A.right, B, C);
		if (l == null)
			return r;
		if (r == null)
			return l;
		return A;
	}

	public int solve(TreeNode A, int B, int C) {
		ArrayList<Integer> a = new ArrayList();
		TreeNode least = lca(A, B, C);
		store(least, a, B);
		ArrayList<Integer> b = new ArrayList();
		store(least, b, C);
		return a.size() + b.size() - 2;
	}

	boolean store(TreeNode A, ArrayList<Integer> a, int b) {
		if (A == null)
			return false;
		if (A.val == b) {
			a.add(A.val);
			return true;
		}
		if (store(A.left, a, b) || store(A.right, a, b)) {
			a.add(A.val);
			return true;
		}
		return false;
	}
}
