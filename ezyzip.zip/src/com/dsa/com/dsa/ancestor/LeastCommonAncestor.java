package com.dsa.ancestor;

import com.dsa.bst.TreeNode;

public class LeastCommonAncestor {
	public int lca(TreeNode A, int B, int C) {
		if (A == null)
			return -1;

		boolean check1 = find(A, B);
		boolean check2 = find(A, C);

		if (check1 && check2)
			return help(A, B, C);
		else
			return -1;
	}

	int help(TreeNode A, int B, int C) {
		if (A == null)
			return -1;

		if (A.val == B || A.val == C)
			return A.val;

		int l = help(A.left, B, C);

		int r = help(A.right, B, C);

		if (l == -1)
			return r;
		if (r == -1)
			return l;
		// return help(A.left,B,C) || help(A.right,B,C) ;
		return A.val;
	}

	boolean find(TreeNode A, int val) {
		if (A == null)
			return false;

		if (A.val == val)
			return true;

		return find(A.left, val) || find(A.right, val);
	}
}
