package com.dsa.ancestor;

import com.dsa.ancestor.TreeNode;

public class TreeNode {
	int val;
	TreeNode left;
	TreeNode right;

	TreeNode(int x) {
		val = x;
		left = null;
		right = null;
	}
}
