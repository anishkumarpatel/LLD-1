package com.dsa;

import java.util.Scanner;

public class ElectricityBill {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the amount of unit of electricity: ");

		int a = sc.nextInt();

		System.out.print("Total bill of electricity is ");

		if (a <= 50)

			System.out.println(a * .5); // 1st 50 unit of electricity = rs .5 / unit

		else if (a > 50 && a <= 150)

			System.out.println(50 * .5 + (a - 50) * .75); // next 100 units of electricity = rs .75 / unit

		else if (a > 150 && a <= 250)

			System.out.println(50 * .5 + 100 * .75 + (a - 150) * 1.20); // next 100 units of electricity = rs 1.2 / unit

		else

			System.out.println(50 * .5 + 100 * .75 + 100 * 1.2 + (a - 250) * 1.5); // anything above 250 units of
																					// electricity = rs 1.5 / unit
	}

}
