package com.dsa;
import java.util.*;

public class LargestNo {

	public static void main(String args[]) {
		ArrayList<Integer> a = new ArrayList<>();
		// [3, 30, 34, 5, 9]
		a.add(3);
		a.add(30);
		a.add(34);
		a.add(5);
		a.add(9);

		System.out.print(largestNumber(a));

	}

	static String largestNumber(final List<Integer> A) {
		int size = A.size();

		String[] s = new String[size];
		// ""
		for (int i = 0; i < size; i++)
			s[i] = (A.get(i)).toString();

		Arrays.sort(s, new Comparator<String>() {
			public int compare(String a, String b) {
				String x = a + b;
				String y = b + a;

				return -x.compareTo(y);
			}
		});
		if (s[0].equals("0"))
			return "0";
		StringBuilder stringBuilder = new StringBuilder();

		for (String s1 : s)
			stringBuilder.append(s1);

		return stringBuilder.toString();

	}
}
// 0 1 1 2 3 5 8 13

/*
 * 
 * public static void main(String args[]) { ArrayList<String> a = new
 * ArrayList<>(); a.add("20"); a.add("100"); a.add("40"); a.add("21");
 * a.add("10"); a.add("9"); Collections.sort(a,new Comparator<String>(){
 * 
 * public int compare(String a, String b) { String q = a+b; String r = b + a;
 * return -q.compareTo(r); // 1 // [9, 40, 21, 20, 100, 10] // 940212010100
 * //100102021409
 * 
 * // [10, 100, 20, 21, 40, 9] } }); String x = "40", y = "";
 * 
 * 
 * System.out.println(x.compareTo(y));
 * 
 * System.out.print(a); }
 * 
 * }
 * 
 * // 0 1 1 2 3 5 8 13
 * 
 * Complexity Analysis
 * 
 * Time complexity : O(nlgn)\mathcal{O}(nlgn)O(nlgn)
 * 
 * Although we are doing extra work in our comparator, it is only by a constant
 * factor. Therefore, the overall runtime is dominated by the complexity of
 * sort, which is O(nlgn)\mathcal{O}(nlgn)O(nlgn) in Python and Java.
 * 
 * Space complexity : O(n)\mathcal{O}(n)O(n)
 * 
 * Here, we allocate O(n)\mathcal{O}(n)O(n) additional space to store the copy
 * of nums. Although we could do that work in place (if we decide that it is
 * okay to modify nums), we must allocate O(n)\mathcal{O}(n)O(n) space for the
 * final return string. Therefore, the overall memory footprint is linear in the
 * length of nums.
 */
