package com.dsa.dynamicprogramming;

/*
 Q3. Ways to Decode
Solved
character backgroundcharacter
Stuck somewhere?
Ask for help from a TA and get it resolved.
Get help from TA.
Problem Description
A message containing letters from A-Z is being encoded to numbers using the following mapping:

'A' -> 1
'B' -> 2
...
'Z' -> 26
Given an encoded message denoted by string A containing digits, determine the total number of ways to decode it modulo 109 + 7.



Problem Constraints
1 <= length(A) <= 105



Input Format
The first and the only argument is a string A.



Output Format
Return an integer, representing the number of ways to decode the string modulo 109 + 7.



Example Input
Input 1:

 A = "12"
Input 2:

 A = "8"


Example Output
Output 1:

 2
Output 2:

 1


Example Explanation
Explanation 1:

 Given encoded message "12", it could be decoded as "AB" (1, 2) or "L" (12).
 The number of ways decoding "12" is 2.
Explanation 2:

 Given encoded message "8", it could be decoded as only "H" (8).
 The number of ways decoding "8" is 1.
 */

public class WaysToDecode {
	
	public int numDecodings4(String A) {
		long mod = 1000 * 1000 * 1000 + 7;
		if (A.charAt(0) == '0')
			return 0;
		long[] dp = new long[A.length() + 1];
		dp[0] = 1;
		dp[1] = 1;
		for (int i = 1; i < A.length(); i++) {
			int cur = 0;
			if (A.charAt(i) != '0')
				dp[i + 1] += dp[i];

			int no = (A.charAt(i - 1) - '0') * 10 + (A.charAt(i) - '0');
			if (A.charAt(i - 1) != '0' && no <= 26)
				dp[i + 1] += dp[i - 1];
			dp[i + 1] %= mod;
		}

		return (int) dp[A.length()];
	}

	public int numDecodings3(String A) {
		if (A.charAt(0) == '0')
			return 0;
		int[] dp = new int[A.length()];
		for (int i = 0; i < A.length(); i++)
			dp[i] = -1;

		return ways3(A, 0, dp);
	}

	int ways3(String A, int i, int[] dp) {
		if (i == A.length())
			return 1;

		if (A.charAt(i) == '0')
			return 0;
		if (dp[i] != -1)
			return dp[i];
		int count = 0;
		count = ways3(A, i + 1, dp);
		if (i + 1 < A.length()) {
			int num = 0;
			num = (A.charAt(i) - '0') * 10 + A.charAt(i + 1) - '0';
			if (num <= 26)
				count = (count + ways3(A, i + 2, dp)) % mod;
		}
		dp[i] = count;
		return count;
	}

	public int numDecodings2(String A) { // right to left
		if (A.charAt(0) == '0')
			return 0;
		if (A.length() == 1)
			return 1;

		return ways2(A, A.length() - 1);
	}

	int mod = 1000 * 1000 * 1000 + 7;

	int ways2(String A, int i) {
		if (i <= 0)
			return 1;

		// if(A.charAt(A.length()- i-1) == '0') return 0;A10000322

		int count = 0;
		if (A.charAt(i) != '0')
			count = ways2(A, i - 1);

		if (i - 1 > -1 && A.charAt(i - 1) != '0') {
			int no = 0;
			no = (A.charAt(i - 1) - '0') * 10 + (A.charAt(i) - '0');
			if (no <= 26)
				count = (count + ways2(A, i - 2)) % mod;
		}
		return count % mod;
	}

	public int numDecodings1(String A) { // left to right
		if (A.charAt(0) == '0')
			return 0;
		return ways1(A, 0);
	}

	int ways1(String A, int i) {
		if (i >= A.length())
			return 1;
		// if( i == A.length()-1 ||i == A.length()-2) return 1;

		if (A.charAt(i) == '0')
			return 0;
		int count = 0;
		count = ways1(A, i + 1);
		if (i + 1 < A.length()) {
			int num = 0;
			num = (A.charAt(i) - '0') * 10 + A.charAt(i + 1) - '0';
			if (num <= 26)
				count = (count + ways1(A, i + 2)) % mod;
		}
		return count % mod;
	}
}
