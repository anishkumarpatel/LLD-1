package com.dsa.dynamicprogramming;

/*
Can you spot any overlapping sub problems?

This problem can be solved with dynamic programming.

At each point, you can split the problem into one of these:
1. Take the wine in the front and multiply it by the corresponding year or
2. Take the wine in the back and multiply it by the correspending year
Out of these two options, we take the maximum.

 Problem Description

Given n wines in a row, with integers denoting the cost of each wine respectively. Each year you can sell the first or the last wine in the row. However, the price of wines increases over time. Let the initial profits from the wines be A1, A2, A3…An. In the Yth year, the profit from the ith wine will be Y*Ai. Calculate the maximum possible profit that can be obtained if you sell exactly one wine each year.

You are given an integer array A where A[i] denotes the cost of the ith wine.



Problem Constraints

1 <= n <= 1000
1 <= A[i] <= 1000


Input Format

The first and only argument is the integer array A.


Output Format

Return a single integer, the answer to the problem.


Example Input

Input 1:
A = [1 2 4 3 1]
Input 2:

A = [1]


Example Output

Output 1:
41
Output 2:

1


Example Explanation

Explanation 1:
The wines can be chosen in the following order - 1(1), 1(2), 2(6), 3(12), 4(20). The values in the brackets denote the values they were sold at.
Explanation 2:

Only 1 way exists.
 */

import java.util.*;
public class MaxWineProfit {
	public int solve(int[] A) {
		int s = 0;
		int e = A.length - 1;
		int[][] dp = new int[e + 1][e + 1];
		for (int[] d : dp)
			Arrays.fill(d, -1);
		return profit(A, s, e, 1, dp);
	}

	int profit(int[] A, int s, int e, int year, int[][] dp) {
		if (s == e)
			return year * A[s];
		if (dp[s][e] != -1)
			return dp[s][e];
		int f = year * A[s] + profit(A, s + 1, e, year + 1, dp);
		int r = year * A[e] + profit(A, s, e - 1, year + 1, dp);

		return dp[s][e] = Math.max(f, r);
	}
	
	public int table(int[] A) {
	    int n = A.length;
	    int[][] dp = new int[n][n];
	    
	    for (int i = n-1; i >= 0; i--) {
	        for (int j = 0; j < n; j++) {
	            if (i == j) {
	                dp[i][j] = A[i] * n;
	            } else if (i < j) {
	                int year = n - (j - i);
	                int f = year * A[i] + (i+1 < n ? dp[i+1][j] : 0);
	                int r = year * A[j] + (j-1 >= 0 ? dp[i][j-1] : 0);
	                dp[i][j] = Math.max(f, r);
	            }
	        }
	    }
	    
	    return dp[0][n-1];
	}
}
