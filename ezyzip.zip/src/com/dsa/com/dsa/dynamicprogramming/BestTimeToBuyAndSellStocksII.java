package com.dsa.dynamicprogramming;

/*
 Approach
 
 Observation based solution:

Note 1: I will never buy a stock and sell it in loss.

Note 2: If A[i] < A[i+1], I will always buy a stock on i and sell it on i+1.
Think and try to come up with a proof on the validity of the statement.

DP based solution:

Let Dp[i] = max profit you can gain in region (i,i+1,….,n).
Then Dp[i] = max(Dp[i+1],-A[i] + max( A[j]+Dp[j] st j > i ) )

Can you come up with base cases and direction of computation now?
 
 Problem Description

Say you have an array, A, for which the ith element is the price of a given stock on day i.

Design an algorithm to find the maximum profit.

You may complete as many transactions as you like (i.e., buy one and sell one share of the stock multiple times).

However, you may not engage in multiple transactions at the same time (ie, you must sell the stock before you buy again).

Input Format:

The first and the only argument is an array of integer, A.
Output Format:

Return an integer, representing the maximum possible profit.
Constraints:

0 <= len(A) <= 1e5
1 <= A[i] <= 1e7
Example:

Input 1:
    A = [1, 2, 3]

Output 1:
    2

Explanation 1:
    => Buy a stock on day 0.
    => Sell the stock on day 1. (Profit +1)
    => Buy a stock on day 1.
    => Sell the stock on day 2. (Profit +1)

    Overall profit = 2

Input 2:
    A = [5, 2, 10]

Output 2:
    8

Explanation 2:
    => Buy a stock on day 1.
    => Sell the stock on on day 2. (Profit +8)

Overall profit = 8
 */

import java.util.*;

public class BestTimeToBuyAndSellStocksII {
// DO NOT MODIFY THE ARGUMENTS WITH "final" PREFIX. IT IS READ ONLY

	// sell=0 means mujhe purchase krna hai stock, abhi mere paas nhi hai koi stock
	// sell krne ke liye
	public int recursion(int[] A, int idx, int canSell, int[][] dp) {
		if (idx == A.length)
			return 0;
		if (dp[idx][canSell] != -1)
			return dp[idx][canSell];
		if (canSell == 0) // either buy or ignore
		{
			int ans = 0;
			int buy = -A[idx] + recursion(A, idx + 1, 1, dp);
			int ignore = recursion(A, idx + 1, 0, dp);
			ans = Math.max(buy, ignore);
			dp[idx][canSell] = ans;
			return ans;
		} else {
			int ans = 0;
			int sell = A[idx] + recursion(A, idx + 1, 0, dp);
			int ignore = recursion(A, idx + 1, 1, dp);
			ans = Math.max(sell, ignore);
			dp[idx][canSell] = ans;
			return ans;
		}
	}

	public int maxProfit(final int[] A) {

		// int dp[][]=new int[A.length+1][2];
		// for(int i=0;i<A.length;i++)
		// {
		// for(int j=0;j<2;j++)
		// dp[i][j]=-1;
		// }
		// return recursion(A,0,0,dp);
		int ans = 0;
		for (int i = 0; i < A.length - 1; i++) {
			if (A[i + 1] > A[i]) {
				ans += A[i + 1] - A[i];
			}
		}
		return ans;
	}

	public int maxProfit1(final int[] A) {
		int n = A.length;
		if (n == 0)
			return 0;
		int[] buy = new int[n];
		int[] sell = new int[n];

		buy[0] = -A[0];
		sell[0] = 0;

		for (int i = 1; i < n; i++) {
			buy[i] = Math.max(buy[i - 1], (i - 2 >= 0 ? sell[i - 1] : 0) - A[i]);
			sell[i] = Math.max(sell[i - 1], buy[i - 1] + A[i]);
		}

		return Math.max(buy[n - 1], sell[n - 1]);
	}

	public int tle(final int[] A) {
		Stack<int[]> stack = new Stack<>();
		stack.push(new int[] { 0, 1, 0 });

		int profit = 0;
		while (!stack.isEmpty()) {
			int[] cur = stack.pop();

			profit = Math.max(profit, cur[2]);

			if (cur[0] >= A.length)
				continue;

			if (cur[1] == 1) {
				int[] buy = new int[] { cur[0] + 1, 2, cur[2] - A[cur[0]] };
				int[] dontBuy = new int[] { cur[0] + 1, 1, cur[2] };
				stack.push(buy);
				stack.push(dontBuy);
			} else {
				int[] sell = new int[] { cur[0] + 1, 1, cur[2] + A[cur[0]] };
				int[] dontSell = new int[] { cur[0] + 1, 2, cur[2] };
				stack.push(sell);
				stack.push(dontSell);
			}
		}
		return profit;
	}
}
