package com.dsa.dynamicprogramming;

/*
 Problem Description
Find out the number of A digit positive numbers, whose digits on being added equals to a given number B.

Note that a valid number starts from digits 1-9 except the number 0 itself. i.e. leading zeroes are not allowed.

Since the answer can be large, output answer modulo 1000000007



Problem Constraints
1 <= A <= 1000

1 <= B <= 10000



Input Format
First argument is the integer A

Second argument is the integer B



Output Format
Return a single integer, the answer to the problem



Example Input
Input 1:

 A = 2
 B = 4
Input 2:

 A = 1
 B = 3


Example Output
Output 1:

 4
Output 2:

 1


Example Explanation
Explanation 1:

 Valid numbers are {22, 31, 13, 40}
 Hence output 4.
Explanation 2:

 Only valid number is 3
 */
/**

A = 2
B = 4


   |  0       1       2       3       4   --> Value B
-----------------------------------------------
A  |  0       0       0       0       0       
1  |  0       1       1       1       1
2  |  0       1       2       3       4
            (1+0)    (2+0),  (3+0),   (4+0),
                     (1+1)   (2+1)    (3+1),
                             (1+2)    (2+2),
                                      (1+3)

Logic I can see is
For a value of Row  we can take one value and see how many ways the remaing value can be made

like for 4 with 2 option (A):   Suppose I took 1 so, number of option left= (2 - 1)= 1
                                Now I can see in the DP matrx how many ways I can form 3 using 1 option.
                                dp[i][j]  += dp[i - 1][j - X]  X= the value I am taking in this case it is 1                                            




    |  0       1       2       3       4   --> Value B
-----------------------------------------------
A   0  |  0       0       0       0       0
1  |  0       1       1       1       1
2  |  0       1       2       3       4
3  |  0       1       3       6       10


Numbers of ways we can form a value using 1 digit is depend on the value itself.
If the value is [1-9] then it is possible to construct the value using 1 digit. Else it will be 0.


  0   1   2   3   4   5   6   7   8   9   10  11  12  13  14  15   --> Value B
-------------------------------------------------------------------------
0  |  0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0
1  |  0   1   1   1   1   1   1   1   1   1   0   0   0   0   0   0
2  |  0   1   2   3   4   5   6   7   8   9   9   8   7   6   5   4

*/
import java.util.*;

public class NDigitNumbers {
	public int solve(int A, int B) {
		int[][] dp = new int[A + 1][B + 1];

		for (int i = 1; i <= 9 && i <= B; i++)
			dp[1][i] = 1;
		int mod = 1000 * 1000 * 1000 + 7;
		for (int i = 2; i <= A; i++) {
			for (int j = 1; j <= B; j++) {
				for (int x = 0; x <= 9; x++) {
					if (j - x >= 0)
						dp[i][j] = (dp[i][j] % mod + dp[i - 1][j - x] % mod) % mod;
				}
			}
		}
		return dp[A][B];
	}
}
