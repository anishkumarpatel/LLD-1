package com.dsa.dynamicprogramming;

/*
 Approach
 
 buy[i] = max profit when last transaction is buy till i(you can buy at i or you can rest (by rest we use buy[i-1] i.e buy till last index))

sell[i] = max profit when last transaction is sell ( you can sell at this point or you can rest( in rest we use sell[i-1] i.esell till last index))

buy[i] = max(buy[i-1],sell[i-2]-prices[i]);
sell[i] = max(sell[i-1],buy[i-1]+prices[i]);
 
 Problem Description
Given an array of integers A of size N in which ith element is the price of the stock on day i,

You may complete as many transactions as you like (ie, buy one and sell one share of the stock multiple times) with the following restrictions:

-> You may not engage in multiple transactions at the same time (i.e. you must sell the stock before you buy again).
-> After you sell your stock, you cannot buy stock on next day. (i.e. cooldown 1 day)

Find the maximum profit you can achieve.


Problem Constraints
1 <= N <= 50000
0 <= A[i] <= 10^6


Input Format
The only argument given is the integer array A.


Output Format
Return the maximum profit you can achieve.


Example Input
Input 1:
A = [1, 2, 3, 0, 2]


Input 2:
A = [1, 2, 3, 1]


Example Output
Output 1:
3

Output 2:
2


Example Explanation
Explanation 1:

Buy on day 1 (price = 1) and sell on day 2 (price = 2), profit = 1
cooldown on day 3
Buy on day 4 (price = 0) and sell on day 5 (price = 2) profit = 2
Total profit = 3.

Explanation 2:

Buy on day 1 (price = 1) and sell on day 3 (price = 3), profit = 2
Total Profit = 2

 
 */

import java.util.*;

public class BestTimetoBuyandSellStockwithCooldown {
	public int solve1(int[] A) {
	    int n = A.length;
	   
	    int[] buy = new int[n];
	    int[] sell = new int[n];
	    buy[0] = -A[0];
	    sell[0] = 0;
	    for(int i = 1; i < n; i++) {
	        buy[i] = Math.max(buy[i-1], (i-2 >= 0 ? sell[i-2] : 0) - A[i]);
	        sell[i] = Math.max(sell[i-1], buy[i-1] + A[i]);
	    }
	    return Math.max(buy[n-1], sell[n-1]);
	}

	public int solve(int[] prices) {
		int n = prices.length;
		int[][] dp = new int[n][2];
		dp[0][0] = 0;
		dp[0][1] = -prices[0];

		for (int i = 1; i < n; i++) {
			dp[i][0] = Math.max(dp[i - 1][0], dp[i - 1][1] + prices[i]);
			if (i >= 2) {
				dp[i][1] = Math.max(dp[i - 1][1], dp[i - 2][0] - prices[i]);
			} else {
				dp[i][1] = Math.max(dp[i - 1][1], -prices[i]);
			}
		}

		return Math.max(dp[n - 1][0], dp[n - 1][1]);
	}

	public int tle(int[] prices) {
		int n = prices.length;
		Stack<int[]> stack = new Stack<>();
		stack.push(new int[] { 0, 1, 0 }); // initial state

		int maxProfit = 0;
		while (!stack.isEmpty()) {
			int[] state = stack.pop();
			int index = state[0], op = state[1], profit = state[2];
			maxProfit = Math.max(maxProfit, profit);

			if (index >= n) {
				continue;
			}

			if (op == 1) { // BUY
				int[] buy = new int[] { index + 1, 2, profit - prices[index] };
				int[] dontBuy = new int[] { index + 1, 1, profit };
				stack.push(buy);
				stack.push(dontBuy);
			} else { // SELL
				int[] sell = new int[] { index + 2, 1, prices[index] + profit };
				int[] dontSell = new int[] { index + 1, 2, profit };
				stack.push(sell);
				stack.push(dontSell);
			}
		}

		return maxProfit;
	}
}
