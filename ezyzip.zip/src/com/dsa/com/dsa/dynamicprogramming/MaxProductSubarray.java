package com.dsa.dynamicprogramming;

/*
 Problem Description
Given an integer array A of size N. Find the contiguous subarray within the given array (containing at least one number) which has the largest product.

Return an integer corresponding to the maximum product possible.

NOTE: Answer will fit in 32-bit integer value.



Problem Constraints
1 <= N <= 5 * 105

-100 <= A[i] <= 100



Input Format
First and only argument is an integer array A.



Output Format
Return an integer corresponding to the maximum product possible.



Example Input
Input 1:

 A = [4, 2, -5, 1]
Input 2:

 A = [-3, 0, -5, 0]


Example Output
Output 1:

 8
Output 2:

 0


Example Explanation
Explanation 1:

 We can choose the subarray [4, 2] such that the maximum product is 8.
Explanation 2:

 0 will be the maximum product possible.


======

If there were no zeros or negative numbers, then the answer would definitely be the product of the whole array.

Now lets assume there were no negative numbers and just positive numbers and 0. In that case we could maintain a 
current maximum product which would be reset to A[i] when 0s were encountered.
When the negative numbers are introduced, the situation changes ever so slightly. We need to now maintain the maximum product 
in positive and maximum product in negative. On encountering a negative number, 
the maximum product in negative can quickly come into picture.


 */
public class MaxProductSubarray {
	public int maxProductBrute(final int[] A) {
		int n = A.length;
		int max = Integer.MIN_VALUE;
		for (int i = 0; i < n; i++) {
			int x = 1;
			for (int j = i; j < n; j++) {
				x *= A[j];
				max = Math.max(max, x);
			}
		}
		return max;
	}

	public int maxProduct(final int[] A) {
		int n = A.length;
		int max = A[0];
		int min = A[0];
		int ans = A[0];

		for (int i = 1; i < n; i++) {
			int temp = Math.max(A[i], Math.max(max * A[i], min * A[i]));
			min = Math.min(A[i], Math.min(max * A[i], min * A[i]));
			max = temp;
			ans = Math.max(ans, max);
		}
		return ans;
	}
}
