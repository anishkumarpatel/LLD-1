package com.dsa.dynamicprogramming;
/*
 *Approach
 
 Lets again look at the bruteforce solution for this question.
Given the string A, B, C, the first character of C has to match with either the first character of A or B. If it matches with first character of A, we try to see if solution is possible with remaining part of A, all of B, and remaining part of C. Then we do the same thing for B.

The pseudocode might look something like this :

    bool isInterleave(int index1, int index2, int index3) {
                    // HANDLE BASE CASES HERE

        bool answer = false; 
        if (index1 < A.length() && A[index1] == C[index3]) answer |= isInterleave(index1 + 1, index2, index3 + 1);
        if (index2 < B.length() && B[index2] == C[index3]) answer |= isInterleave(index1, index2 + 1, index3 + 1);

        return answer;
    }
Again, index1, index2, and index3 can only take A.length(), B.length() and C.length() possibilities respectively. Can you think of a memoization solution using the observation ?

BONUS: Can you eliminate one of the state i.e. come up with something having only two arguments.
 
 Problem Description
Given A, B, C find whether C is formed by the interleaving of A and B.



Problem Constraints
1 <= length(A), length(B) <= 100

1 <= length(C) <= 200



Input Format
The first argument of input contains a string, A.
The second argument of input contains a string, B.
The third argument of input contains a string, C.



Output Format
Return 1 if string C is formed by interleaving of A and B else 0.



Example Input
Input 1:

 A = "aabcc"
 B = "dbbca"
 C = "aadbbcbcac"
Input 2:

 A = "aabcc"
 B = "dbbca"
 C = "aadbbbaccc"


Example Output
Output 1:

 1
Output 2:

 0


Example Explanation
Explanation 1:

 "aa" (from A) + "dbbc" (from B) + "bc" (from A) + "a" (from B) + "c" (from A)
Explanation 2:

 It is not possible to get C by interleaving A and B.
 */

public class InterleavinStrings {
	public static void main(String... args){
		isInterleave("xxy","xwz","xxwxyz") ;
	 }
    static int isInterleave(String A, String B, String C) {

        boolean[][] dp = new boolean[A.length()+1][B.length()+1];

        if (C.length() != A.length() + B.length()) {
            return 0;
        }


        for(int i=0; i<dp.length; i++){
            for(int j=0; j<dp[0].length; j++){

                if(i==0 && j==0){
                    dp[i][j] = true;

                }else if(i==0){

                    dp[i][j] = (B.charAt(j-1) == C.charAt(i+j-1)) ? dp[i][j-1] : false;

                }else if(j==0){

                    dp[i][j] = (A.charAt(i-1) == C.charAt(i+j-1)) ? dp[i-1][j] : false;

                }else{

                    if(A.charAt(i-1) == C.charAt(i+j-1)){
                        dp[i][j] = dp[i-1][j];
                    }
               
                    if(B.charAt(j-1) == C.charAt(i+j-1)){
                        dp[i][j] = dp[i][j-1];
                    }

                    if((A.charAt(i-1) == C.charAt(i+j-1)) && (B.charAt(j-1) == C.charAt(i+j-1)) ){
                        dp[i][j] = dp[i-1][j] || dp[i][j-1];
                    }
                }
            }
        }
		for(boolean[] dp1 : dp ){
			for(boolean d : dp1)
				System.out.print(d+"\t");
			System.out.println();
		}

        return dp[dp.length-1][dp[0].length-1] == true ? 1 : 0;

    }
}
