package com.dsa.dynamicprogramming;

/*
 Approach
  We rewrite our problem as given N cut points(and you cannot make first and last cut), decide order of these cuts to minimise the cost. So, we insert 0 and N at beginning and end of vector B. Now, we have solve our new problem with respect to this new array(say A).

We define dp(i, j) as minimum cost for making cuts Ai, Ai+1, …, Aj. Note that you are not making cuts Ai and Aj, but they decide the cost for us.

For solving dp(i, j), we iterate k from i+1 to j-1, assuming that the first cut we make in this interval is Ak. The total cost required(if we make first cut at Ak) is Aj - Ai + dp(i, k) + dp(k, j).

This is our solution. We can implement this DP recursively with memoisation. Total complexity will be O(N3).
For actually building the solution, after calculating dp(i, j), we can store the index k which gave the minimum cost and then we can build the solution backwards.
 
  public ArrayList<Integer> rodCut(int A, ArrayList<Integer> B) {
        // Insert 0 and A into the cuts array
        B.add(0, 0);
        B.add(A);

        int n = B.size();
        long[][] dp = new long[n][n];
        int[][] parent = new int[n][n];

        // Initialize dp and parent arrays
        for (int len = 2; len < n; len++) {
            for (int i = 0; i + len < n; i++) {
                int j = i + len;
                dp[i][j] = Long.MAX_VALUE;

                for (int k = i + 1; k < j; k++) {
                    long cost = dp[i][k] + dp[k][j] + B.get(j) - B.get(i);
                    if (cost < dp[i][j]) {
                        dp[i][j] = cost;
                        parent[i][j] = k;
                    }
                }
            }
        }

        // Build solution
        ArrayList<Integer> ans = new ArrayList<>();
        buildSolution(0, n - 1, B, parent, ans);

        return ans;
    }

    private void buildSolution(int i, int j, ArrayList<Integer> B, int[][] parent, ArrayList<Integer> ans) {
        if (i + 1 >= j) {
            return;
        }

        int k = parent[i][j];
        ans.add(B.get(k));
        buildSolution(i, k, B, parent, ans);
        buildSolution(k, j, B, parent, ans);
    }
 
 */

import java.util.*;

public class RodCutting {
	public ArrayList<Integer> rodCut(int A, ArrayList<Integer> B) {
		// Insert 0 and A into the cuts array
		B.add(0, 0);
		B.add(A);

		int n = B.size();
		long[][] dp = new long[n][n];
		int[][] parent = new int[n][n];

		// Initialize dp and parent arrays
		for (int len = 2; len < n; len++) {
			for (int i = 0; i + len < n; i++) {
				int j = i + len;
				dp[i][j] = Long.MAX_VALUE;

				for (int k = i + 1; k < j; k++) {
					long cost = dp[i][k] + dp[k][j] + B.get(j) - B.get(i);
					if (cost < dp[i][j]) {
						dp[i][j] = cost;
						parent[i][j] = k;
					}
				}
			}
		}

		// Build solution
		ArrayList<Integer> ans = new ArrayList<>();
		buildSolution(0, n - 1, B, parent, ans);

		return ans;
	}

	private void buildSolution(int i, int j, ArrayList<Integer> B, int[][] parent, ArrayList<Integer> ans) {
		if (i + 1 >= j) {
			return;
		}

		int k = parent[i][j];
		ans.add(B.get(k));
		buildSolution(i, k, B, parent, ans);
		buildSolution(k, j, B, parent, ans);
	}
}
