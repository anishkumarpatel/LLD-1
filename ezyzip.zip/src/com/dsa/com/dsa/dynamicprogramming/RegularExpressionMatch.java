package com.dsa.dynamicprogramming;

/*
 Problem Description
Implement wildcard pattern matching with support for ' ? ' and ' * ' for strings A and B.

' ? ' : Matches any single character.
' * ' : Matches any sequence of characters (including the empty sequence).
The matching should cover the entire input string (not partial).



Problem Constraints
1 <= length(A), length(B) <= 104



Input Format
The first argument of input contains a string A.
The second argument of input contains a string B.



Output Format
Return 1 if the patterns match else return 0.



Example Input
Input 1:

 A = "aaa"
 B = "a*"
Input 2:

 A = "acz"
 B = "a?a"


Example Output
Output 1:

 1
Output 2:

 0


Example Explanation
Explanation 1:

 Since '*' matches any sequence of characters. Last two 'a' in string A will be match by '*'.
 So, the pattern matches we return 1.
Explanation 2:

 '?' matches any single character. First two character in string A will be match. 
 But the last character i.e 'z' != 'a'. Return 0.
 */
import java.util.*;

public class RegularExpressionMatch {
	public int isMatch1(final String A, final String B) {
        int s = A.length();
        int p = B.length();
        boolean[][] dp = new boolean[s+1][p+1] ;
        dp[0][0] = true ;
        for(int i=1; i<=p; i++){
            char c = B.charAt(i-1);
            if(c == '*')
            dp[0][i] = true ;
          else
           break ;
        }

        for(int i=1; i<=s; i++){
           for(int j=1; j<=p; j++){
               char c1 =  A.charAt(i-1);
               char c2 = B.charAt(j-1) ;
               if(c1 == c2 || c2 == '?')
                dp[i][j] = dp[i-1][j-1];
              else if(c2 == '*')
                dp[i][j] = dp[i-1][j] || dp[i][j-1] ;
           }
        }
        if(dp[s][p])
        return 1;
      else 
        return 0 ;
    }
	public int isMatch(final String A, final String B) {
		int a = A.length();
		int b = B.length();
		boolean[][] dp = new boolean[a + 1][b + 1];
		boolean[][] visited = new boolean[a + 1][b + 1];

		if (match(A, B, a - 1, b - 1, dp, visited))
			return 1;
		else
			return 0;
	}

	boolean match(String A, String B, int a, int b, boolean[][] dp, boolean[][] visited) {   // Sa : abaa :: Sb : ab*
		if (a == -1 && b == -1)
			return true;
		if (b == -1)                      
			return false;
		if (a == -1) {
			for (int i = 0; i <= b; i++)
				if (B.charAt(i) != '*')
					return false;
			return true;
		}
		if (visited[a][b] == false) {
			boolean ans = false;
			if (B.charAt(b) >= 'a' && B.charAt(b) <= 'z') {
				if (A.charAt(a) == B.charAt(b))
					ans = match(A, B, a - 1, b - 1, dp, visited);
			}

			if (B.charAt(b) == '?')
				ans = match(A, B, a - 1, b - 1, dp, visited);

			else if (B.charAt(b) == '*')
				ans = match(A, B, a, b - 1, dp, visited) || match(A, B, a - 1, b, dp, visited);
			dp[a][b] = ans;
			visited[a][b] = true;

		}
		return dp[a][b];
	}
}
