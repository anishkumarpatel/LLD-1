package com.dsa.dynamicprogramming;

/*
 Problem Description
Given a 2-D binary matrix A of size N x M filled with 0's and 1's, find the largest rectangle containing only ones and return its area.



Problem Constraints
1 <= N, M <= 100



Input Format
The first argument is a 2-D binary array A.



Output Format
Return an integer denoting the area of the largest rectangle containing only ones.



Example Input
Input 1:

 A = [
       [1, 1, 1]
       [0, 1, 1]
       [1, 0, 0] 
     ]
Input 2:

 A = [
       [0, 1, 0]
       [1, 1, 1]
     ] 


Example Output
Output 1:

 4
Output 2:

 3


Example Explanation
Explanation 1:

 As the max area rectangle is created by the 2x2 rectangle created by (0, 1), (0, 2), (1, 1) and (1, 2).
Explanation 2:

 As the max area rectangle is created by the 1x3 rectangle created by (1, 0), (1, 1) and (1, 2).
 */
import java.util.*;

public class MaxRectangleInBinaryMatrix {
	public int maximalRectangle(int[][] A) {
		int r = A.length;
		int c = A[0].length;
		int[] curRow = A[0];
		int max = maxArea(curRow);

		for (int i = 1; i < r; i++) {
			for (int j = 0; j < c; j++) {
				if (A[i][j] == 1)
					curRow[j] += 1;
				else
					curRow[j] = 0;
			}
			max = Math.max(max, maxArea(curRow));
		}
		return max;
	}

	int maxArea(int[] A) {
		int[] ps = previousSmaller(A);
		int[] ns = nextSmaller(A);
		int max = 0;
		for (int i = 0; i < A.length; i++) {
			int cur = (ns[i] - ps[i] - 1) * A[i];
			max = Math.max(max, cur);
		}
		return max;
	}

	int[] nextSmaller(int[] A) {
		int[] ns = new int[A.length];
		Stack<Integer> s = new Stack();

		for (int i = A.length - 1; i >= 0; i--) {
			while (!s.isEmpty() && A[s.peek()] >= A[i])
				s.pop();

			if (s.isEmpty())
				ns[i] = A.length;
			else
				ns[i] = s.peek();

			s.push(i);
		}
		return ns;
	}

	int[] previousSmaller(int[] A) {
		int[] ps = new int[A.length];
		Stack<Integer> s = new Stack();

		for (int i = 0; i < A.length; i++) {
			while (!s.isEmpty() && A[s.peek()] >= A[i])
				s.pop();

			if (s.isEmpty())
				ps[i] = -1;
			else
				ps[i] = s.peek();

			s.push(i);
		}
		return ps;
	}
}
