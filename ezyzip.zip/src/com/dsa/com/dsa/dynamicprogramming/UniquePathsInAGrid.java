package com.dsa.dynamicprogramming;

/*
 Problem Description
Given a grid of size n * m, lets assume you are starting at (1,1) and your goal is to reach (n, m). At any instance, if you are on (x, y), you can either go to (x, y + 1) or (x + 1, y).

Now consider if some obstacles are added to the grids. How many unique paths would there be? An obstacle and empty space is marked as 1 and 0 respectively in the grid.



Problem Constraints
1 <= n, m <= 100
A[i][j] = 0 or 1



Input Format
Firts and only argument A is a 2D array of size n * m.



Output Format
Return an integer denoting the number of unique paths from (1, 1) to (n, m).



Example Input
Input 1:

 A = [
        [0, 0, 0]
        [0, 1, 0]
        [0, 0, 0]
     ]
Input 2:

 A = [
        [0, 0, 0]
        [1, 1, 1]
        [0, 0, 0]
     ]


Example Output
Output 1:

 2
Output 2:

 0


Example Explanation
Explanation 1:

 Possible paths to reach (n, m): {(1, 1), (1, 2), (1, 3), (2, 3), (3, 3)} and {(1 ,1), (2, 1), (3, 1), (3, 2), (3, 3)}  
 So, the total number of unique paths is 2. 
Explanation 2:

 It is not possible to reach (n, m) from (1, 1). So, ans is 0.
 */
import java.util.*;

public class UniquePathsInAGrid {
	public int minimumTotal(ArrayList<ArrayList<Integer>> a) {
		int n = a.size();

		for (int i = n - 2; i >= 0; i--) {
			int size = a.get(i).size();
			for (int j = 0; j < size; j++) {
				int x = a.get(i).get(j);
				int y = a.get(i + 1).get(j);
				int z = a.get(i + 1).get(j + 1);
				a.get(i).set(j, Math.min(y + x, z + x));
			}
		}
		return a.get(0).get(0);
	}

	public int uniquePathsWithObstacles(int[][] A) {
		int[][] dp = new int[A.length][A[0].length];
		for (int i = 0; i < A.length; i++)
			for (int j = 0; j < A[0].length; j++)
				dp[i][j] = -1;
		return path(A, 0, 0, dp);
	}

	int path(int[][] A, int i, int j, int[][] dp) {
		int r = A.length;
		int c = A[0].length;
		if (i == r || j == c)
			return 0;

		if (A[i][j] == 1)
			return 0;
		if (i == r - 1 && j == c - 1)
			return 1;

		if (dp[i][j] == -1)
			dp[i][j] = path(A, i + 1, j, dp) + path(A, i, j + 1, dp);

		return dp[i][j];
	}

	public int uniquePathsWithObstacles1(int[][] A) {
		int r = A.length;
		int c = A[0].length;
		int[][] dp = new int[r + 1][c + 1];
		dp[0][1] = 1;
		for (int i = 1; i <= r; ++i)
			for (int j = 1; j <= c; ++j)
				if (A[i - 1][j - 1] == 0)
					// 2 way is possible go right or down
					dp[i][j] = dp[i - 1][j] + dp[i][j - 1];
		return dp[r][c];
	}
}
