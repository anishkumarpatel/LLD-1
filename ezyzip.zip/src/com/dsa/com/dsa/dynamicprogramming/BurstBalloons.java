package com.dsa.dynamicprogramming;

/*
 Approach
 We define a function dp to return the maximum number of coins obtainable on the open interval (left, right).
Our base case is if there are no integers on our interval (left + 1 == right), and
therefore there are no more balloons that can be added.
We add each balloon on the interval, divide and conquer the left and right sides, and find the maximum score.

The best score after adding the ith balloon is given by:
A[left] * A[i] * A[right] + dp(left, i) + dp(i, right)

A[left] * A[i] * A[right] is the number of coins obtained from adding the ith balloon, and dp(left, i) + dp(i, right) are the maximum number of coins obtained from solving the left and right sides of that balloon respectively.
 
 Problem Description
You are given N balloons each with a number of coins associated with them. An array of integers A represents the coins associated with the ith balloon.
You are asked to burst all the balloons. If the you burst balloon ith you will get A[left] * A[i] * A[right] coins. Here left and right are adjacent indices of i. After the burst, the left and right then becomes adjacent.

Find the maximum coins you can collect by bursting the balloons wisely.

NOTE: You may imagine A[-1] = A[N] = 1. They are not real therefore you can not burst them.



Problem Constraints
1 <= N <= 100
1 <= A[i] <= 100



Input Format
The only argument given is the integer array A.



Output Format
Return the maximum coins you can collect by bursting the balloons wisely.



Example Input
Input 1:

 A = [3, 1, 5, 8]
Input 2:

 A = [3, 1, 2]


Example Output
Output 1:

 167
Output 2:

 15


Example Explanation
Explanation 1:

 Burst ballon at index 1, coins collected = 3*1*5=15 , A becomes = [3, 5, 8] 
 Burst ballon at index 1, coins collected = 3*5*8=120 , A becomes = [3, 8]
 Burst ballon at index 0, coins collected = 1*3*8=24 , A becomes = [8]
 Burst ballon at index 0, coins collected = 1*8*1 = 8
 Total coins collected = 15 + 120 + 24 + 8 = 167
Explanation 2:

 Burst ballon at index 1, coins collected = 3*1*2 = 6, A becomes = [3, 2] 
 Burst ballon at index 1, coins collected = 3*2*1 = 6, A becomes = [3]
 Burst ballon at index 0, coins collected = 1*3*1 = 3
 Total coins collected = 6 + 6 + 3 = 15
 
 */

public class BurstBalloons {
	public int solve(int[] A) {
		int n = A.length + 2;
		int[] a = new int[n];

		for (int i = 1; i < n - 1; i++) {
			a[i] = A[i - 1];
		}
		a[0] = 1;
		a[n - 1] = 1;

		int[][] dp = new int[n][n];

		for (int l = 1; l < n - 1; l++) {
			for (int start = 1; start < n - l; start++) {
				int end = start + l - 1;
				for (int k = start; k <= end; k++) {
					dp[start][end] = Math.max(dp[start][end],
							dp[start][k - 1] + a[start - 1] * a[k] * a[end + 1] + dp[k + 1][end]);
				}
			}
		}
		return dp[1][n - 2];
	}
}
