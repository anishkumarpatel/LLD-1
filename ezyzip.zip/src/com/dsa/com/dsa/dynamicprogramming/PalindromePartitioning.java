package com.dsa.dynamicprogramming;

/*
 Problem Description
Given a string A, partition A such that every substring of the partition is a palindrome.

Return the minimum cuts needed for a palindrome partitioning of A.



Problem Constraints
1 <= length(A) <= 501



Input Format
The first and the only argument contains the string A.



Output Format
Return an integer, representing the minimum cuts needed.



Example Input
Input 1:

 A = "aba"
Input 2:

 A = "aab"


Example Output
Output 1:

 0
Output 2:

 1


Example Explanation
Explanation 1:

 "aba" is already a palindrome, so no cuts are needed.
Explanation 2:

 Return 1 since the palindrome partitioning ["aa","b"] could be produced using 1 cut.
 */
import java.util.*;

public class PalindromePartitioning {
	public class Solution {
		public int minCut(String A) {
			int n = A.length();
			int[][] dp = new int[n][n];

			for (int l = 1; l < n; l++) {
				for (int r = 0, c = l; r < n - l; r++, c++) {
					if (isPalindrome(A, r, c))
						dp[r][c] = 0;
					else {
						dp[r][c] = Integer.MAX_VALUE;
						for (int k = r; k < c; k++)
							dp[r][c] = Math.min(dp[r][c], 1 + dp[r][k] + dp[k + 1][c]);
					}
				}
			}
			return dp[0][n - 1];
		}

		boolean isPalindrome(String A, int s, int e) {
			while (s < e) {
				if (A.charAt(s++) != A.charAt(e--))
					return false;
			}
			return true;
		}
	}

	public int minCut1(String A) {
		int[] dp = new int[A.length()];
		Arrays.fill(dp, -1);
		return partition(A, 0, dp);
	}

	int partition(String A, int idx, int[] dp) {
		if (idx == A.length())
			return -1;
		if (dp[idx] != -1)
			return dp[idx];
		int ans = Integer.MAX_VALUE;
		for (int i = idx; i < A.length(); i++) {
			if (isPalindrome(A, idx, i)) {
				ans = Math.min(ans, 1 + partition(A, i + 1, dp));
			}
		}
		dp[idx] = ans;
		return dp[idx];
	}

	boolean isPalindrome(String A, int s, int e) {
		while (s < e) {
			if (A.charAt(s++) != A.charAt(e--))
				return false;
		}
		return true;
	}
}
