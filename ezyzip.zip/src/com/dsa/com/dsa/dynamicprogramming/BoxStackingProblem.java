package com.dsa.dynamicprogramming;

/*
 
 Approach
 -------
 
 This problem is the variation longest increasing subsequence problem.

Approach:
Let N be the initial number of boxes of we have.

Since you can use multiple instance of the boxes, generate all the rotations of all the boxes. This will give us 3 * N boxes.
Sort these 3*N boxes based on the base area (decreasing order of base area).
After sorting the boxes, the problem is same as LIS with following optimal substructure property.
maximum_Stack_height[i] = Maximum possible Stack Height with box i at top of stack
maximum_Stack_height[i]= Max(maximum_Stack_height[i], maximum_Stack_height[j] + height[i]) where j < i and width(j) > width(i) and depth(j) > depth(i).
If there is no such j then maximum_Stack_height[i] = height(i)

Return the maximum value from maximum_Stack_height array.

 
 Problem Description

Given a matrix of integers A of size N x 3 representing the dimensions of N rectangular 3-D boxes, where A[i][0] represents the height of the ith box, A[i][1] represents the widht of the ith box and A[i][2] represents the length of the ith box.
You want to create a stack of boxes which is as tall as possible, but you can only stack a box on top of another box if the dimensions of the 2-D base of the lower box are each strictly larger than those of the 2-D base of the higher box. You can rotate a box so that any side functions as its base. It is also allowable to use multiple instances of the same type of box.

Find and return the maximum height of stack achievable.



Problem Constraints

1 <= N <= 1000
1 <= A[i][0], A[i][1], A[i][2] <= 1e6


Input Format

The only argument given is the integer matrix A.


Output Format

Return a single integer, the maximum height of stack achievable.


Example Input

Input 1:
A = [   [4, 6, 7]
        [1, 2, 3]
        [4, 5, 6]
        [1, 2, 3]   ]
Input 2:

A = [   [4, 5, 6]
        [10, 12, 14]    ]


Example Output

Output 1:
60
Output 2:

34


Example Explanation

Explanation 1:
Following are all rotations of the boxes in decreasing order of base area:
        10 x 12 x 32
        12 x 10 x 32
        32 x 10 x 12
        4 x 6 x 7
        4 x 5 x 6
        6 x 4 x 7
        5 x 4 x 6
        7 x 4 x 6
        6 x 4 x 5
        1 x 2 x 3
        2 x 1 x 3
        3 x 1 x 2

        The height 60 is obtained by boxes
        [ [3, 1, 2], [1, 2, 3], [6, 4, 5], [4, 5, 6], [4, 6, 7], [32, 10, 12], [10, 12, 32] ]
Explanation 2:

Similarly, the answer for this case would be 34

 */

import java.util.*;

public class BoxStackingProblem {
	public int solve(int[][] A) {
		int n = A.length;

		int[][] boxes = new int[6 * n][3];
		int j = 0;

		for (int i = 0; i < n; i++) {
			int h = A[i][0];
			int w = A[i][1];
			int l = A[i][2];

			boxes[j][0] = h;
			boxes[j][1] = w;
			boxes[j][2] = l;
			j++;

			boxes[j][0] = h;
			boxes[j][1] = l;
			boxes[j][2] = w;
			j++;

			boxes[j][0] = w;
			boxes[j][1] = h;
			boxes[j][2] = l;
			j++;

			boxes[j][0] = w;
			boxes[j][1] = l;
			boxes[j][2] = h;
			j++;

			boxes[j][0] = l;
			boxes[j][1] = h;
			boxes[j][2] = w;
			j++;

			boxes[j][0] = l;
			boxes[j][1] = w;
			boxes[j][2] = h;
			j++;
		}

		// Calculate the maximum height of the boxes using LIS
		Arrays.sort(boxes, (a, b) -> a[1] - b[1]);
		int[] dp = new int[6 * n];
		int max = 0;
		for (int i = 0; i < 6 * n; i++) {
			dp[i] = boxes[i][0];
			for (int k = 0; k < i; k++) {
				if (boxes[k][1] < boxes[i][1] && boxes[k][2] < boxes[i][2]) {
					dp[i] = Math.max(dp[i], dp[k] + boxes[i][0]);
				}
			}
			max = Math.max(max, dp[i]);
		}

		return max;
	}

	// ====================================

	class Boxes {
		int h;
		int w;
		int l;

		Boxes(int h, int w, int l) {
			this.h = h;
			this.w = w;
			this.l = l;
		}
	}

	public int solve1(int[][] A) {
		int n = A.length;
		Boxes[] arr = new Boxes[6 * n];
		int j = 0;
		for (int i = 0; i < 6 * n; i++) {
			arr[i] = new Boxes(A[j][0], A[j][1], A[j][2]);
			arr[++i] = new Boxes(A[j][0], A[j][2], A[j][1]);
			arr[++i] = new Boxes(A[j][1], A[j][0], A[j][2]);
			arr[++i] = new Boxes(A[j][1], A[j][2], A[j][0]);
			arr[++i] = new Boxes(A[j][2], A[j][0], A[j][1]);
			arr[++i] = new Boxes(A[j][2], A[j][1], A[j][0]);
			j++;
		}
		Arrays.sort(arr, (a, b) -> a.w - b.w);
		int max = A[0][0];
		int[] ans = new int[6 * n];
		for (int i = 0; i < 6 * n; i++) {
			ans[i] = arr[i].h;
			for (j = 0; j < i; j++) {
				if (arr[j].w < arr[i].w && arr[j].l < arr[i].l && ans[i] < ans[j] + arr[i].h) {
					ans[i] = ans[j] + arr[i].h;
				}
			}
			max = Math.max(max, ans[i]);
		}
		return max;
	}
}
