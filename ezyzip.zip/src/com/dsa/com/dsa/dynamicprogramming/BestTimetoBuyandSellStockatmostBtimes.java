package com.dsa.dynamicprogramming;

/*
 Approach:-
  dp[i][j] = maximum profit from most i transactions using prices[0..j]
A transaction is defined as one buy + sell.
Now on day j, we have two options:

Do nothing (or buy) which doesn't change the acquired profit : dp[i][j] = dp[i][j-1]

Sell the stock: In order to sell the stock, you must've bought it on a day t=[0..j-1]. Maximum profit that can be attained is t:0->j-1 max(prices[j]-prices[t]+dp[i-1][t-1]) where prices[j]-prices[t] is the profit from buying on day t and selling on day j. 
dp[i-1][t-1] is the maximum profit that can be made with at most i-1 transactions with prices prices[0..t-1].

Time complexity of this approach is O(n^2 * k).

In order to reduce it to O(n*k), we must find t:0->j-1 max(prices[j]-prices[t]+dp[i-1][t-1]) this expression in constant time.
If you see carefully,
t:0->j-1 max(prices[j]-prices[t]+dp[i-1][t-1]) is same as
prices[j] + t:0->j-1 max(dp[i-1][t-1]-prices[t])

Second part of the below expression 
MaxDiff = t:0->j-1 max(dp[i-1][t-1]-prices[t]) can be included in the dp loop by keeping track of the maximum value till j-1.

 
 Given an array of integers A of size N in which ith element is the price of the stock on day i,

You can complete atmost B transactions.

Find the maximum profit you can achieve.

NOTE: You may not engage in multiple transactions at the same time (ie, you must sell the stock before you buy again).


Input Format

The First argument given is the integer array A.
The Second argument is integer B.
Output Format

Return the maximum profit you can achieve by doing atmost B transactions.
Constraints

1 <= N <= 500
0 <= A[i] <= 10^6
0 <= B <= 10^9
For Example

Input 1:
    A = [2, 4, 1]
    B = 2
Output 1:
    2
    Explanation 1:
        Buy on day 1 (price = 2) and sell on day 2 (price = 4), 
        profit = 4 - 2 = 2

Input 2:
    A = [3, 2, 6, 5, 0, 3]
    B = 2
Output 2:
    7
    Explanation 1:
        Buy on day 2 (price = 2) and sell on day 3 (price = 6), profit = 6 - 2 = 4.
        Then buy on day 5 (price = 0) and sell on day 6 (price = 3), profit = 3 - 0 = 3.
 */

import java.util.*;

public class BestTimetoBuyandSellStockatmostBtimes {
	public int solve(int[] A, int B) {
		int n = A.length;
		if (B > n)
			B = n;

		int[][] dp = new int[B + 1][n];

		for (int i = 1; i <= B; i++) {
			int prev = Integer.MIN_VALUE;
			for (int j = 1; j < n; j++) {
				prev = Math.max(dp[i - 1][j - 1] - A[j - 1], prev);
				dp[i][j] = Math.max(dp[i][j - 1], prev + A[j]);
			}
		}
		return dp[B][n - 1];
	}

	public int maxProfit(int[] prices, int B) { // TLE
		int n = prices.length;
		int maxProfit = 0;

		for (int i = 0; i < B; i++) {
			for (int j = 0; j < n; j++) {
				int buyPrice = prices[j];
				int profit = 0;
				for (int k = j + 1; k < n; k++) {
					int sellPrice = prices[k];
					if (sellPrice > buyPrice) {
						int currentProfit = sellPrice - buyPrice;
						int remainingTransactions = B - i - 1;
						if (remainingTransactions > 0) {
							int futureProfit = maxProfit(Arrays.copyOfRange(prices, k + 1, n), remainingTransactions);
							currentProfit += futureProfit;
						}
						profit = Math.max(profit, currentProfit);
					}
				}
				maxProfit = Math.max(maxProfit, profit);
			}

			/*
			 * The time complexity of this code is O(Bn^2log(n)), where n is the length of
			 * the input array A, and B is the maximum number of transactions allowed.
			 * 
			 * The outer loop runs B times, and the middle loop runs n times, giving a total
			 * of Bn iterations. The inner loop runs n - j - 1 times, where j is the current
			 * index of the middle loop. Therefore, the total number of iterations of the
			 * inner loop is the sum of (n-1) + (n-2) + ... + 2 + 1, which is equal to
			 * n(n-1)/2.
			 * 
			 * Inside the innermost loop, a copy of the input array is created using the
			 * copyOfRange method, which has a time complexity of O(n). Therefore, the
			 * recursive call to maxProfit has a time complexity of O(n*log(n)).
			 * 
			 * Since the recursive calls to maxProfit are nested, the total time complexity
			 * can be expressed as follows:
			 * 
			 * T(B,n) = B * n * (n-1)/2 * n * log(n) + B * n * (n-1)/2 * (n-1) * log(n-1) +
			 * ... + B * n * (n-1)/2 * 2 * log(2) + B * n * (n-1)/2 * 1 * log(1)
			 * 
			 * This is a sum of geometric series, and can be simplified to:
			 * 
			 * T(B,n) = O(Bn^2log(n))
			 * 
			 * The space complexity of this code is O(B*log(n)), because at most B recursive
			 * calls to maxProfit will be on the call stack at any given time, and each call
			 * to maxProfit creates a copy of the input array using the copyOfRange method,
			 * which has a space complexity of O(log(n)).
			 */
		}

		return maxProfit;
	}
}
