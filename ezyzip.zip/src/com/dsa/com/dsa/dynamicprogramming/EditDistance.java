package com.dsa.dynamicprogramming;

/*
 Problem Description
Given two strings A and B, find the minimum number of steps required to convert A to B. (each operation is counted as 1 step.)

You have the following 3 operations permitted on a word:

Insert a character
Delete a character
Replace a character


Problem Constraints
1 <= length(A), length(B) <= 450



Input Format
The first argument of input contains a string, A.
The second argument of input contains a string, B.



Output Format
Return an integer, representing the minimum number of steps required.



Example Input
Input 1:

 A = "abad"
 B = "abac"
Input 2:

 A = "Anshuman"
 B = "Antihuman


Example Output
Output 1:

 1
Output 2:

 2


Example Explanation
Exlanation 1:

 A = "abad" and B = "abac"
 After applying operation: Replace d with c. We get A = B.
 
Explanation 2:

 A = "Anshuman" and B = "Antihuman"
 After applying operations: Replace s with t and insert i before h. We get A = B.
 
 */
public class EditDistance {
	public int minDistance(String A, String B) { // tabulation or bottom-up approach
		int a = A.length();
		int b = B.length();
		int[][] dp = new int[a + 1][b + 1];
		for (int i = 1; i <= a; i++) {
			for (int j = 1; j <= b; j++) {
				dp[0][j] = j;
				dp[i][0] = i;
			}
		}

		for (int i = 1; i <= a; i++) {
			for (int j = 1; j <= b; j++) {

				if (A.charAt(i - 1) == B.charAt(j - 1))
					dp[i][j] = dp[i - 1][j - 1];
				else {
					int insert = dp[i - 1][j];
					int update = dp[i - 1][j - 1];
					int delete = dp[i][j - 1];

					dp[i][j] = 1 + Math.min(insert, Math.min(update, delete));
				}
			}
		}
		return dp[a][b];
	}

	public int minDistance1(String A, String B) { // memorization or top-down approach
		int a = A.length();
		int b = B.length();
		int[][] dp = new int[a][b];
		for (int i = 0; i < a; i++) {
			for (int j = 0; j < b; j++) {
				dp[i][j] = -1;
			}
		}
		return editDistance(A, B, a - 1, b - 1, dp);
	}

	int editDistance(String A, String B, int a, int b, int[][] dp) {

		if (a == -1 || b == -1)
			return Math.max(a, b) + 1;

		if (dp[a][b] != -1)
			return dp[a][b];

		if (A.charAt(a) == B.charAt(b))
			dp[a][b] = editDistance(A, B, a - 1, b - 1, dp);
		else {
			int insert = editDistance(A, B, a - 1, b, dp);
			int update = editDistance(A, B, a - 1, b - 1, dp);
			int delete = editDistance(A, B, a, b - 1, dp);

			dp[a][b] = 1 + Math.min(insert, Math.min(update, delete));
		}
		return dp[a][b];
	}
}
