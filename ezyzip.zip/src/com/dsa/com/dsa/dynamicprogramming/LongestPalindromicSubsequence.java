package com.dsa.dynamicprogramming;

/*
 Problem Description
Given a string A. Find the longest palindromic subsequence (A subsequence which does not need to be contiguous and is a palindrome).

You need to return the length of longest palindromic subsequence.



Problem Constraints
1 <= length of(A) <= 103



Input Format
First and only integer is a string A.



Output Format
Return an integer denoting the length of longest palindromic subsequence.



Example Input
Input 1:

 A = "bebeeed"
Input 2:

 A = "aedsead"


Example Output
Output 1:

 4
Output 2:

 5


Example Explanation
Explanation 1:

 The longest palindromic subsequence is "eeee", which has a length of 4.
Explanation 2:

 The longest palindromic subsequence is "aedea", which has a length of 5.
 */

import java.util.*;

public class LongestPalindromicSubsequence {
	public int solve(String A) {
		int n = A.length();
		int[][] dp = new int[n][n];
		for (int i = 0; i < n; i++)
			dp[i][i] = 1;

		for (int l = 2; l <= n; l++) {
			for (int i = 0; i < n - l + 1; i++) {
				int j = i + l - 1;
				char s = A.charAt(i);
				char e = A.charAt(j);
				if (s == e && l == 2)
					dp[i][j] = 2;

				else if (s == e)
					dp[i][j] = dp[i + 1][j - 1] + 2;

				else
					dp[i][j] = Math.max(dp[i + 1][j], dp[i][j - 1]);
			}
		}
		return dp[0][n - 1];
	}

	public int solve1(String A) {
		int[][] visited = new int[A.length()][A.length()];
		for (int i = 0; i < A.length(); i++) {
			for (int j = 0; j < A.length(); j++)
				visited[i][j] = -1;
		}
		return lps(A, 0, A.length() - 1, visited);
	}

	int lps(String A, int s, int e, int[][] visited) {
		if (s > e)
			return 0;
		if (s == e)
			return 1;
		if (visited[s][e] != -1)
			return visited[s][e];
		int ans = 0;

		if (visited[s][e] == -1) {
			if (A.charAt(s) == A.charAt(e))
				ans = 2 + lps(A, s + 1, e - 1, visited);
			else
				ans = Math.max(lps(A, s + 1, e, visited), lps(A, s, e - 1, visited));
			visited[s][e] = ans;
		}
		return ans;
		// return visited[A.length()-1][A.length()-1] ;
	}
}
