package com.dsa.dynamicprogramming;

/*
 Problem Description
Given a string A of size N, find and return the longest palindromic substring in A.

Substring of string A is A[i...j] where 0 <= i <= j < len(A)

Palindrome string:
A string which reads the same backwards. More formally, A is palindrome if reverse(A) = A.

Incase of conflict, return the substring which occurs first ( with the least starting index).



Problem Constraints
1 <= N <= 6000



Input Format
First and only argument is a string A.



Output Format
Return a string denoting the longest palindromic substring of string A.



Example Input
A = "aaaabaaa"


Example Output
"aaabaaa"


Example Explanation
We can see that longest palindromic substring is of length 7 and the string is "aaabaaa".
 */
public class LongestPalindromicSubstring {
	public String longestPalindrome(String A) {
		int n = A.length();
		int max = Integer.MIN_VALUE;
		String ans = "";
		for (int i = 0; i < n; i++) {

			int p1 = i;
			int p2 = i;

			String subString = lps(A, p1, p2);
			int l = subString.length();
			if (l > max) {
				ans = subString;
				max = l;
			}
			p2 = p1 + 1;
			subString = lps(A, p1, p2);
			l = subString.length();
			if (l > max) {
				ans = subString;
				max = l;
			}
		}
		return ans;
	}

	String lps(String A, int p1, int p2) {

		while (p1 >= 0 && p2 < A.length() && A.charAt(p1) == A.charAt(p2)) {
			p1--;
			p2++;
		}
		return A.substring(p1 + 1, p2);
	}
}
