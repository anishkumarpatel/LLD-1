package com.dsa.dynamicprogramming;
/*
 Given a string A and a dictionary of words B, determine if A can be segmented into a space-separated sequence of one or more dictionary words.

Input Format:

The first argument is a string, A.
The second argument is an array of strings, B.
Output Format:

Return 0 / 1 ( 0 for false, 1 for true ) for this problem.
Constraints:

1 <= len(A) <= 6500
1 <= len(B) <= 10000
1 <= len(B[i]) <= 20
Examples:

Input 1:
    A = "myinterviewtrainer",
    B = ["trainer", "my", "interview"]

Output 1:
    1

Explanation 1:
    Return 1 ( corresponding to true ) because "myinterviewtrainer" can be segmented as "my interview trainer".

Input 2:
    A = "a"
    B = ["aaa"]

Output 2:
    0

Explanation 2:
    Return 0 ( corresponding to false ) because "a" cannot be segmented as "aaa".
 */
import java.util.*;
public class WordBreak {
	public int wordBreak1(String A, String[] B) { // TLE
        HashSet<String> dic = new HashSet<>();
        for(String s : B)
         dic.add(s);

         if(isWordBreak1(A,dic))
        return 1 ;
       else
        return 0 ;  
    }
    boolean isWordBreak1(String A, HashSet<String> dic){
        int l = A.length();
        if(l==0) return true ;
        for(int i=1; i<=A.length(); i++ )
         if(dic.contains(A.substring(0,i)) && isWordBreak1(A.substring(i,l),dic) )
          return true ;
        return false ;
    }
    
    public int wordBreak(String A, String[] B) {
        HashSet<String> dic = new HashSet<>();
        int l = A.length();
        int[] dp = new int[l] ;
        Arrays.fill(dp, -1);
        for(String s : B)
         dic.add(s);

        return isWordBreak(A,0,dic,dp);
    }
    int isWordBreak(String A,int idx, HashSet<String> dic,int[] dp ){
        int l = A.length();
        if(idx == l) return 1 ;

        if(dp[idx] != -1) return dp[idx];

        dp[idx] = 0;
        for(int i=idx; i<l; i++ ){
            String w = A.substring(idx, i + 1);
            if(dic.contains(w)) {
                if(isWordBreak(A, i + 1, dic, dp) == 1) {
                    dp[idx] = 1;
                    break;
                }
            }
        }
        return dp[idx] ;
    }
}
