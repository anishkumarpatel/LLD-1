package com.dsa.dynamicprogramming;

/*
 Approach
 
 Since the value of items will be less than equal to 50. So the max value can be 50 * N.

Create a dp array of size 50 * N where dp[val] will tell that minimum weight require to have value exactly equal to val.

This can be easily calculated by running two loops:

    for i -> 0 to N-1:
        for val -> mxval to A[i]
            dp[val] = min(dp[val],B[i] + dp[val-A[i]])
Now, check for the maximum value for which dp[val] is less than equal to the capacity of knapsack.
 
 Problem Description
Given two integer arrays A and B of size N each which represent values and weights associated with N items respectively.

Also given an integer C which represents knapsack capacity.

Find out the maximum value subset of A such that sum of the weights of this subset is smaller than or equal to C.

NOTE: You cannot break an item, either pick the complete item, or don’t pick it (0-1 property).



Problem Constraints
1 <= N <= 500

1 <= C, B[i] <= 106

1 <= A[i] <= 50



Input Format
First argument is an integer array A of size N denoting the values on N items.

Second argument is an integer array B of size N denoting the weights on N items.

Third argument is an integer C denoting the knapsack capacity.



Output Format
Return a single integer denoting the maximum value subset of A such that sum of the weights of this subset is smaller than or equal to C.



Example Input
Input 1:

 A = [6, 10, 12]
 B = [10, 20, 30]
 C = 50
Input 2:

 A = [1, 3, 2, 4]
 B = [12, 13, 15, 19]
 C = 10


Example Output
Output 1:

 22
Output 2:

 0


Example Explanation
Explanation 1:

 Taking items with weight 20 and 30 will give us the maximum value i.e 10 + 12 = 22
Explanation 2:

 Knapsack capacity is 10 but each item has weight greater than 10 so no items can be considered in the knapsack therefore answer is 0.
 */

import java.util.*;

public class KnapsackII {
	// using 2 d arrays
	public int solve(int[] A, int[] B, int C) {
		int n = A.length;

		int max = 0;
		for (int a : A) {
			max += a;
		}
		int[][] dp = new int[n + 1][max + 1];
		Arrays.fill(dp[0], (int) 1e7);

		dp[0][0] = 0;

		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= max; j++) {
				int pick = dp[i - 1][j];
				int skip = (int) 1e7;
				if (j - A[i - 1] >= 0)
					skip = B[i - 1] + dp[i - 1][j - A[i - 1]];
				dp[i][j] = Math.min(pick, skip);
			}
		}
		int ans = 0;
		for (int i = 1; i <= max; i++)
			if (dp[n][i] <= C)
				ans = i;
		return ans;
	}

	// 1 d array
	public int solve2(int[] A, int[] B, int C) {
		int n = A.length;

		int max = 0;
		for (int a : A) {
			max += a;
		}
		int[] dp = new int[max + 1];
		Arrays.fill(dp, (int) 1e7);

		dp[0] = 0;

		for (int i = 1; i <= n; i++) {
			for (int j = max; j >= 1; j--) {
				int pick = dp[j];
				int skip = (int) 1e7;
				if (j - A[i - 1] >= 0)
					skip = B[i - 1] + dp[j - A[i - 1]];
				dp[j] = Math.min(pick, skip);
			}
		}
		int ans = 0;
		for (int i = 1; i <= max; i++)
			if (dp[i] <= C)
				ans = i;
		return ans;
	}

	public int solve1(int[] A, int[] B, int C) {
		int n = A.length;

		int max = 0;
		for (int a : A) {
			max += a;
		}
		int[] dp = new int[max + 1];
		Arrays.fill(dp, (int) 1e7);

		dp[0] = 0;

		for (int i = 1; i <= n; i++) {
			for (int j = max; j >= A[i - 1]; j--) {
				int pick = dp[j];
				int skip = B[i - 1] + dp[j - A[i - 1]];
				dp[j] = Math.min(pick, skip);
			}
		}
		int ans = 0;
		for (int i = 1; i <= max; i++)
			if (dp[i] <= C)
				ans = i;
		return ans;
	}
	/*
	 * The code provided implements a dynamic programming solution to solve a
	 * problem of selecting elements from array A and skipping some elements, each
	 * of which has a corresponding cost in array B. The goal is to select elements
	 * in such a way that the total cost is minimized and does not exceed a given
	 * value C.
	 * 
	 * The approach involves using a 2D array 'dp' where dp[i][j] represents the
	 * minimum cost to achieve a sum of 'j' using the first 'i' elements of array A.
	 * The algorithm fills the 2D array in a bottom-up manner using two nested
	 * loops: the outer loop iterates over the elements of array A, and the inner
	 * loop iterates over the possible sum values (from 1 to the maximum possible
	 * sum of all elements in A). For each combination of 'i' and 'j', the algorithm
	 * computes the cost of selecting the i-th element (by adding its corresponding
	 * cost B[i-1] to the value dp[i-1][j-A[i-1]] which represents the minimum cost
	 * to achieve a sum of 'j-A[i-1]' using the first 'i-1' elements of A), or the
	 * cost of skipping the i-th element (by using the value dp[i-1][j] which
	 * represents the minimum cost to achieve a sum of 'j' using the first 'i-1'
	 * elements of A). Finally, the algorithm finds the highest possible sum value
	 * (i.e., the value of 'j') for which the corresponding minimum cost (i.e., the
	 * value of dp[n][j]) is less than or equal to C. This value is returned as the
	 * solution to the problem.
	 * 
	 * The time complexity of this algorithm is O(nmax), where 'n' is the length of
	 * array A and 'max' is the maximum possible sum of all elements in A. The space
	 * complexity is also O(nmax) due to the 2D array 'dp'. However, as mentioned
	 * before, it is possible to reduce the space complexity to O(max) by using a 1D
	 * array and updating the values in reverse order.
	 */
}
