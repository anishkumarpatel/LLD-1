package com.dsa.graph;

/*
 Problem Description
Given a matrix of integers A of size N x M describing a maze. The maze consists of empty locations and walls.

1 represents a wall in a matrix and 0 represents an empty location in a wall.

There is a ball trapped in a maze. The ball can go through empty spaces by rolling up, down, left or right, but it won't stop rolling until hitting a wall (maze boundary is also considered as a wall). When the ball stops, it could choose the next direction.

Given two array of integers of size B and C of size 2 denoting the starting and destination position of the ball.

Find the shortest distance for the ball to stop at the destination. The distance is defined by the number of empty spaces traveled by the ball from the starting position (excluded) to the destination (included). If the ball cannot stop at the destination, return -1.



Problem Constraints
2 <= N, M <= 100

0 <= A[i] <= 1

0 <= B[i][0], C[i][0] < N

0 <= B[i][1], C[i][1] < M



Input Format
The first argument given is the integer matrix A.

The second argument given is an array of integer B.

The third argument if an array of integer C.



Output Format
Return a single integer, the minimum distance required to reach destination



Example Input
Input 1:

A = [ [0, 0], [0, 0] ]
B = [0, 0]
C = [0, 1]
Input 2:

A = [ [0, 0], [0, 1] ]
B = [0, 0]
C = [0, 1]


Example Output
Output 1:

 1
Output 2:

 1


Example Explanation
Explanation 1:

 Go directly from start to destination in distance 1.
Explanation 2:

 Go directly from start to destination in distance 1.
 */
import java.util.*;

public class ShortestDistanceInAMaze {
	class Pair {
		int x;
		int y;
		int dis;

		Pair(int x, int y, int dis) {
			this.x = x;
			this.y = y;
			this.dis = dis;
		}
	}

	public int solve(int[][] A, int[] B, int[] C) {
		int r = A.length;
		int c = A[0].length;
		int[][] distance = new int[r][c];
		for (int[] arr : distance)
			Arrays.fill(arr, (int) 1e9);
		distance[B[0]][B[1]] = 0;
		bfs(A, B, distance);

		return (distance[C[0]][C[1]] == (int) 1e9) ? -1 : distance[C[0]][C[1]];
	}

	void bfs(int[][] A, int[] B, int[][] distance) {
		PriorityQueue<Pair> pq = new PriorityQueue<Pair>((a, b) -> a.dis - b.dis);
		Pair p = new Pair(B[0], B[1], 0);
		pq.add(p);
		while (!pq.isEmpty()) {
			p = pq.poll();
			if (p.dis > distance[p.x][p.y])
				continue;

			int[] dx = { 0, 0, -1, 1 }; // {0,-1,0,1};
			int[] dy = { -1, 1, 0, 0 };

			for (int k = 0; k < 4; k++) {
				int x = dx[k] + p.x;
				int y = dy[k] + p.y;

				int count = 0;
				while((x >= 0) && (x < A.length) && (y >= 0) && (y < A[0].length) && (A[x][y] == 0)) {
					x += dx[k];
					y += dy[k];
					count++;
				}
				x -= dx[k];
				y -= dy[k];
				if (distance[p.x][p.y] + count < distance[x][y]) {
					distance[x][y] = distance[p.x][p.y] + count;
					// p = new Pair(x,y,distance[x][y]);
					// pq.add(p);
					pq.add(new Pair(x, y, distance[x][y]));

				}
			}
		}
	}
}
/*
 * We can definitely say that ball will roll only in one of 4 directions, this
 * gives us only 4 options for each place. This points towards a BFS based
 * solution. This can be written easily using starting point as source and
 * running bfs until queue gets empty or we reach our destiniation.
 * 
 * 
 * The time complexity of the solve method is O(rclog(rc)), where r is the
 * number of rows and c is the number of columns in the input matrix A. This is
 * because the method uses a modified version of Dijkstra's algorithm, which has
 * a time complexity of O(Elog(V)), where E is the number of edges and V is the
 * number of vertices in the graph. In this case, the graph has rc vertices, and
 * each vertex has up to 4 edges (depending on the number of obstacles), so the
 * total number of edges is O(rc). Therefore, the time complexity is
 * O(rclog(r*c)).
 * 
 * The space complexity of the solve method is O(rc), as it uses a 2D matrix of
 * size rc to store the distances between each point in the matrix A and the
 * starting point B. The bfs method also uses a priority queue to store the
 * points to visit, which has a maximum size of rc. Therefore, the total space
 * complexity is O(rc).
 * 
 * It is important to note that the time complexity and space complexity of the
 * algorithm can be affected by the number and location of obstacles in the
 * input matrix A. If the matrix contains many obstacles, the number of edges in
 * the graph may increase, which could increase the time complexity of the
 * algorithm. Similarly, if the starting and ending points are far apart, the
 * time complexity may also increase.
 * 
 * 
 * 
 * 
 * 
 * Regenerat
 */
