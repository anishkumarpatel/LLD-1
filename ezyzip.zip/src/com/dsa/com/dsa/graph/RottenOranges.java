package com.dsa.graph;

/*
 Problem Description
Given a matrix of integers A of size N x M consisting of 0, 1 or 2.

Each cell can have three values:

The value 0 representing an empty cell.

The value 1 representing a fresh orange.

The value 2 representing a rotten orange.

Every minute, any fresh orange that is adjacent (Left, Right, Top, or Bottom) to a rotten orange becomes rotten. Return the minimum number of minutes that must elapse until no cell has a fresh orange. If this is impossible, return -1 instead.

Note: Your solution will run on multiple test cases. If you are using global variables, make sure to clear them.



Problem Constraints
1 <= N, M <= 1000

0 <= A[i][j] <= 2



Input Format
The first argument given is the integer matrix A.



Output Format
Return the minimum number of minutes that must elapse until no cell has a fresh orange.

If this is impossible, return -1 instead.



Example Input
Input 1:

A = [   [2, 1, 1]
        [1, 1, 0]
        [0, 1, 1]   ]
Input 2:

 
A = [   [2, 1, 1]
        [0, 1, 1]
        [1, 0, 1]   ]


Example Output
Output 1:

 4
Output 2:

 -1


Example Explanation
Explanation 1:

 Max of 4 using (0,0) , (0,1) , (1,1) , (1,2) , (2,2)
Explanation 2:

 Task is impossible
 */
import java.util.*;

public class RottenOranges {
	class Pair {
		int x;
		int y;
		int time;

		Pair(int x, int y, int time) {
			this.x = x;
			this.y = y;
			this.time = time;
		}
	}

	public int solve(int[][] A) {
		int r = A.length;
		int c = A[0].length;
		Queue<Pair> q = new LinkedList<Pair>();

		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				if (A[i][j] == 2)
					q.add(new Pair(i, j, 0));
			}
		}
		int ans = 0;
		while (!q.isEmpty()) {
			Pair p = q.poll();
			ans = p.time;
			if (p.x - 1 >= 0 && A[p.x - 1][p.y] == 1) {
				A[p.x - 1][p.y] = 2;

				q.add(new Pair(p.x - 1, p.y, p.time + 1));
			}
			if (p.x + 1 < r && A[p.x + 1][p.y] == 1) {
				A[p.x + 1][p.y] = 2;

				q.add(new Pair(p.x + 1, p.y, p.time + 1));
			}

			if (p.y - 1 >= 0 && A[p.x][p.y - 1] == 1) {
				A[p.x][p.y - 1] = 2;
				q.add(new Pair(p.x, p.y - 1, p.time + 1));
			}

			if (p.y + 1 < c && A[p.x][p.y + 1] == 1) {
				A[p.x][p.y + 1] = 2;
				q.add(new Pair(p.x, p.y + 1, p.time + 1));
			}
			/*
			 * for(int i=0; i<4; i++){ int x = p.x + dx[i]; int y = p.y + dy[i]; if(x>=0 &&
			 * x<r && y>=0 && y<c && A[x][y]==1){ A[x][y] = 2; q.add(new
			 * Pair(x,y,p.time+1)); } }
			 */
		}

		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				if (A[i][j] == 1)
					return -1;
			}
		}
		return ans;
	}
}

/*
 * Every turn, the rotting spreads from each rotting orange to other adjacent
 * oranges. Initially, the rotten oranges have ‘depth’ 0, and every time they
 * rot a neighbor, the neighbors have 1 more depth. We want to know the largest
 * possible depth.
 * 
 * Use multi-source BFS to achieve this with all cells containing rotten oranges
 * as starting nodes. At the end check if there are fresh oranges left or not.
 */
