package com.dsa.graph;
/*
 Approach
 
The idea is to use shortest path algorithm. We one by one remove every edge from graph, then we find shortest path between two corner vertices of it. We add an edge back before we process next edge.

1). create an empty vector ‘edge’ of size ‘E’
( E total number of edge). Every element of
this vector is used to store information of
all the edge in graph info

2) Traverse every edge edge[i] one - by - one
a). First remove ‘edge[i]’ from graph ‘G’
b). get current edge vertices which we just
removed from graph
c). Find the shortest path between them
“Using Dijkstra’s shortest path algorithm “
d). To make a cycle we add weight of the
removed edge to the shortest path.
e). update min_weight_cycle if needed
3) Return minimum weighted cycle

Time Complexity : O( E ( E log V ) ) where E is number of edges and N is number of nodes.

Problem Description
Given an integer A, representing number of vertices in a graph.

Also you are given a matrix of integers B of size N x 3 where N represents number of Edges in a Graph and Triplet (B[i][0], B[i][1], B[i][2]) implies there is an undirected edge between B[i][0] and B[i][1] and weight of that edge is B[i][2].

Find and return the weight of minimum weighted cycle and if there is no cycle return -1 instead.

NOTE: Graph may contain multiple edges and self loops.



Problem Constraints
1 <= A <= 1000

1 <= B[i][0], B[i][1] <= A

1 <= B[i][2] <= 100000



Input Format
The first argument given is the integer A.

The second argument given is the integer matrix B.



Output Format
Return the weight of minimum weighted cycle and if there is no cycle return -1 instead.



Example Input
Input 1:

 A = 4
 B = [  [1 ,2 ,2]
        [2 ,3 ,3]
        [3 ,4 ,1]
        [4 ,1 ,4]
        [1 ,3 ,15]  ]
Input 2:

 A = 3
 B = [  [1 ,2 ,2]
        [2 ,3 ,3]  ]


Example Output
Output 1:

 10 
Output 2:

 -1


Example Explanation
Explanation 1:

 Given graph forms 3 cycles
 1. 1 ---> 2 ---> 3 ---> 4 ---> 1 weight = 10
 2. 1 ---> 2 ---> 3 ---> 1 weight = 20
 3. 1 ---> 3---> 4 ---> 1 weight = 20
 so answer would be 10.
Explanation 2:

 Given graph forms 0 cycles so return -1.

 */
import java.util.*;
public class MinimumWeightedCycle {
/*
 Start traversing through each nodes in the given B matrix and find the min weighted cycle length and for each node we make use of dijkstra algo:

class Pair{
    int node,weight;
    Pair(int n,int w){
        this.node = n;
        this.weight = w;
    }
}

public class Solution {
    // need to declare some static global variables such as Adj list of Pairs,dist array and visited and inf
    static int maxS = 1001;
    static int[] dist = new int[maxS];
    static ArrayList<ArrayList<Pair>> adjList;
    static int inf = 100001;
    static int[] visited = new int[maxS];
    public int solve(int A, int[][] B) {
        buildGraph();
        HashMap<Pair,Integer> map = new HashMap<>();

        // In below code we can see 2 iterations for B array
        // using HashMap to make sure all the nodes get used only once
        for(int[] arr : B){
            if(arr[0] == arr[1])continue;
            if(map.containsKey(new Pair(arr[0],arr[1])) || map.containsKey(new Pair(arr[1],arr[0]))){
                continue;
            }
            map.put(new Pair(arr[0],arr[1]),1);
            map.put(new Pair(arr[1],arr[0]),1);
            // we also create the adjecency list here only 
            adjList.get(arr[0]).add(new Pair(arr[0],arr[1]));
            adjList.get(arr[1]).add(new Pair(arr[1],arr[0]));

        }
        int ans = Integer.MAX_VALUE;
        for(int[] arr : B){
            int u = arr[0];
            int v = arr[1];
            int w = arr[2];

            removeEdge(u,v,w);
            int cost = getThroughDijkstra(u,v);
            if(cost != inf){
                ans = Math.min(ans,cost+w);
            }
            addEdge(u,v,w);
        }
        if(ans == Integer.MAX_VALUE){
            ans = -1;
        }
        return ans;
    }
    private void addEdge(int s,int d,int wt){
        adjList.get(s).add(new Pair(d,wt));
        adjList.get(d).add(new Pair(s,wt));
    }
    private void removeEdge(int s,int d,int wt){
        adjList.get(s).remove(new Pair(d,wt));
        adjList.get(d).remove(new Pair(s,wt));
    }

    private int getThroughDijkstra(int src,int dest){

        for(int i = 0;i<maxS;i++){
            dist[i] = inf;
            visited[i] = 0;
        }
        PriorityQueue<Pair> que = new PriorityQueue<Pair>(new Comparator<Pair>(){
            @Override
            public int compare(Pair a,Pair b){
                return (a.node != b.node) ? a.node-b.node : a.weight - b.weight;
            }
        });
        que.add(new Pair(src,0));
        dist[src] = 0;
        while(que.size() > 0){
            Pair cp = que.poll();
            int pnode = cp.node;
            int pweight = cp.weight;
            if(visited[pnode] == 1)continue;
            visited[pnode] = 1;
            for(Pair p : adjList.get(cp.node)){
                int v = p.node;
                int w = p.weight;
                if(dist[pnode]+w < dist[v]){
                    dist[v] = dist[pnode]+w;
                    que.add(new Pair(v,dist[v]));
                }
            }
        }
        return dist[dest];

    }
    private void buildGraph(){
        adjList = new ArrayList<>();
        for(int i = 0;i<maxS;i++){
            dist[i] = 0;
            visited[i] = 0;
            adjList.add(new ArrayList<>());
        }

    }

}

=============================================

public class Solution {
    static int maxn = 1009;
    static ArrayList < ArrayList < pair > > adj;
    static int[] dist = new int[maxn];
    static int[] visited = new int[maxn];
    static int inf = 1000000000;
    public static void graph() {
        adj = new ArrayList < ArrayList < pair > > (maxn);
        for (int i = 0; i < maxn; i++) {
            dist[i] = 0;
            visited[i] = 0;
            adj.add(new ArrayList < pair > ());
        }
    }
    public int solve(int A, int[][] B) {
        graph();
        Map < pair, Integer > mp = new HashMap < pair, Integer > ();
        for (int[] row: B) {
            if (row[0] == row[1]) continue;
            if (mp.containsKey(new pair(row[0], row[1])) || mp.containsKey(new pair(row[1], row[0])))
                continue;
            mp.put(new pair(row[0], row[1]), 1);
            mp.put(new pair(row[1], row[0]), 1);
            adj.get(row[0]).add(new pair(row[1], row[2]));
            adj.get(row[1]).add(new pair(row[0], row[2]));
        }
        int ans = Integer.MAX_VALUE;
        for (int[] row: B) {
            int u = row[0];
            int v = row[1];
            int w = row[2];
            removeEdge(u, v, w);
            int cost = dijkstra(u, v);
            if (cost != inf)
                ans = Math.min(ans, cost + w);
            addEdge(u, v, w);
        }
        if (ans == Integer.MAX_VALUE)
            ans = -1;
        return ans;
    }
    public static void removeEdge(int u, int v, int w) {
        adj.get(u).remove(new pair(v, w));
        adj.get(v).remove(new pair(u, w));
    }
    public static void addEdge(int u, int v, int w) {
        adj.get(u).add(new pair(v, w));
        adj.get(v).add(new pair(u, w));
    }
    public static int dijkstra(int source, int dest) {
        PriorityQueue < pair > pq = new PriorityQueue < pair > (new CustomComp());
        for (int i = 0; i < maxn; i++) {
            dist[i] = inf;
            visited[i] = 0;
        }
        dist[source] = 0;
        pq.offer(new pair(0, source));

        while (pq.size() != 0) {
            pair temp = pq.poll();
            int u = temp.S;
            if (visited[u] == 1)
                continue;
            visited[u] = 1;
            for (int i = 0; i < adj.get(u).size(); i++) {
                int v = adj.get(u).get(i).F, w = adj.get(u).get(i).S;
                if (dist[u] + w < dist[v]) {
                    dist[v] = dist[u] + w;
                    pq.offer(new pair(dist[v], v));
                }
            }
        }
        return dist[dest];
    }
}
class pair implements Comparable {
    int F, S;
    pair(int f, int s) {
        F = f;
        S = s;
    }
    @Override
    public int compareTo(Object o) {
        pair p1 = (pair) this;
        pair p2 = (pair) o;
        return (p1.F != p2.F) ? p1.F - p2.F : p1.S - p2.S;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof pair)) return false;
        pair p1 = (pair) this;
        pair p2 = (pair) o;
        return p1.F == p2.F && p1.S == p2.S;
    }
    @Override
    public int hashCode() {
        return this.F + 97 * this.S;
    }
}
class CustomComp implements Comparator < pair > {
    @Override
    public int compare(pair aa, pair bb) {
        return aa.F - bb.F;
    }
}
 */
}
