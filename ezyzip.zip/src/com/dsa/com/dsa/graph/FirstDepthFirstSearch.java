package com.dsa.graph;

/*
 Problem Description
You are given N towns (1 to N). All towns are connected via unique directed path as mentioned in the input.

Given 2 towns find whether you can reach the first town from the second without repeating any edge.

B C : query to find whether B is reachable from C.

Input contains an integer array A of size N and 2 integers B and C ( 1 <= B, C <= N ).

There exist a directed edge from A[i] to i+1 for every 1 <= i < N. Also, it's guaranteed that A[i] <= i for every 1 <= i < N.

NOTE: Array A is 0-indexed. A[0] = 1 which you can ignore as it doesn't represent any edge.



Problem Constraints
1 <= N <= 100000



Input Format
First argument is vector A

Second argument is integer B

Third argument is integer C



Output Format
Return 1 if reachable, 0 otherwise.



Example Input
Input 1:

 A = [1, 1, 2]
 B = 1
 C = 2
Input 2:

 A = [1, 1, 2]
 B = 2
 C = 1


Example Output
Output 1:

 0
Output 2:

 1


Example Explanation
Explanation 1:

 Tree is 1--> 2--> 3 and hence 1 is not reachable from 2.
Explanation 2:

 Tree is 1--> 2--> 3 and hence 2 is reachable from 1.
 
 Sure! Here's an intuition of the BFS approach:

The idea behind the BFS approach is to start from the source node and explore its neighbors, then explore the neighbors of its neighbors, and so on until either the target node is found or all nodes have been explored. We can use a queue to keep track of the nodes that need to be explored.

In this particular problem, we can use the BFS approach to check whether we can reach the first town (B) from the second town (C) without repeating any edge. To do this, we can start from town C and explore its neighbors. If we find town B among the neighbors of town C, then we can return 1 since we can reach town B from town C. Otherwise, we continue exploring the neighbors of town C until either we find town B or we have explored all reachable towns from town C. If we have explored all reachable towns from town C and have not found town B, then we can return 0 since we cannot reach town B from town C without repeating any edge.

The key advantage of the BFS approach in this problem is that it guarantees that we find the shortest path from town C to town B (if there exists one) since we explore the neighbors of town C in a breadth-first manner.
 
 
 */
import java.util.*;

public class FirstDepthFirstSearch {
	public int solve(ArrayList<Integer> A, int B, int C) {
		// Create a graph represented as an adjacency list
		ArrayList<ArrayList<Integer>> graph = new ArrayList<>();
		for (int i = 0; i <= A.size(); i++) {
			graph.add(new ArrayList<Integer>());
		}
		for (int i = 0; i < A.size(); i++) {
			graph.get(A.get(i)).add(i + 1);
		}

		// Create a visited array to keep track of visited nodes
		boolean[] visited = new boolean[A.size() + 1];
		Arrays.fill(visited, false);

		// Perform BFS
		Queue<Integer> queue = new LinkedList<>();
		queue.offer(C);
		visited[C] = true;
		while (!queue.isEmpty()) {
			int current = queue.poll();
			if (current == B) {
				return 1; // B is reachable from C
			}
			for (int i = 0; i < graph.get(current).size(); i++) {
				int neighbor = graph.get(current).get(i);
				if (!visited[neighbor]) {
					visited[neighbor] = true;
					queue.offer(neighbor);
				}
			}
		}
		return 0; // B is not reachable from C
	}
}
