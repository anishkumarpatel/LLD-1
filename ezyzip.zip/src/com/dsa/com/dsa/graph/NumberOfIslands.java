package com.dsa.graph;

/*
 Problem Description
Given a matrix of integers A of size N x M consisting of 0 and 1. A group of connected 1's forms an island. From a cell (i, j) such that A[i][j] = 1 you can visit any cell that shares a corner with (i, j) and value in that cell is 1.

More formally, from any cell (i, j) if A[i][j] = 1 you can visit:

(i-1, j) if (i-1, j) is inside the matrix and A[i-1][j] = 1.
(i, j-1) if (i, j-1) is inside the matrix and A[i][j-1] = 1.
(i+1, j) if (i+1, j) is inside the matrix and A[i+1][j] = 1.
(i, j+1) if (i, j+1) is inside the matrix and A[i][j+1] = 1.
(i-1, j-1) if (i-1, j-1) is inside the matrix and A[i-1][j-1] = 1.
(i+1, j+1) if (i+1, j+1) is inside the matrix and A[i+1][j+1] = 1.
(i-1, j+1) if (i-1, j+1) is inside the matrix and A[i-1][j+1] = 1.
(i+1, j-1) if (i+1, j-1) is inside the matrix and A[i+1][j-1] = 1.
Return the number of islands.

NOTE: Rows are numbered from top to bottom and columns are numbered from left to right.



Problem Constraints
1 <= N, M <= 100

0 <= A[i] <= 1



Input Format
The only argument given is the integer matrix A.



Output Format
Return the number of islands.



Example Input
Input 1:

 A = [ 
       [0, 1, 0]
       [0, 0, 1]
       [1, 0, 0]
     ]
Input 2:

 A = [   
       [1, 1, 0, 0, 0]
       [0, 1, 0, 0, 0]
       [1, 0, 0, 1, 1]
       [0, 0, 0, 0, 0]
       [1, 0, 1, 0, 1]    
     ]


Example Output
Output 1:

 2
Output 2:

 5


Example Explanation
Explanation 1:

 The 1's at position A[0][1] and A[1][2] forms one island.
 Other is formed by A[2][0].
Explanation 2:

 There 5 island in total.
 
 ==========
 Approach
 
 The idea behind the BFS approach to solve this problem is to traverse the matrix and identify islands as connected components of 1's. We start with any cell containing 1 and mark it as visited, then add it to a queue for further traversal.
While the queue is not empty, we take a cell from the queue, check its neighbors, and if any of them are 1's and have not been visited yet, we mark them as visited and add them to the queue.
We repeat this process until the queue is empty, and then we move on to the next unvisited cell containing 1, and repeat the same process.
During this process, we keep track of the number of islands encountered, which is equal to the number of times we start the BFS traversal from an unvisited cell containing 1.
In summary, the BFS approach to solve this problem is based on the graph traversal algorithm BFS, which we apply to identify connected components of 1's in the matrix.
 */

import java.util.*;

public class NumberOfIslands {
	public int solve(int[][] A) {
		int r = A.length;
		int c = A[0].length;
		boolean[][] visited = new boolean[r][c];
		int noOfIslands = 0;
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				if (!visited[i][j] && A[i][j] == 1) {
					bfs(A, i, j, visited);
					noOfIslands++;
				}
			}
		}
		return noOfIslands;
	}

	void bfs(int[][] A, int i, int j, boolean[][] visited) {
		Queue<int[]> q = new LinkedList<>();
		q.offer(new int[] { i, j });
		visited[i][j] = true;
		while (!q.isEmpty()) {
			int[] cur = q.poll();
			int[] dx = { 0, -1, -1, -1, 0, 1, 1, 1 };
			int[] dy = { -1, -1, 0, 1, 1, 1, 0, -1 };
			for (int k = 0; k < 8; k++) {
				int x = cur[0] + dx[k];
				int y = cur[1] + dy[k];
				if (x >= 0 && x < A.length && y >= 0 && y < A[0].length && !visited[x][y] && A[x][y] == 1) {
					visited[x][y] = true;
					q.offer(new int[] { x, y });
				}
			}
		}
	}
	/*
	 * The time complexity of the given code is not O(n^2*m^2), as the nested loops
	 * only iterate over each element in the grid once.
	 * 
	 * The outer loop iterates over each row, and the inner loop iterates over each
	 * column of the current row. So, the total number of iterations of the nested
	 * loops is O(n * m), where n is the number of rows and m is the number of
	 * columns in the input grid.
	 * 
	 * 
	 * Inside the nested loops, the bfs function is called once for each unvisited 1
	 * in the grid. The bfs function has a worst-case time complexity of O(n * m),
	 * as it may visit every cell in the grid in the worst case. However, each cell
	 * is only visited once, so the total time complexity of the bfs function across
	 * all calls is also O(n * m).
	 * 
	 * Therefore, the overall time complexity of the solve function is O(n * m) +
	 * O(n * m), which simplifies to O(n * m).
	 * 
	 * Note that the space complexity of the algorithm is also O(n * m), as it uses
	 * a 2D boolean array to keep track of visited cells.
	 */
}
