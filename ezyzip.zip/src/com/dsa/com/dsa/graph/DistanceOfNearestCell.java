package com.dsa.graph;
/*
 Problem Description
Given a matrix of integers A of size N x M consisting of 0 or 1.

For each cell of the matrix find the distance of nearest 1 in the matrix.

Distance between two cells (x1, y1) and (x2, y2) is defined as |x1 - x2| + |y1 - y2|.

Find and return a matrix B of size N x M which defines for each cell in A distance of nearest 1 in the matrix A.

NOTE: There is atleast one 1 is present in the matrix.



Problem Constraints
1 <= N, M <= 1000

0 <= A[i][j] <= 1



Input Format
The first argument given is the integer matrix A.



Output Format
Return the matrix B.



Example Input
Input 1:

 A = [
       [0, 0, 0, 1]
       [0, 0, 1, 1] 
       [0, 1, 1, 0]
     ]
Input 2:

 A = [
       [1, 0, 0]
       [0, 0, 0]
       [0, 0, 0]  
     ]


Example Output
Output 1:

 [ 
   [3, 2, 1, 0]
   [2, 1, 0, 0]
   [1, 0, 0, 1]   
 ]
Output 2:

 [
   [0, 1, 2]
   [1, 2, 3]
   [2, 3, 4] 
 ]


Example Explanation
Explanation 1:

 A[0][0], A[0][1], A[0][2] will be nearest to A[0][3].
 A[1][0], A[1][1] will be nearest to A[1][2].
 A[2][0] will be nearest to A[2][1] and A[2][3] will be nearest to A[2][2].
Explanation 2:

 There is only a single 1. Fill the distance from that 1.
 */

import java.util.*;

public class DistanceOfNearestCell {
	class Pair {
		int x;
		int y;
		int dis;

		Pair(int x, int y, int dis) {
			this.x = x;
			this.y = y;
			this.dis = dis;
		}
	}

	public int[][] solve1(int[][] A) {
		int r = A.length;
		int c = A[0].length;

		Queue<Pair> q = new LinkedList<Pair>();
		int[][] B = new int[r][c];
		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				if (A[i][j] == 1)
					q.add(new Pair(i, j, 0));
				else
					B[i][j] = Integer.MAX_VALUE;
			}
		}

		while (!q.isEmpty()) {
			Pair p = q.poll();
			int[] dx = { 0, 0, -1, 1 };
			int[] dy = { 1, -1, 0, 0 };

			for (int i = 0; i < 4; i++) {
				int x = p.x + dx[i];
				int y = p.y + dy[i];
				if (x >= 0 && x < r && y >= 0 && y < c && B[x][y] > p.dis + 1) {
					B[x][y] = p.dis + 1;
					q.add(new Pair(x, y, B[x][y]));
				}
			}
		}
		return B;
	}

	public int[][] solve(int[][] A) {
		int r = A.length;
		int c = A[0].length;
		int[][] B = new int[r][c];
		for (int[] a : B)
			Arrays.fill(a, (int) 1e4);

		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++)
				if (A[i][j] == 1)
					B[i][j] = 0;
				else {
					if (i > 0)
						B[i][j] = Math.min(B[i][j], B[i - 1][j] + 1);
					if (j > 0)
						B[i][j] = Math.min(B[i][j], B[i][j - 1] + 1);
				}
		}

		for (int i = r - 1; i >= 0; i--) {
			for (int j = c - 1; j >= 0; j--)
				if (A[i][j] == 1)
					B[i][j] = 0;
				else {
					if (i < r - 1)
						B[i][j] = Math.min(B[i][j], B[i + 1][j] + 1);
					if (j < c - 1)
						B[i][j] = Math.min(B[i][j], B[i][j + 1] + 1);
				}
		}
		return B;
	}
}
