package com.dsa.graph;

/*Problem Description
There are A islands and there are M bridges connecting them. Each bridge has some cost attached to it.

We need to find bridges with minimal cost such that all islands are connected.

It is guaranteed that input data will contain at least one possible scenario in which all islands are connected with each other.



Problem Constraints
1 <= A, M <= 6*104

1 <= B[i][0], B[i][1] <= A

1 <= B[i][2] <= 103



Input Format
The first argument contains an integer, A, representing the number of islands.

The second argument contains an 2-d integer matrix, B, of size M x 3 where Island B[i][0] and B[i][1] are connected using a bridge of cost B[i][2].



Output Format
Return an integer representing the minimal cost required.



Example Input
Input 1:

 A = 4
 B = [  [1, 2, 1]
        [2, 3, 4]
        [1, 4, 3]
        [4, 3, 2]
        [1, 3, 10]  ]
Input 2:

 A = 4
 B = [  [1, 2, 1]
        [2, 3, 2]
        [3, 4, 4]
        [1, 4, 3]   ]


Example Output
Output 1:

 6
Output 2:

 6


Example Explanation
Explanation 1:

 We can choose bridges (1, 2, 1), (1, 4, 3) and (4, 3, 2), where the total cost incurred will be (1 + 3 + 2) = 6.
Explanation 2:

 We can choose bridges (1, 2, 1), (2, 3, 2) and (1, 4, 3), where the total cost incurred will be (1 + 2 + 3) = 6.*/
import java.util.* ;
public class CommutableIslands {
	class Pair {
		int v;
		int wt;

		Pair(int v, int wt) {
			this.v = v;
			this.wt = wt;
		}
	}

	public int solve(int A, int[][] B) {
		ArrayList<ArrayList<Pair>> graph = new ArrayList<>();
		for (int i = 0; i <= A; i++)
			graph.add(new ArrayList());

		for (int i = 0; i < B.length; i++) {
			graph.get(B[i][0]).add(new Pair(B[i][1], B[i][2]));
			graph.get(B[i][1]).add(new Pair(B[i][0], B[i][2]));
		}
		boolean[] visited = new boolean[A + 1];

		PriorityQueue<Pair> pq = new PriorityQueue<>((a, b) -> a.wt - b.wt);
		pq.offer(new Pair(1, 0));
		int mod = (int) 1e9 + 7;
		int minCost = 0;
		while (!pq.isEmpty()) {

			Pair cur = pq.poll();
			// System.out.println(cur.v+" "+cur.wt);
			int u = cur.v;
			if (visited[u])
				continue;

			minCost = minCost + cur.wt;
			minCost %= mod;
			visited[u] = true; // mark
			for (int i = 0; i < graph.get(cur.v).size(); i++) {
				Pair p1 = graph.get(cur.v).get(i);

				pq.offer(new Pair(p1.v, p1.wt));
			}
		}
		return minCost;
		/*
		 * The space complexity of the given code is O(V + E), where V is the number of
		 * vertices and E is the number of edges in the graph. This is because, in the
		 * ArrayList<ArrayList<Pair>> graph, we are storing adjacency list
		 * representation of the graph using ArrayList, which takes O(V + E) space. The
		 * boolean array visited and the PriorityQueue pq both take O(V) space.
		 * 
		 * The time complexity of the code is O(E log V), where E is the number of edges
		 * and V is the number of vertices in the graph. This is because, we are using a
		 * priority queue to store the edges, and the while loop runs E times. In each
		 * iteration, we extract the minimum element from the priority queue, which
		 * takes log V time. Additionally, for each vertex, we are iterating through its
		 * adjacency list, which takes O(E) time. Therefore, the total time complexity
		 * of the code is O(E log V).
		 */
	}
}
