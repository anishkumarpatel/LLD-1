package com.dsa.graph;

/*
 Problem Description
Find largest distance Given an arbitrary unweighted rooted tree which consists of N (2 <= N <= 40000) nodes.

The goal of the problem is to find largest distance between two nodes in a tree. Distance between two nodes is a number of edges on a path between the nodes (there will be a unique path between any pair of nodes since it is a tree).

The nodes will be numbered 0 through N - 1.

The tree is given as an array A, there is an edge between nodes A[i] and i (0 <= i < N). Exactly one of the i's will have A[i] equal to -1, it will be root node.



Problem Constraints
2 <= |A| <= 40000



Input Format
First and only argument is vector A



Output Format
Return the length of the longest path



Example Input
Input 1:

 
A = [-1, 0]
Input 2:

 
A = [-1, 0, 0]


Example Output
Output 1:

 1
Output 2:

 2


Example Explanation
Explanation 1:

 Path is 0 -> 1.
Explanation 2:

 Path is 1 -> 0 -> 2.
 */

import java.util.*;

public class LargestDistanceBetweenNodesOfATree {
	int ans;

	int maxHeightOfTree(int rootIndex, ArrayList<ArrayList<Integer>> list) {

		int max1 = 0;
		int max2 = 0;
		for (int i = 0; i < list.get(rootIndex).size(); i++) {
			int temp = maxHeightOfTree(list.get(rootIndex).get(i), list);
			if (temp >= max1) {
				max2 = max1;
				max1 = temp;
			}
			if (temp > max2 && temp != max1) {
				max2 = temp;
			}

		}
		ans = Math.max(ans, 1 + max1 + max2);
		return 1 + Math.max(max1, max2);
		// int left = maxHeightOfTree(root.left);
		// int right = maxHeightOfTree(root.right);
		// 1 + left + right;

		// return 1 + max(left, right);
	}

	public int solve(int[] A) {
		ans = 0;
		ArrayList<ArrayList<Integer>> list = new ArrayList<>();
		for (int i = 0; i < A.length; i++) {
			ArrayList<Integer> temp = new ArrayList<>();
			list.add(temp);
		}
		int rootIndex = 0;
		for (int i = 0; i < A.length; i++) {
			if (A[i] == -1)
				rootIndex = i;
			else
				list.get(A[i]).add(i);
		}
		maxHeightOfTree(rootIndex, list);
		return ans - 1;
	}
}
