package com.dsa.graph;
/*Problem Description
Given a 2-D board A of size N x M containing 'X' and 'O', capture all regions surrounded by 'X'.

A region is captured by flipping all 'O's into 'X's in that surrounded region.



Problem Constraints
1 <= N, M <= 1000



Input Format
First and only argument is a N x M character matrix A.


Output Format
Make changes to the the input only as matrix is passed by reference.



Example Input
Input 1:

 A = [ 
       [X, X, X, X],
       [X, O, O, X],
       [X, X, O, X],
       [X, O, X, X] 
     ]
Input 2:

 A = [
       [X, O, O],
       [X, O, X],
       [O, O, O]
     ]


Example Output
Output 1:

 After running your function, the board should be:
 A = [
       [X, X, X, X],
       [X, X, X, X],
       [X, X, X, X],
       [X, O, X, X]
     ]
Output 2:

 After running your function, the board should be:
 A = [
       [X, O, O],
       [X, O, X],
       [O, O, O]
     ]


Example Explanation
Explanation 1:

 O in (4,2) is not surrounded by X from below.
Explanation 2:

 No O's are surrounded.*/

import java.util.*;

public class CaptureRegionsOnBoard {
	class Pair {
		int x;
		int y;

		Pair(int x, int y) {
			this.x = x;
			this.y = y;
		}
	}

	public void solve(ArrayList<ArrayList<Character>> a) {
		int r = a.size();
		int c = a.get(0).size();

		boolean[][] visited = new boolean[r][c];

		Queue<Pair> q = new LinkedList<>();

		for (int i = 0; i < c; i++)
			if (a.get(0).get(i) == 'O') {
				visited[0][i] = true;
				q.offer(new Pair(0, i));
				bfs(a, q, visited);
			}

		for (int i = 0; i < c; i++)
			if (a.get(r - 1).get(i) == 'O') {
				q.offer(new Pair(r - 1, i));
				visited[r - 1][i] = true;
				bfs(a, q, visited);
			}

		for (int i = 0; i < r; i++)
			if (a.get(i).get(0) == 'O') {
				q.offer(new Pair(i, 0));
				visited[i][0] = true;
				bfs(a, q, visited);
			}

		for (int i = 0; i < r; i++)
			if (a.get(i).get(c - 1) == 'O') {
				q.offer(new Pair(i, c - 1));
				visited[i][c - 1] = true;
				bfs(a, q, visited);
			}

		for (int i = 0; i < r; i++) {
			for (int j = 0; j < c; j++) {
				if (visited[i][j] == false)
					a.get(i).set(j, 'X');
			}
		}
	}

	void bfs(ArrayList<ArrayList<Character>> a, Queue<Pair> q, boolean[][] visited) {
		int r = a.size();
		int c = a.get(0).size();

		while (!q.isEmpty()) {
			Pair p = q.poll();

			int[] dx = { 0, 0, -1, 1 };
			int[] dy = { 1, -1, 0, 0 };
			for (int i = 0; i < 4; i++) {
				int x = p.x + dx[i];
				int y = p.y + dy[i];
				if (x >= 0 && x < r && y >= 0 && y < c && a.get(x).get(y) == 'O' && visited[x][y] == false) {
					visited[x][y] = true;
					q.offer(new Pair(x, y));
				}
			}
		}
	}
}
