package com.dsa.graph;

/*
 Problem Description

Given a Tree of A nodes having A-1 edges. Each node is numbered from 1 to A where 1 is the root of the tree.

You are given Q queries. In each query, you will be given two integers L and X. Find the value of such node which lies at level L mod (MaxDepth + 1) and has value greater than or equal to X.

Answer to the query is the smallest possible value or -1, if all the values at the required level are smaller than X.

NOTE:

Level and Depth of the root is considered as 0.
It is guaranteed that each edge will be connecting exactly two different nodes of the tree.
Please read the input format for more clarification.


Problem Constraints

2 <= A, Q(size of array E and F) <= 105

1 <= B[i], C[i] <= A

1 <= D[i], E[i], F[i] <= 106



Input Format

The first argument is an integer A denoting the number of nodes.

The second and third arguments are the integer arrays B and C where for each i (0 <= i < A-1), B[i] and C[i] are the nodes connected by an edge.

The fourth argument is an integer array D, where D[i] denotes the value of the (i+1)th node

The fifth and sixth arguments are the integer arrays E and F where for each i (0 <= i < Q), E[i] denotes L and F[i] denotes X for ith query.



Output Format

Return an array of integers where the ith element denotes the answer to ith query.



Example Input

Input 1:

 A = 5
 B = [1, 4, 3, 1]
 C = [5, 2, 4, 4]
 D = [7, 38, 27, 37, 1]
 E = [1, 1, 2]
 F = [32, 18, 26]
Input 2:

 A = 3
 B = [1, 2]
 C = [3, 1]
 D = [7, 15, 27]
 E = [1, 10, 1]
 F = [29, 6, 26]


Example Output

Output 1:

 [37, 37, 27]
Output 2:

 [-1, 7, 27]


Example Explanation

Explanation 1:

      1[7]
     /    \
   5[1]  4[37]
        /    \
       2[38]  3[27]

 Query 1: 
    L = 1, X = 32
    Nodes for level 1 are 5, 4
    Value of Node 5 = 1 < 32
    Value of Node 4 = 37 >= 32
    Ans = 37
Explanation 2:

      1[7]
     /    \
   2[15]  3[27]

 Query 1: 
    L = 1, X = 6
    Nodes for level 1 are 2, 3 having value 15 and 27 respectively.
    Answer = -1 (Since no node is greater or equal to 29).
 Query 1: 
    L = 10 % 2 = 0, X = 6
    Nodes for level 0 is 1 having value 7.
    Answer = 7.  
 */
import java.util.*;

public class MaximumDepth {
	class Pair {
		int val;
		int level;

		Pair(int val, int level) {
			this.val = val;
			this.level = level;
		}
	}

	public int[] tle(int A, int[] B, int[] C, int[] D, int[] E, int[] F) {
		ArrayList<ArrayList<Integer>> graph = new ArrayList<>();

		for (int i = 0; i <= A; i++)
			graph.add(new ArrayList<>());

		for (int i = 0; i < B.length; i++) {
			graph.get(B[i]).add(C[i]);
			graph.get(C[i]).add(B[i]);
		}
		boolean[] visited1 = new boolean[A + 1];
		int maxDepth = bfs(graph, A, visited1);
		int[] result = new int[E.length];
		for (int i = 0; i < E.length; i++) {
			int l = E[i] % (maxDepth + 1);
			// System.out.println(l+" "+maxDepth+" "+E[i]);
			int x = F[i];
			Queue<Pair> q = new LinkedList<>();
			boolean[] visited = new boolean[A + 1];
			q.offer(new Pair(1, 0));
			int min = Integer.MAX_VALUE;
			while (!q.isEmpty()) {
				Pair p = q.poll();
				if (visited[p.val - 1])
					continue;
				if (p.level == l && D[p.val - 1] >= x)
					min = Math.min(min, D[p.val - 1]);

				visited[p.val - 1] = true;

				for (int j = 0; j < graph.get(p.val).size(); j++) {
					int v = graph.get(p.val).get(j);
					q.offer(new Pair(v, p.level + 1));
				}
			}
			if (min == Integer.MAX_VALUE)
				result[i] = -1;
			else
				result[i] = min;
		}
		return result;
	}

	int bfs(ArrayList<ArrayList<Integer>> graph, int A, boolean[] visited) {
		Queue<int[]> q = new LinkedList<>();
		q.offer(new int[] { 1, 0 });

		int ans = 0;

		while (!q.isEmpty()) {
			int[] p = q.poll();
			if (visited[p[0]])
				continue;
			ans = p[1];
			visited[p[0]] = true;
			for (int i : graph.get(p[0])) {
				q.offer(new int[] { i, 1 + p[1] });
			}
		}
		return ans;
	}

	public int[] solve(int A, int[] B, int[] C, int[] D, int[] E, int[] F) {
		ArrayList<ArrayList<Integer>> graph = new ArrayList<>();
		for (int i = 0; i <= A; i++) {
			graph.add(new ArrayList());
		}
		for (int i = 0; i < B.length; i++) {
			graph.get(B[i]).add(C[i]);
			graph.get(C[i]).add(B[i]);
		}
		HashMap<Integer, ArrayList<Integer>> preProcess = new HashMap<>();
		boolean[] visited = new boolean[A + 1];
		levelOrderTraversal(graph, preProcess, visited, D);
		// System.out.println(preProcess);
		int[] res = new int[E.length];
		for (int i = 0; i < E.length; i++) {
			int l = E[i] % (preProcess.size());
			int x = F[i];
			ArrayList<Integer> list = preProcess.get(l);
			res[i] = binarySearch(list, x);
			// System.out.println("re "+res[i]);
		}

		return res;
	}

	int binarySearch(ArrayList<Integer> level, int x) {
		int ans = -1;
		int s = 0;
		int e = level.size() - 1;
		while (s <= e) {
			int mid = (s + e) / 2;
			if (level.get(mid) == x)
				return x;
			else if (level.get(mid) < x)
				s = mid + 1;
			else {
				ans = level.get(mid);
				e = mid - 1;
			}
		}
		return ans;
	}

	void levelOrderTraversal(ArrayList<ArrayList<Integer>> graph, HashMap<Integer, ArrayList<Integer>> preProcess,
			boolean[] visited, int[] D) {
		Queue<int[]> q = new LinkedList<>();
		q.offer(new int[] { 1, 0 });
		while (!q.isEmpty()) {
			int[] p = q.poll();
			if (visited[p[0]])
				continue;
			visited[p[0]] = true;
			int key = p[1];
			ArrayList<Integer> store = preProcess.getOrDefault(key, new ArrayList<>());
			store.add(D[p[0] - 1]);
			preProcess.put(key, store);
		//	Collections.sort(store);
			for (int neighbour : graph.get(p[0])) {
				q.offer(new int[] { neighbour, key + 1 });
			}
		}
		for(Map.Entry<Integer,ArrayList<Integer>> entry : preProcess.entrySet()){
            Collections.sort(entry.getValue()) ;
        }
		/*
		 * The time complexity of the solve method is O(A + B log B + E log N), where A
		 * is the number of nodes, B is the number of edges, and E is the length of the
		 * input array E.
		 * 
		 * The space complexity of the solve method is O(A + B + E + N log N), where N
		 * is the maximum number of levels (i.e., the maximum distance from the root
		 * node to any other node in the graph). This includes the space used by the
		 * adjacency list representation of the graph (graph), the preProcess HashMap,
		 * the visited boolean array, and the res result array. The space complexity of
		 * the levelOrderTraversal method is O(A + N log N), where A is the number of
		 * nodes and N is the maximum number of levels, which includes the space used by
		 * the queue q.
		 */
	}

}
