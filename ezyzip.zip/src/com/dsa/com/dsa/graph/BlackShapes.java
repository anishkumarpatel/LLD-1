package com.dsa.graph;
/*
 Problem Description

Given character matrix A of O's and X's, where O = white, X = black.

Return the number of black shapes. A black shape consists of one or more adjacent X's (diagonals not included)



Problem Constraints

1 <= |A|,|A[0]| <= 1000

A[i][j] = 'X' or 'O'



Input Format

The First and only argument is character matrix A.



Output Format

Return a single integer denoting number of black shapes.



Example Input

Input 1:

 A = [ [X, X, X], [X, X, X], [X, X, X] ]
Input 2:

 A = [ [X, O], [O, X] ]


Example Output

Output 1:

 1
Output 2:

 2


Example Explanation

Explanation 1:

 All X's belong to single shapes
Explanation 2:

 Both X's belong to different shapes
 */

import java.util.*;

public class BlackShapes {
	private static final int[][] DIRECTIONS = { { -1, 0 }, { 1, 0 }, { 0, -1 }, { 0, 1 } };

	public int black(String[] A) {
		int n = A.length;

		int m = A[0].length();

		boolean[][] visited = new boolean[n][m];
		int count = 0;

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < m; j++) {
				if (A[i].charAt(j) == 'X' && !visited[i][j]) {
					bfs(A, visited, i, j);
					count++;
				}
			}
		}

		return count;
	}

	private void bfs(String[] A, boolean[][] visited, int i, int j) {
		Queue<int[]> queue = new LinkedList<>();
		queue.offer(new int[] { i, j });
		visited[i][j] = true;

		while (!queue.isEmpty()) {
			int[] curr = queue.poll();
			int x = curr[0];
			int y = curr[1];

			for (int[] dir : DIRECTIONS) {
				int newX = x + dir[0];
				int newY = y + dir[1];

				if (isValid(A, visited, newX, newY)) {
					queue.offer(new int[] { newX, newY });
					visited[newX][newY] = true;
				}
			}
		}
	}

	private boolean isValid(String[] A, boolean[][] visited, int i, int j) {
		int n = A.length;
		int m = A[0].length();

		return i >= 0 && i < n && j >= 0 && j < m && A[i].charAt(j) == 'X' && !visited[i][j];
	}
}
