package com.dsa.graph;

/*
Problem Description
A country consist of N cities connected by N - 1 roads. King of that country want to construct maximum number of roads such that the new country formed remains bipartite country.

Bipartite country is a country, whose cities can be partitioned into 2 sets in such a way, that for each road (u, v) that belongs to the country, u and v belong to different sets. Also, there should be no multiple roads between two cities and no self loops.

Return the maximum number of roads king can construct. Since the answer could be large return answer % 109 + 7.

NOTE: All cities can be visited from any city.



Problem Constraints
1 <= A <= 105

1 <= B[i][0], B[i][1] <= N



Input Format
First argument is an integer A denoting the number of cities, N.

Second argument is a 2D array B of size (N-1) x 2 denoting the initial roads i.e. there is a road between cities B[i][0] and B[1][1] .



Output Format
Return an integer denoting the maximum number of roads king can construct.



Example Input
Input 1:

 A = 3
 B = [
       [1, 2]
       [1, 3]
     ]
Input 2:

 A = 5
 B = [
       [1, 3]
       [1, 4]
       [3, 2]
       [3, 5]
     ]


Example Output
Output 1:

 0
Output 2:

 2


Example Explanation
Explanation 1:

 We can't construct any new roads such that the country remains bipartite.
Explanation 2:

 We can add two roads between cities (4, 2) and (4, 5).
 */
import java.util.*;

public class ConstructRoads {
	public int solve(int A, int[][] B) {
		ArrayList<ArrayList<Integer>> graph = new ArrayList<>();
		for (int i = 0; i <= A; i++)
			graph.add(new ArrayList<>());

		for (int i = 0; i < B.length; i++) {
			graph.get(B[i][0]).add(B[i][1]);
			graph.get(B[i][1]).add(B[i][0]);
		}

		int[] visited = new int[A + 1];
		Arrays.fill(visited, -1);
		int toggle = 1;

		Set<Integer> set1 = new HashSet<>();
		Set<Integer> set2 = new HashSet<>();
		Queue<Integer> q = new LinkedList<>();
		q.offer(1);
		visited[1] = 1;
		set2.add(0);

		while (!q.isEmpty()) {
			int cur = q.poll();

			toggle = 1 - visited[cur];
			for (int neighbours : graph.get(cur)) {
				if (visited[neighbours] != -1)
					continue;
				if (toggle == 0) {
					set1.add(neighbours);
					q.offer(neighbours);
					visited[neighbours] = 0;
				} else {
					set2.add(neighbours);
					q.offer(neighbours);
					visited[neighbours] = 1;
				}
			}
		}
		int mod = (int) 1e9 + 7;
		return (int) ((1l * set1.size() * set2.size() - (A - 1)) % mod);
	}
}
