package com.dsa.graph;

/*
 Approach
 =======
 
 Think of matrix as a graph with A*B nodes and Each node has an edge to its four neighbouring cells with weight as absolute difference of values between them.

Apply any MST algorithm on it and find the maximum weighted edge in that MST.

Why we have to apply MST?
Because in MST we always consider smallest weighted edge as to minimize the total cost so just find mst and find the maximum weighted edge in that MST.

You can use any of Kruskal or Prims Implementation of MST to solve this question.
 
 ==========
 
 Problem Description

Given a matrix C of integers, of dimension A x B.

For any given K, you are not allowed to travel between cells that have an absolute difference greater than K.

Return the minimum value of K such that it is possible to travel between any pair of cells in the grid through a path of adjacent cells.

NOTE:

Adjacent cells are those cells that share a side with the current cell.


Problem Constraints

1 <= A, B <= 102

1 <= C[i][j] <= 109



Input Format

The first argument given is A.

The second argument give is B.

The third argument given is the integer matrix C.



Output Format

Return a single integer, the minimum value of K.



Example Input

Input 1:

 A = 3
 B = 3
 C = [  [1, 5, 6]
        [10, 7, 2]
        [3, 6, 9]   ]


Example Output

Output 1:

 4


Example Explanation

Explanation 1:

 
 It is possible to travel between any pair of cells through a path of adjacent cells that do not have an absolute
 difference in value greater than 4. e.g. : A path from (0, 0) to (2, 2) may look like this:
 => (0, 0) -> (0, 1) -> (1, 1) -> (2, 1) -> (2, 2)
 
 */

import java.util.*;

public class MatrixAndAbsoluteDifference {
	public int solve(int A, int B, int[][] C) {
		ArrayList<ArrayList<int[]>> graph = new ArrayList<>();
		for (int i = 0; i < A; i++) {
			for (int j = 0; j < B; j++)
				graph.add(new ArrayList<>());
		}
		for (int i = 0; i < A; i++) {
			for (int j = 0; j < B; j++) {
				int u = i * B + j;
				if (i + 1 < A) {
					int v = (i + 1) * B + j;
					int wt = Math.abs(C[i][j] - C[i + 1][j]);
					graph.get(u).add(new int[] { v, wt });
					graph.get(v).add(new int[] { u, wt });
				}
				if (j + 1 < B) {
					int v = i * B + (j + 1);
					int wt = Math.abs(C[i][j] - C[i][j + 1]);
					graph.get(u).add(new int[] { v, wt });
					graph.get(v).add(new int[] { u, wt });
				}
			}
		} 
		int max = 0;
		PriorityQueue<int[]> q = new PriorityQueue<>((a, b) -> a[1] - b[1]);
		q.offer(new int[] { 0, 0 });
		boolean[] visited = new boolean[A * B];
		while (!q.isEmpty()) {
			int[] cur = q.poll();
			if (visited[cur[0]])
				continue;
			visited[cur[0]] = true;
			max = Math.max(max, cur[1]);
			for (int[] neighbours : graph.get(cur[0])) {
				int v = neighbours[0];
				int wt = neighbours[1];
				q.offer(new int[] { v, wt });
			}
		} // time complexity --> Elog(V) ; 
		return max;
	}
}
