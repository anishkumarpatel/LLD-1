package Q2;

public class LeastCommonAncestor {

}
