package Q2;

import java.util.*;

public class NMaxPairCombinations {
	public int[] solve1(int[] A, int[] B) { // brute force Approach
		int n = A.length;
		int[] res = new int[n * n];
		int k = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				res[k++] = A[i] + B[j];
			}
		}
		Arrays.sort(res);
		k = 0;
		for (int i = n * n - 1; i >= n * n - n; i--)
			A[k++] = res[i];
		return A;
	}

	// ==========
	class Pair {
		int val;
		int i;
		int j;

		Pair(int val, int i, int j) {
			this.val = val;
			this.i = i;
			this.j = j;
		}
	}

	public ArrayList<Integer> solve2(ArrayList<Integer> A, ArrayList<Integer> B) {
		Collections.sort(A);
		Collections.sort(B);
		PriorityQueue<Pair> pq = new PriorityQueue<>((a, b) -> b.val - a.val);
		HashSet<String> set = new HashSet<>();
		ArrayList<Integer> ans = new ArrayList<>();

		int n = A.size();
		int sum = A.get(n - 1) + B.get(n - 1);
		Pair p = new Pair(sum, n - 1, n - 1);
		pq.add(p);

		while (!pq.isEmpty()) {
			p = pq.poll();
			ans.add(p.val);
			int i = p.i;
			int j = p.j;
			String s1 = (i - 1) + "" + j;
			String s2 = i + "" + (j - 1);
			if (i - 1 > -1 && !set.contains(s1)) {
				sum = A.get(i - 1) + B.get(j);
				p = new Pair(sum, i - 1, j);
				pq.add(p);
				set.add(s1);
			}
			if (j - 1 > -1 && !set.contains(s2)) {
				sum = A.get(i) + B.get(j - 1);
				p = new Pair(sum, i, j - 1);
				pq.add(p);
				set.add(s2);
			}
			if (n == ans.size())
				break;
		}
		return ans;
	}
}

/*
 * 
 * Problem Description Given two integers arrays, A and B, of size N each.
 * 
 * Find the maximum N elements from the sum combinations (Ai + Bj) formed from
 * elements in arrays A and B.
 * 
 * 
 * 
 * Problem Constraints 1 <= N <= 2 * 105
 * 
 * -1000 <= A[i], B[i] <= 1000
 * 
 * 
 * 
 * Input Format The first argument is an integer array A. The second argument is
 * an integer array B.
 * 
 * 
 * 
 * Output Format Return an integer array denoting the N maximum element in
 * descending order.
 * 
 * 
 * 
 * Example Input Input 1:
 * 
 * A = [1, 4, 2, 3] B = [2, 5, 1, 6] Input 2:
 * 
 * A = [2, 4, 1, 1] B = [-2, -3, 2, 4]
 * 
 * 
 * Example Output Output 1:
 * 
 * [10, 9, 9, 8] Output 2:
 * 
 * [8, 6, 6, 5]
 * 
 * 
 * Example Explanation Explanation 1:
 * 
 * 4 maximum elements are 10(6+4), 9(6+3), 9(5+4), 8(6+2). Explanation 2:
 * 
 * 4 maximum elements are 8(4+4), 6(4+2), 6(4+2), 5(4+1).
 * 
 */
