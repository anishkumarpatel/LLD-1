
public class AG {

	public static void main(String[] args) {
		String s = "adgagagfg" ;
	     int c = 0,ans=0;
	    for(int i=0; i<s.length(); i++)
	    {
	    	if(s.charAt(i )== 'a')
	    		c = c +  1;
	    	else
	    		if(s.charAt(i) == 'g' )
	    			 ans += c;
	    	
	    }
	    System.out.println(ans);
	    
	    int n = s.length();
	    
	    ans=0;
	    c=0;
	    
	    for(int i=n-1; i>=0; i--)
	    	if(s.charAt(i )== 'g')
	    		c = c +  1;
	    	else
	    		if(s.charAt(i) == 'a' )
	    			 ans += c;
	    System.out.println(ans);
	}

}
