import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Test {
	
	public static void main(String[] args) {
		Node n1 = new Node(10,20) ;
		
		n1.next = new Node(1,2) ;
		
		n1.next.next = new Node(11,22);
		
		while(n1 != null)
		{
			System.out.println(n1.next);
			n1 = n1.next;
		}
	}

}
class Node{
	int x;
	int y;
	Node next ; 
	Node(int a, int b)
	{
		x = a ;
		y = b ;
		 next = null;
	}
}
